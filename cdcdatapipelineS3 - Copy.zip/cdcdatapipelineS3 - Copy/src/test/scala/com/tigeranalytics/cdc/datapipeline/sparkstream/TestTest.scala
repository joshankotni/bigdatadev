package com.tigeranalytics.cdc.datapipeline.sparkstream

import org.scalatest.FunSuite
class TestTest extends FunSuite {
    test("Test.functionalityCheck"){
      assert(Test.functionalityCheck("Joshan") == "Joshan")

    }
}
