package com.tigeranalytics.cdc.datapipeline.sparkstream

import org.apache.spark.sql.SparkSession

object imageTest {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("Imagetest").master("local").getOrCreate()
    val image_df=spark.read.format("image").load("C:\\Users\\joshan.kotni\\Pictures\\Wallpaper.jpg")
    image_df.show()
  }

}
