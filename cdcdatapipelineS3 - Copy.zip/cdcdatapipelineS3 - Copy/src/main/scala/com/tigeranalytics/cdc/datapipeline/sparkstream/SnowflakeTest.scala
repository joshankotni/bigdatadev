package com.tigeranalytics.cdc.datapipeline.sparkstream
import java.util.Calendar

import net.snowflake.spark.snowflake.Utils
import org.apache.spark.sql.SparkSession
object SnowflakeTest {
  val spark: SparkSession = SparkSession.builder().master("local").getOrCreate()
  val configuration = spark.sparkContext.hadoopConfiguration

  def main(args: Array[String]): Unit = {
    //println("joshan".replaceAll(".","*"))
    spark.sparkContext.setLogLevel("ERROR")
    val snowflakeConnProps = Map("sfUrl" -> "koa60317.snowflakecomputing.com",
      "sfUser" -> "cdcuser",
      "sfPassword" -> "Password!23",
      "sfDatabase" -> "TESTDB",
      "sfSchema" -> "PUBLIC",
      "sfWarehouse" -> "COMPUTE_WH")
    println("*****Start****")
    //val dbExistCheck =spark.read.format(Constants.SNOWFLAKE_SOURCE_NAME).options(snowflakeConnProps).option("query","select * from pos_data_tbl").load()
    //dbExistCheck.show()
    //println(Utils.runQuery(snowflakeConnProps, s"create database if not exists testdbnew"))
    // spark.read.format(Constants.SNOWFLAKE_SOURCE_NAME).options(snowflakeConnProps).option("query","show tables").load().show()
    // println(Utils.runQuery(snowflakeConnProps, s"show tables"))
    /* dbExistCheck.write
       .format(Constants.SNOWFLAKE_SOURCE_NAME)
       .options(snowflakeConnProps)
       .option("dbtable","cdctestingnew")
       .option("overwriteSchema", "true")
       .mode("append").save()*/
    println("Initial Load Completed")
    println(s"Block start time :  ${Calendar.getInstance().getTime()} ")
    //spark.read.format(Constants.SNOWFLAKE_SOURCE_NAME).options(snowflakeConnProps).option("query","show tables in database testdb").load().show()
    println(Utils.runQuery(snowflakeConnProps, s"use testdb"))
    Utils.runQuery(snowflakeConnProps, s"show tables like 'pos_data_tbl'")
    // println(Utils.runQuery(snowflakeConnProps,"drop database cdctesting"))



    //val tableExistCheck = spark.read.format(Constants.SNOWFLAKE_SOURCE_NAME).options(snowflakeConnProps).option("query",s"show tables in database testdb").load()
    //tableExistCheck.show()

    //val dbExistCheck1 = spark.read.format(Constants.SNOWFLAKE_SOURCE_NAME).options(snowflakeConnProps).option("query","show databases").load()
    println("******END*******")

  }

}
