package com.tigeranalytics.cdc.datapipeline.sparkstream
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

object Test {
  var log = Logger.getLogger(this.getClass.getName)
  val spark: SparkSession = SparkSession.builder().master("local").getOrCreate()
  val configuration = spark.sparkContext.hadoopConfiguration

  def main(args: Array[String]): Unit = {
    //var a = Option[Int]
    var topic =args(0)

/*
    configuration.addResource(new Path("../cdcdatapipeline/config/cdcdatasync.xml"))
    configuration.reloadConfiguration()
  import spark.implicits._
    log.info(s"Arguments : ${args.mkString(" ")}")
    var df = spark.sparkContext.parallelize(List("   x","a b  ","   v ","  b  ")).toDF().collect().map(_.getString(0).replace(" ","")).toList.contains("a")
      //.select("alphabet").collectAsList()//.mkString(" ")//.contains("a")//.replaceAll("[\\[\\]]","")//.toArray
    println(df)//.foreach(println))
    log.info(s"$name ...  completed")
    println(s"Calendar.getInstance().getTime() ${Calendar.getInstance().getTimeInMillis.toString}")
    println(s"configuration.get()  ${configuration.get("sfDataBase")}")*/

      println("joshan".replaceAll(".","*"))
    spark.sparkContext.setLogLevel("ERROR")
    println("PROGRAM STARTED ----------------------------")
    println(s"topic--->${topic}")
    /*val kafkaKeyValueDf = spark.readStream.format("kafka").option("kafka.bootstrap.servers", "kafka:9092")
      .option("subscribe", topic).option("startingOffsets", "earliest").load()
      .selectExpr("CONCAT(CAST(key AS STRING),'~',CAST(value AS STRING)) AS key_value")
*/
    //val kafkaDf = spark.read.csv("C:\\Users\\joshan.kotni\\workSpace\\NotepadPlusPlus\\kafkaTestData.csv")

    //kafkaKeyValueDf.show()
   /* kafkaKeyValueDf.writeStream
      .trigger (Trigger.ProcessingTime ("10 seconds") )
      //.option ("checkpointLocation", check_point_dir)
      .foreachBatch (writeToDelta _)
      .queryName ("kafka_stream_1")
      .start ()
      .awaitTermination ()*/
   var web_sales =  spark.read.format("csv").option("header",false).option("sep","|").load("s3a://tiger-de-tpcdata/tpc_ds_10g_generated_data/tpcds-kit/tools/web_sales.dat").drop("_c34").toDF("ws_sold_date_sk","ws_sold_time_sk","ws_ship_date_sk","ws_item_sk","ws_bill_customer_sk","ws_bill_cdemo_sk","ws_bill_hdemo_sk","ws_bill_addr_sk","ws_ship_customer_sk","ws_ship_cdemo_sk","ws_ship_hdemo_sk","ws_ship_addr_sk","ws_web_page_sk","ws_web_site_sk","ws_ship_mode_sk","ws_warehouse_sk","ws_promo_sk","ws_order_number","ws_quantity","ws_wholesale_cost","ws_list_price","ws_sales_price","ws_ext_discount_amt","ws_ext_sales_price","ws_ext_wholesale_cost","ws_ext_list_price","ws_ext_tax","ws_coupon_amt","ws_ext_ship_cost","ws_net_paid","ws_net_paid_inc_tax","ws_net_paid_inc_ship","ws_net_paid_inc_ship_tax","ws_net_profit")
    var customerDf = spark.read.format("csv").option("header",false).option("sep","|").load("s3a://tiger-de-tpcdata/tpc_ds_10g_generated_data/tpcds-kit/tools/customer.dat").drop("_c18").toDF("c_customer_sk","c_customer_id","c_current_cdemo_sk","c_current_hdemo_sk","c_current_addr_sk","c_first_shipto_date_sk","c_first_sales_date_sk","c_salutation","c_first_name","c_last_name","c_preferred_cust_flag","c_birth_day","c_birth_month","c_birth_year","c_birth_country","c_login","c_email_address","c_last_review_date")
    web_sales.write.format("delta").option("overwriteSchema", "true").mode("overwrite").save("s3a://tiger-de-tpcdata/bench_marking_data/delta_tables/web_sales/")
    customerDf.write.format("delta").option("overwriteSchema", "true").mode("overwrite").save("s3a://tiger-de-tpcdata/bench_marking_data/delta_tables/customerDf/")
    //var catalog_sales =  spark.read.format("csv").option("header",false).option("sep","|").load("s3a://tiger-de-tpcdata/tpc_ds_10g_generated_data/tpcds-kit/tools/catalog_sales.dat").drop("_c34").toDF("cs_sold_date_sk","cs_sold_time_sk","cs_ship_date_sk","cs_bill_customer_sk","cs_bill_cdemo_sk","cs_bill_hdemo_sk","cs_bill_addr_sk","cs_ship_customer_sk","cs_ship_cdemo_sk","cs_ship_hdemo_sk","cs_ship_addr_sk","cs_call_center_sk","cs_catalog_page_sk","cs_ship_mode_sk","cs_warehouse_sk","cs_item_sk","cs_promo_sk","cs_order_number","cs_quantity","cs_wholesale_cost","cs_list_price","cs_sales_price","cs_ext_discount_amt","cs_ext_sales_price","cs_ext_wholesale_cost","cs_ext_list_price","cs_ext_tax","cs_coupon_amt","cs_ext_ship_cost","cs_net_paid","cs_net_paid_inc_tax","cs_net_paid_inc_ship","cs_net_paid_inc_ship_tax","cs_net_profit")
    println("...Df loaded...")
    //catalog_sales.write.format("delta").option("overwriteSchema", "true").mode("overwrite").save("s3a://tiger-de-tpcdata/bench_marking_data/delta_tables/catalog_sales/")
      println("data written to delta")
    println("PROGRAM ENDED ----------------------------")
  }

  /*def functionalityCheck(str: String):String = str
  def   writeToDelta(microBatchOutputDF: DataFrame, batchId: Long) {
    import spark.implicits._
    val keyJsonDf = spark.read.json(microBatchOutputDF.withColumn("key",split($"KEY_VALUE","~").getItem(0)).drop("key_value").as[String])
    keyJsonDf.show
    val partitionBy_lst,primaryKey_lst = keyJsonDf.select("payload.*").columns.toList
    val valueJsonDf = spark.read.json(microBatchOutputDF.withColumn("value",split($"KEY_VALUE","~").getItem(1)).drop("key_value").as[String])
    println(valueJsonDf.printSchema)
    valueJsonDf.show()
    println(valueJsonDf.columns)
    valueJsonDf.coalesce(1).write.option("overwriteSchema", "true").mode("overwrite").option("path","/opt/").format("delta").saveAsTable("pos_data_tbl")

    //val database_name = valueJsonDf.select("payload").first.getString(0)
  }*/

}


