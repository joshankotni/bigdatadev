package com.tigeranalytics.cdc.datapipeline.sparkstream

import org.apache.spark.sql.SparkSession


object SparkKafkaTest extends App {
  val spark = SparkSession
    .builder
    .appName("Spark-Kafka-Integration")
    .master("local")
    .getOrCreate()

  /*  val mySchema = StructType(Array(
      StructField("id", IntegerType),
      StructField("name", StringType),
      StructField("year", IntegerType),
      StructField("rating", DoubleType),
      StructField("duration", IntegerType)
    ))
    val streamingDataFrame = spark.readStream.schema(mySchema).csv("C:\\Users\\joshan.kotni\\workSpace\\NotepadPlusPlus\\kafkaTestData.csv")
    streamingDataFrame.selectExpr("CAST(id AS STRING) AS key", "to_json(struct(*)) AS value").
      writeStream
      .format("kafka")
      .option("topic", "topicName")
      .option("kafka.bootstrap.servers", "localhost:9092")
      .option("checkpointLocation", "path to your local dir")
      .start()
    val df = spark
      .readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", "localhost:9092")
      .option("subscribe", "topicName")
      .load()

    df.show()*/

  /*val jdbcUrl = "jdbc:snowflake://koa60317.snowflakecomputing.com/"
  val properties = new Properties
  properties.put("user", "cdcuser")
  properties.put("password", "Password!23")
  properties.put("account", "koa60317")
  properties.put("warehouse", "COMPUTE_WH")
  properties.put("db", "TESTDB")
  properties.put("schema", "PUBLIC")
  // get connection
 // println("Create JDBC connection")
  val connection = DriverManager.getConnection(jdbcUrl, properties)
 // println("Done creating JDBC connection\n")
  // create statement
  //println("Create JDBC statement")
  val statement = connection.createStatement
 // println("Done creating JDBC statement\n")
  // create a table
  //println("Create my_variant_table table")
  statement.executeQuery("use testdb")
  val resultSet = statement.executeQuery("show tables like 'pos_data_tbl' in database testdb ")//executeUpdate("create or replace table my_variant_table(json VARIANT)")
  while(resultSet.next())
    {
      println(resultSet.getString("name"))//getString("name")
       }
  statement.close()
 // System.out.println("Done creating demo table\n")
  connection.close()
  System.out.println("Close connection\n")*/
  var df = spark.read.format("avro").load("C:/Users/joshan.kotni/Downloads/userdata1.avro")
  df.show()
  println(df.printSchema())


  //    val jsonFormatSchema = new String(Files.readAllBytes(Paths.get("./examples/src/main/resources/user.avsc")))
  //  df.select(from_avro($"first_name",jsonFormatSchema) as 'user)


}
