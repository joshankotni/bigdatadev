package com.tigeranalytics.datapipeline.cdc

import java.util.Calendar

import org.apache.hadoop.fs.Path
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.streaming.Trigger
//import org.apache.spark.sql.hive.HiveExternalCatalog
object Process {
  var log = Logger.getLogger(this.getClass.getSimpleName)



  val spark: SparkSession = SparkSession.builder()
    .config("spark.hadoop.fs.s3a.endpoint", "s3.us-east-2.amazonaws.com")
    .config("spark.hadoop.fs.s3a.access.key", "AKIASOWTZXBIW46U77X4")
    .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
    .config("spark.hadoop.fs.AbstractFileSystem.s3a.impl","org.apache.hadoop.fs.s3a.S3AFileSystem" )
    .config("spark.hadoop.fs.s3a.secret.key", "0zuuRCkT+pl5GdeGIC2PMLYbDmH0lq0MIL8FHOYz")
    //.enableHiveSupport()
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
    .config("spark.delta.logStore.class","org.apache.spark.sql.delta.storage.S3SingleDriverLogStore")
    //.config("spark.sql.streaming.metricsEnabled", true)
    .getOrCreate()

  //def open(spark: SparkSession) = { import org.apache.spark.sql.hive.HiveExternalCatalog spark.sharedState.externalCatalog.asInstanceOf[HiveExternalCatalog].client }

  spark.conf.set("spark.sql.crossJoin.enabled", true)
  spark.sparkContext.setLogLevel("WARN")
  println("Jai Sriram")
  println("Jai Bajrangabali")

  var delta_base_dir, kafka_topic, check_point_dir, snowFlakeDbUrl,dataBaseName: String = _
  var target_db_list: Array[String] = _
  val configuration = spark.sparkContext.hadoopConfiguration

  def main(args: Array[String]): Unit = {
    //Arguments to be passed
    kafka_topic = args(0)
    target_db_list = args(1).split(",")
   // dataBaseName = args(2)
     if (args.length != 2) throw
       new ArrayIndexOutOfBoundsException(s"Arguments did not match.\n Required Arguments are kafka_topic,target_db")

    configuration.addResource(new Path("/opt/spark/jars/cdcdatasync.xml"))
    configuration.reloadConfiguration()
    println(s"kafkaBrokerIp---->${configuration.get("kafkaBrokerIp")}")
    println(s"kafkaBrokerIp::::: kafkaBrokerIp" )


    /*val schemaRegistryConfs = Map(
      SchemaManager.PARAM_SCHEMA_REGISTRY_URL -> "http://schema-registry:8081/",
      SchemaManager.PARAM_SCHEMA_REGISTRY_TOPIC -> "topic1",
      SchemaManager.PARAM_VALUE_SCHEMA_ID -> "latest")*/


    for (target_db <- target_db_list) {
      println(s"Arguments : ${args.mkString(",\n")}")
      try {
        val kafkaKeyValueDf = spark.readStream
                                  .format("kafka")
                                  .option("kafka.bootstrap.servers", "kafka:9092")
                                  .option("subscribe", kafka_topic).option("startingOffsets", "earliest").load()


        println(s"Data read from kafka source :  ${Calendar.getInstance().getTime()}")
         target_db match {
           case deltaDb => val query2 = kafkaKeyValueDf.writeStream
                                                .trigger (Trigger.ProcessingTime ("10 seconds") )
                                                //.option ("checkpointLocation", check_point_dir)
                                                .foreachBatch (UpsertToDelta.writeToDelta _)
                                                .queryName ("kafka_stream_1")
                                                .start ()
                                                .awaitTermination ()
           case snowFlakeDb => val query2 = kafkaKeyValueDf.writeStream
                                                      .trigger (Trigger.ProcessingTime ("10 seconds") )
                                                      //.option ("checkpointLocation", check_point_dir)
                                                      .foreachBatch (UpsertToSnowflake.writeToSnowflake _)
                                                      .queryName ("kafka_stream_1")
                                                      .start ()
                                                      .awaitTermination ()
         }
      }
      catch {
        case x: NullPointerException => log.error("Empty data read from Kafka Broker")
        case e => e.printStackTrace()
      }
    }
  }
 }
