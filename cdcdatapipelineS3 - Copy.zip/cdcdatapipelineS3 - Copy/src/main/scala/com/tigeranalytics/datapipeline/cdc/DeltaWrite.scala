package com.tigeranalytics.datapipeline.cdc
import java.net.URI
import java.util.Calendar

import io.delta.tables.DeltaTable
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, rank}
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

object DeltaWrite {
  var log = Logger.getLogger(this.getClass.getSimpleName)

 /* def mergeToDelta(spark:SparkSession,delta_base_dir:String,database_name:String,dbTable:String,joinExpression:String,rankDf:DataFrame):Unit = {
    val delta_tbl_loc = delta_base_dir + database_name + "/" + dbTable
    println(s"Data merging to delta :  ${Calendar.getInstance().getTime()}")
    /*rankDf.createOrReplaceTempView("staging_tbl")
    val merge_str = s"""MERGE INTO ${dbTable} AS target
       USING staging_tbl AS source
       ON ${joinExpression}
        WHEN MATCHED and source.op = 'u' THEN
         UPDATE SET *
        WHEN MATCHED and source.op = 'd' THEN
         delete
       WHEN NOT MATCHED and source.op = 'c' THEN
         INSERT *"""
      spark.sql(merge_str)
      println("Incremental Load Completed")
      spark.sql(s"optimize ${dbTable}")
     println(s"optimize for ${dbTable} table is Completed")*/
    println(s"**** delta table Location:${delta_tbl_loc} and join expression ${joinExpression}  : ${Calendar.getInstance().getTime()}")

    rankDf.coalesce(10).write.mode("append").option("path", delta_tbl_loc).format("delta").saveAsTable(dbTable)
   /* DeltaTable.forPath(spark,delta_tbl_loc)
      .as("source")
      .merge(rankDf.as("target"), joinExpression)
      .whenMatched("source.op = 'u'").updateAll()
      .whenMatched("source.op = 'd'").delete()
      .whenNotMatched("source.op = 'c'").insertAll()
*/
     /*val deltaTableDf = spark.table(dbTable)
     println("merging data to delta")
     val deltaTable = DeltaTable.apply(deltaTableDf)
    //DeltaTable.forPath("")
    // if (deltaTable != null) {println ("deltatable is not null")}
     deltaTable.as("source").merge(rankDf.as("target"), joinExpression)
       .whenMatched("source.op = 'u'").updateAll()
       .whenMatched("source.op = 'd'").delete()
       .whenNotMatched("source.op = 'c'").insertAll()*/

    }
*/

  /*def fullLoad(spark:SparkSession,df:DataFrame, db_tbl:String, database_name:String, table_name:String,delta_base_dir:String, dbExistCheck:Boolean) : Unit =
  {/*
     INIT PROCESSING
    */
    println(s"DeltaFullLoad: ${Calendar.getInstance().getTime()}")
    val delta_tbl_loc = delta_base_dir + database_name + "/" + table_name
     println(s"delta_tbl_loc ${delta_tbl_loc} : ${Calendar.getInstance().getTime()}")
     println(s"Initial Load for Table ${table_name} : ${Calendar.getInstance().getTime()}")

    if (!dbExistCheck)
    {
      spark.sql(s"create database if not exists ${database_name}")
      println(s"${database_name} database created.. : ${Calendar.getInstance().getTime()}.")
    }
//    df.where("op != 'd'").coalesce(10).write.option("overwriteSchema", "true").mode("overwrite").option("path", delta_tbl_loc).format("delta").saveAsTable(db_tbl)
//    df.where("op != 'd'").write.option("overwriteSchema", "true").mode("overwrite").option("path", delta_tbl_loc).format("delta").saveAsTable(db_tbl)
    df.write.format("delta").option("overwriteSchema", "true").mode("overwrite").option("path", delta_tbl_loc).saveAsTable(db_tbl)
    println(s"Initial Load Completed : ${Calendar.getInstance().getTime()}")
  }
*/


  /* def fullLoad(spark:SparkSession,valueJsonDf:DataFrame, db_tbl:String, deltaTableLocation:String,primaryKey_lst: List[String],database_name:String,table_name:String):Unit = {
      println(s"dbtable: ${db_tbl} : ${Calendar.getInstance().getTime()}")
     //println(s"valuejsonDf count: ${valueJsonDf.count()} : ${Calendar.getInstance().getTime()}")
     valueJsonDf.show(50,false)
     println(s"ops in valuejsonDf :${valueJsonDf.select("op").distinct().show()} : ${Calendar.getInstance().getTime()}")
     val createUpdateDf = valueJsonDf.where("op in ('c','r','u')")
                          .selectExpr("after.*", "op", "cast(ts_ms/1000 as timestamp) as debz_processed_time")
     println(s"createDf loaded : ${Calendar.getInstance().getTime()} ")
     //println(s"createDf count : ${createDf.count()} : ${Calendar.getInstance().getTime()}")
    /* val updateDf = valueJsonDf.where("op = 'u'")
              .selectExpr("after.*", "op", "cast(ts_ms/1000 as timestamp) as debz_processed_time")
     println(s"updateDf loaded : ${Calendar.getInstance().getTime()} ")*/
     val orderBy_lst = List("debz_processed_time")
     val byPrimaryKey = Window.partitionBy(primaryKey_lst.map(col): _*).orderBy(orderBy_lst.map(x => col(x) desc): _*)
     val initialLoadDf = createUpdateDf.withColumn("rank", rank over byPrimaryKey).filter("rank = 1").drop("rank")
      println(s"Initial load df Created : ${Calendar.getInstance().getTime()} ")
     val fs = FileSystem.get(new URI(deltaTableLocation), spark.sparkContext.hadoopConfiguration)
     fs.delete(new Path(deltaTableLocation), true)
     println(s"Deleted the existing files in delta path : ${Calendar.getInstance().getTime()}")
     initialLoadDf.write.option("overwriteSchema", "true").mode(SaveMode.Overwrite).option("path", deltaTableLocation).format("delta").saveAsTable(db_tbl)
     //createDf.write.option("overwriteSchema", "true").mode(SaveMode.Overwrite).format("delta").save(deltaTableLocation)
     //spark.sql(s"CREATE TABLE ${table_name} USING DELTA LOCATION '${deltaTableLocation}'")
     println(s"createDf written to Delta: ${Calendar.getInstance().getTime()} ")
     var rankDf : DataFrame = null

     /*if(!updateDf.head(1).isEmpty) {
       println(s"updateDf is not Empty : ${Calendar.getInstance().getTime()}")
       val orderBy_lst = List("debz_processed_time")
       val byPrimaryKey = Window.partitionBy(primaryKey_lst.map(col): _*).orderBy(orderBy_lst.map(x => col(x) desc): _*)
       rankDf = updateDf.withColumn("rank", rank over byPrimaryKey).filter("rank = 1").drop("rank")
       println("inside updateDf after taking rank1 value")
       rankDf.show(false)
       println(s" RankDf orderedBy Primary Key :  ${Calendar.getInstance().getTime()}")
       //mergeToDelta(spark,rankDf,deltaTableLocation,primaryKey_lst,Util.getDeltaTargetTableSchema(spark,database_name,table_name))
     }*/
println("Initial Load Completed...")
   }
*/

  def createDeltaTable(spark:SparkSession,valueJsonDf: DataFrame,deltaTableLocation:String,db_tbl: String): Unit = {
    //valueJsonDf.show(100,false)
    val createTableDf = valueJsonDf.where("op in ('c','r','u')")
      .selectExpr("after.*", "op", "cast(ts_ms/1000 as timestamp) as debz_processed_time").filter("1=2")
    //createTableDf.distinct().show(5,false)
    val fs = FileSystem.get(new URI(deltaTableLocation), spark.sparkContext.hadoopConfiguration)
    fs.delete(new Path(deltaTableLocation), true)
    println(s"Deleted the existing files in delta path : ${Calendar.getInstance().getTime()}")
    createTableDf.write.option("overwriteSchema", "true").mode(SaveMode.Overwrite).option("path", deltaTableLocation).format("delta").saveAsTable(db_tbl)
    println(s"${db_tbl} Table created in delta : ${Calendar.getInstance().getTime()} ")
  }


  def incrementalLoad(spark:SparkSession,valueJsonDf:DataFrame,delta_tbl_loc:String,primaryKey_lst:Array[String],target_tbl_schema:Array[String],database_name:String,table_name:String,db_tbl:String,tableExistCheck:Boolean): Unit = {
    /*var createDf = valueJsonDf.where("op = 'c' or op = 'r'")
      .selectExpr("after.*", "op", "cast(ts_ms/1000 as timestamp) as debz_processed_time")
    println(s"initial load for createDf : ${Calendar.getInstance().getTime()} ")

    var updateDf = valueJsonDf.where("op = 'u'")
      .selectExpr("after.*", "op", "cast(ts_ms/1000 as timestamp) as debz_processed_time")
    println(s"initial load for UpdateDf : ${Calendar.getInstance().getTime()} ")

    var deleteDf = valueJsonDf.where("op = 'd'")
      .selectExpr("before.*", "op", "cast(ts_ms/1000 as timestamp) as debz_processed_time")
    println(s"initial load for deleteDf : ${Calendar.getInstance().getTime()} ")

    if(!createDf.head(1).isEmpty) { mergeToDelta(spark,createDf,delta_tbl_loc,primaryKey_lst,target_tbl_schema); println(s"merging createDf to Delta.:${Calendar.getInstance().getTime()}")}

    if(!updateDf.head(1).isEmpty) { mergeToDelta(spark,updateDf,delta_tbl_loc,primaryKey_lst,target_tbl_schema);println(s"merging updateDf to Delta.:${Calendar.getInstance().getTime()}")}

    if(!deleteDf.head(1).isEmpty) { mergeToDelta(spark,deleteDf,delta_tbl_loc,primaryKey_lst,target_tbl_schema);println(s"merging deleteDf to Delta.:${Calendar.getInstance().getTime()}")}
*/
   // println(s"ops in valuejsonDf :${valueJsonDf.select("op").distinct().show()} : ${Calendar.getInstance().getTime()}")
    //valueJsonDf.show(50,false)
    var createUpdateDf = valueJsonDf.where("op in ('c','u','r')").selectExpr("after.*", "op", "cast(ts_ms/1000 as timestamp) as debz_processed_time") ;
    println(s"CreateUpdateDf is loaded.:${Calendar.getInstance().getTime()}")
    println("createUpdateDf : ")
    //createUpdateDf.show(false)
    var deleteDf = valueJsonDf.where("op = 'd'").selectExpr("before.*", "op", "cast(ts_ms/1000 as timestamp) as debz_processed_time") ;
    println(s"DeleteDf is loaded.:${Calendar.getInstance().getTime()}")
    //deleteDf.show(false)
    println(s"Before CreateUpdate DF Empty Check : ${Calendar.getInstance().getTime()}")

    //val createUpdateDfEmptyCheck = createUpdateDf.head(1).isEmpty
   // val deleteDfEmptyCheck = deleteDf.head(1).isEmpty
   // if (!createUpdateDfEmptyCheck) {createUpdateDf = createUpdateDf.selectExpr("after.*", "op", "cast(ts_ms/1000 as timestamp) as debz_processed_time") ; println(s"CreateUpdateDf is loaded.:${Calendar.getInstance().getTime()}")}
   // if (!deleteDfEmptyCheck) {deleteDf = deleteDf.selectExpr("before.*", "op", "cast(ts_ms/1000 as timestamp) as debz_processed_time") ; println(s"DeleteDf is loaded.:${Calendar.getInstance().getTime()}")}

    val CUDschemaCheckFlag = Util.schemaCheck(createUpdateDf.columns.map(_.toLowerCase()), deleteDf.columns.map(_.toLowerCase()))
    println(s"CUDschemaCheckFlag : ${CUDschemaCheckFlag} : ${Calendar.getInstance().getTime()}")

    var dmlDf: DataFrame = null
    //if ((!createUpdateDfEmptyCheck) && (!deleteDfEmptyCheck)) {
      println(s"inside condition : createUpdateDf and deleteDf are not empty : ${Calendar.getInstance().getTime()} ")
      if (CUDschemaCheckFlag){ dmlDf = createUpdateDf.union(deleteDf); println(s"cudschemacheckFlag : true ; createupdateDf.union(deleteDf) : ${Calendar.getInstance().getTime()}")}
      else {
        // Very rare scenario For DDL changes in Delete records which is not in update or create statements. Only at that time, cartesian join will happen
        println(s"DDL changes are present in between createupdateDf and deleteDf  : ${Calendar.getInstance().getTime()}")
        val commonCols = createUpdateDf.columns.intersect(deleteDf.columns)
        println(s"cudschemacheckFlag : false ; createupdateDf.intersect(deleteDf) : ${Calendar.getInstance().getTime()}")
        dmlDf = createUpdateDf.join(deleteDf, commonCols, "outer")
        println(s"createUpdateDf join delete df : ${Calendar.getInstance().getTime()}")
      }
   // }
   /* else if (!createUpdateDf.isEmpty) dmlDf = createUpdateDf
    else dmlDf = deleteDf
*/    println("------------dmlDf------------")
    var rankDf: DataFrame = null
    /*if(!dmlDf.head(1).isEmpty) {*/
      println(s"dmlDf is not Empty : ${Calendar.getInstance().getTime()}")
      val orderBy_lst = List("debz_processed_time")
      val byPrimaryKey = Window.partitionBy(primaryKey_lst.map(col): _*).orderBy(orderBy_lst.map(x => col(x) desc): _*)
      rankDf = dmlDf.withColumn("rank", rank over byPrimaryKey).filter("rank = 1").drop("rank")
      println(s" RankDf orderedBy Primary Key :  ${Calendar.getInstance().getTime()}")
      //rankDf.dtypes.deep
      mergeToDelta(spark,rankDf,delta_tbl_loc,primaryKey_lst,target_tbl_schema,database_name,table_name,db_tbl,tableExistCheck)
    //}
    }

  def mergeToDelta(spark:SparkSession,rankDf:DataFrame,delta_tbl_loc:String,primaryKeyList:Array[String],target_tbl_schema:Array[String],database_name:String,table_name:String,db_tbl:String,tableExistCheck:Boolean):Unit = {
   println(s"taking rankDf schema.. : ${Calendar.getInstance().getTime()}")
      val stage_tbl_schema = rankDf.columns.map(_.toLowerCase) //spark.sql("select * from staging_tbl where 1 = 2").columns.map(x => x.toLowerCase)
     println(s"stage table schema Derived: ${Calendar.getInstance().getTime()}")
     val stg_target_schemaCheckFlag = Util.schemaCheck(stage_tbl_schema, target_tbl_schema)
     println(s"stg_delta_schemaCheckFlag : ${stg_target_schemaCheckFlag} : ${Calendar.getInstance().getTime()}")
    //def  schemaCheck (spark:SparkSession,sourceDf : DataFrame ,targetDf: DataFrame) :String = {
      //var str :String = null
      val joinExpression = primaryKeyList.map(x => s"source.${x}  = target.${x}").mkString(" and ")

      val sourceDf = spark.sql(s"select * from ${database_name}.${table_name} where 1 = 2")
      val emptyDf = rankDf.filter("1=2")

     /* if (sourceDf.dtypes.length > emptyDf.dtypes.length || (sourceDf.dtypes != emptyDf.dtypes && sourceDf.columns.length == emptyDf.columns.length)) {
        println(s"inside the overwriting data loop : ${Calendar.getInstance().getTime()}")
        var sourceDeltaDf = spark.read.format("delta").load(delta_tbl_loc + "/")
        var resultDf = sourceDeltaDf.alias("src").join(emptyDf.alias("rnk")).select("rnk.*")//oin(rankDf.as("rnk") col(s"src.${}"))
        resultDf.write.format("delta").option("overwriteSchema", "true").mode(SaveMode.Overwrite).save(delta_tbl_loc)
      }
*/
     if (!(stg_target_schemaCheckFlag)) {
       println(s" stg_target_schemaCheckFlag : false ,There are DDL changes : ${Calendar.getInstance().getTime()}")
       val emptyDf = rankDf.filter("1=2")
       emptyDf.coalesce(1).write.option("mergeSchema", "true").mode("append").format("delta").save(delta_tbl_loc)
       println(spark.read.format("delta").load(delta_tbl_loc).printSchema())
       println(s"Data written to delta : ${Calendar.getInstance().getTime()}")
     }
     else   println(s"There are no DDL changes ; ${Calendar.getInstance().getTime()}")


    println(s"**** delta table Location:${delta_tbl_loc} and join expression ${joinExpression}  : ${Calendar.getInstance().getTime()}")
   // rankDf.show(false)
   DeltaTable.forPath(spark,delta_tbl_loc)
      .as("source")
      .merge(rankDf.as("target"), joinExpression)
      .whenMatched("target.op = 'u'").updateAll()
      .whenMatched("target.op = 'd'").delete()
      //.whenNotMatched().insertAll().execute()
      .whenNotMatched("target.op in ('c','u')").insertAll().execute()
    var history = DeltaTable.forPath(spark,delta_tbl_loc).history()
    history.show(100)
    //rankDf.write.format("delta").option("mergeSchema", "true").mode("append").save(delta_tbl_loc)
    println("Delta Merge Completed ...")
  }


  }
