package com.tigeranalytics.datapipeline.cdc

import net.snowflake.spark.snowflake.Utils
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}


object SnowflakeWrite {
var log = Logger.getLogger(this.getClass.getSimpleName)
  def mergeToSnowflake(spark:SparkSession,dbTable:String,joinExpression:String,database_name:String,connectionProperties:Map[String,String]):Unit = {
    Utils.runQuery(connectionProperties,s"use database ${database_name}")
    var tableCheck = spark.read.format(Constants.SNOWFLAKE_SOURCE_NAME).options(connectionProperties).option("query","show tables").load().collect().contains(dbTable)
    //tableCheck
    //var joinExpression = (for (key <- primaryKey_lst) yield s"tgt.${key} = src.${key}").mkString(" and ")
    //val mergeQuery = s"""MERGE INTO ${dbTable} tgt USING ${dbTable}_temp src ON ${joinExpression}"""
  }

  def fullLoad(df:DataFrame, db_tbl:String, database_name:String, table_name:String, dbExistCheck:Boolean,connectionProperties:Map[String,String]) : Unit =
  {/*
     INIT PROCESSING
    */
    println(s"Initial Load for Table ${table_name}")
    Utils.runQuery(connectionProperties,s"create database if not exists ${database_name}")
    println(s"${database_name} database created...")

    df.where("op != 'd'").write
      .format(Constants.SNOWFLAKE_SOURCE_NAME)
      .options(connectionProperties)
      .option("dbtable",table_name)
      .option("overwriteSchema", "true")
      .mode("overwrite").save()
     println("Initial Load Completed")
  }


  def incrementalLoad(df:DataFrame,table_name:String,connectionProperties:Map[String,String]):Unit={
   /* val blockStartTimeInMillis = Calendar.getInstance().getTimeInMillis()
    Utils.runQuery(connectionProperties,s"CREATE TABLE ${table_name}")*/
    df.write
      .format(Constants.SNOWFLAKE_SOURCE_NAME)
      .options(connectionProperties)
      .option("dbtable",table_name)
      .option("overwriteSchema", "true")
      .mode("append").save()
    println("Data appended")
/*
    emptyDf.coalesce(1).write.option("mergeSchema", "true").mode("append").format("delta").save(delta_base_dir + database_name + "/" + table_name)
*/

  }

}
