package com.tigeranalytics.datapipeline.cdc
import org.apache.spark.sql.{DataFrame, Dataset}
import org.apache.spark.sql.SparkSession

object Util {
  val getMetaData = (df: DataFrame, node_value: String) => df.select(node_value).first.getString(0)
  val schemaCheck = (arr1:Array[String],arr2:Array[String]) => arr1.deep == arr1.deep
  /*def  schemaCheck (sourceDf : DataFrame ,targetDf: DataFrame) :Boolean = {
    if (sourceDf.dtypes.length< targetDf.dtypes.length || (sourceDf.dtypes.length == targetDf.dtypes.length)){
      if(sourceDf.columns)
    }
  } */

  def jsonRead(spark:SparkSession,ds:Dataset[String]):DataFrame = spark.read.json(ds)
//  def jsonRead(spark:SparkSession,ds:DataFrame[String]):DataFrame = spark.read.format("json").load()
  def getDeltaTargetTableSchema (spark: SparkSession,database_name:String,table_name: String):Array[String] = spark.sql(s"select * from ${database_name}.${table_name} where 1 = 2").columns.map(_.toLowerCase())

}
