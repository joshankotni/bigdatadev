package com.tigeranalytics.datapipeline.cdc

import java.util.Calendar

import com.tigeranalytics.datapipeline.cdc.Process._
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel
//import org.apache.spark.sql.avro.from_avro
import org.apache.spark.sql.DataFrame
import za.co.absa.abris.avro.functions.from_confluent_avro
import za.co.absa.abris.avro.read.confluent.SchemaManager



object UpsertToDelta {

  def writeToDelta(microBatchOutputDF: DataFrame, batchId: Long)  {
   println(s"spark URL ${spark.sparkContext.uiWebUrl}")
   val commonRegistryConfig = Map(
      SchemaManager.PARAM_SCHEMA_REGISTRY_TOPIC -> Process.kafka_topic,
      SchemaManager.PARAM_SCHEMA_REGISTRY_URL -> "http://schema-registry:8081/"
    )

    val keyRegistryConfig = commonRegistryConfig ++ Map(
      SchemaManager.PARAM_KEY_SCHEMA_NAMING_STRATEGY -> SchemaManager.SchemaStorageNamingStrategies.TOPIC_RECORD_NAME,
      SchemaManager.PARAM_KEY_SCHEMA_ID -> "latest",
      SchemaManager.PARAM_SCHEMA_NAME_FOR_RECORD_STRATEGY -> "key"
    )

    val valueRegistryConfig = commonRegistryConfig ++ Map(
      SchemaManager.PARAM_VALUE_SCHEMA_NAMING_STRATEGY -> SchemaManager.SchemaStorageNamingStrategies.TOPIC_NAME,
      SchemaManager.PARAM_VALUE_SCHEMA_ID -> "latest")

    val delta_base_dir = "s3a://tiger-de-tpcdata/spark_delta/"
    println(s"delta_base_dir : ${delta_base_dir}")
     spark.sql("set -v").show(100,false)

    println(s"Running for Batch: ${batchId}: ${Calendar.getInstance().getTime()} ")
    println(s"microBatchOutputDF partitions after rdd empty: ${microBatchOutputDF.rdd.getNumPartitions}: ${Calendar.getInstance().getTime()} ")
    println(s"Batch start time :  ${Calendar.getInstance().getTime()} \n BatchId : ${batchId} ")

    println(s"After microBatch show: ${Calendar.getInstance().getTime()}")
//    val keyJsonDf = Util.jsonRead(spark, microBatchOutputDF.withColumn("key", split(col("KEY_VALUE"), "~").getItem(0)).drop("key_value").as[String])
    //val keyJsonDf = microBatchOutputDF.select(from_avro(col("key"),keyavroschema).as("data")).select("data.*")
    val keyJsonDf = microBatchOutputDF.select(from_confluent_avro(col("key"),keyRegistryConfig).as("data")).select("data.*")
    val partitionBy_lst, primaryKey_lst = keyJsonDf.columns.toArray
    println(s"keyJsonDf loaded. partitionBy_lst : ${partitionBy_lst} : ${Calendar.getInstance().getTime()}")
    println(s"keyJsonDf partitions: ${keyJsonDf.rdd.getNumPartitions}: ${Calendar.getInstance().getTime()} ")

    val topicnameArray= Process.kafka_topic.split("\\.")
    val database_name = topicnameArray(topicnameArray.length - 2) //Process.dataBaseName //
    val table_name = topicnameArray.last
    val db_tbl = database_name + "." + table_name
    val delta_tbl_loc = delta_base_dir + database_name + "/" + table_name
    println(s"database_name: ${database_name}, table_name: ${table_name}, db_tbl: ${db_tbl}, delta_tbl_loc: ${delta_tbl_loc} : ${Calendar.getInstance().getTime()}")

    println(s"delta_tbl_loc : ${delta_tbl_loc} : ${Calendar.getInstance().getTime()}")

    // val valueJsonDf = Util.jsonRead(spark, microBatchOutputDF.withColumn("value", split(col("KEY_VALUE"), "~").getItem(1)).drop("key_value").as[String]
    // val valueJsonDf = microBatchOutputDF.select(from_avro(col("value"),valueavroschema).as("data")).select("data.*")
    // val valueJsonDf = microBatchOutputDF.select(from_avro(col("value"),valueRegistryConfig).as("data")).select("data.*")
    val valueJsonDf = microBatchOutputDF.select(from_confluent_avro(col("value"),valueRegistryConfig).as("data")).select("data.*")

    println(s"valueJsonDf loaded : ${Calendar.getInstance().getTime()}")
    valueJsonDf.persist(StorageLevel.MEMORY_ONLY)
    println(s"value json df persisted : ${Calendar.getInstance().getTime()}")
   // println(s"value json Count : ${valueJsonDf.count} : ${Calendar.getInstance().getTime()}")
    println(s"valueJsonDf partitions first: ${valueJsonDf.rdd.getNumPartitions}: ${Calendar.getInstance().getTime()} ")
    println(valueJsonDf.printSchema())
    println(s"valueJsonDf number partitions : ${valueJsonDf.rdd.getNumPartitions} ${Calendar.getInstance().getTime()}")

    val dbExistCheck = spark.catalog.databaseExists(database_name)
    println(s"dbExistCheck : ${dbExistCheck} : ${Calendar.getInstance().getTime()}" )

    if(!dbExistCheck ){spark.sql(s"create database if not exists ${database_name}") ; println(s"${database_name} database created.. : ${Calendar.getInstance().getTime()}.")}

    val tableExistCheck = spark.catalog.tableExists(s"${database_name}.${table_name}")
    println(s"tableExistCheck : ${tableExistCheck} : ${Calendar.getInstance().getTime()}")
    if (!tableExistCheck){ println("creating table");DeltaWrite.createDeltaTable(spark ,valueJsonDf,delta_tbl_loc,db_tbl)}
        val target_tbl_schema = Util.getDeltaTargetTableSchema(spark, database_name, table_name)
        println(s"target table schema derived : ${Calendar.getInstance().getTime()}")
        println(s"Incremental load part Running : ${Calendar.getInstance().getTime()} ")
        DeltaWrite.incrementalLoad(spark, valueJsonDf, delta_tbl_loc, primaryKey_lst, target_tbl_schema,database_name,table_name,db_tbl,tableExistCheck)
    //println(s"optimizing delta table : ${Calendar.getInstance().getTime()}")
    //    spark.sql(s"OPTIMIZE ${database_name}.${table_name}")
    //println(s"optimization completed : ${Calendar.getInstance().getTime()}")
      valueJsonDf.unpersist()
    if(batchId == 0) spark.sql(s"CREATE TABLE ${table_name} USING DELTA  LOCATION '${delta_tbl_loc}'")
    spark.sql("show databases").show()
  }

}
////*************************************************************************************************************************************************************
    /* var createUpdateDf = valueJsonDf.where("op = 'c' or op = 'u' or op = 'r'")
     println(s"Before CreateUpdate DF Empty Check : ${Calendar.getInstance().getTime()}")
     val createUpdateDf_empty_flag = createUpdateDf.rdd.isEmpty
//     val createUpdateDf_empty_flag = valueJsonDf.where("op = 'c' or op = 'u' or op = 'r'").rdd.isEmpty
     println(s"After CreateUpdate DF Empty Check : ${Calendar.getInstance().getTime()}")
//     var createUpdateDf = valueJsonDf.where("op = 'c' or op = 'u' or op = 'r'")
     if (!createUpdateDf_empty_flag) {
       println(s"Inside CreateUpdate DF Empty Check : ${Calendar.getInstance().getTime()}")
       println(s"CreateUpdate number partitions : ${createUpdateDf.rdd.getNumPartitions} ${Calendar.getInstance().getTime()}")
       createUpdateDf = createUpdateDf.selectExpr("after.*", "op", "cast(ts_ms/1000 as timestamp) as debz_processed_time")
     }
//     var createUpdateDf = valueJsonDf.where("op = 'c' or op = 'u' or op = 'r'").selectExpr("after.*", "op", "cast(ts_ms/1000 as timestamp) as debz_processed_time")
     println(s"CreateUpdateDf is loaded.:${Calendar.getInstance().getTime()}")

     var dmlDf: DataFrame = null
     dmlDf = createUpdateDf
     println(s"dmlDf = createUpdateDf : ${Calendar.getInstance().getTime()}")

     var deleteDf = valueJsonDf.where("op = 'd'")
     println(s"Before Delete DF Empty Check : ${Calendar.getInstance().getTime()}")
//     val deleteDf_empty_flag = valueJsonDf.where("op = 'd'").rdd.isEmpty()
//     var deleteDf = valueJsonDf.where("op = 'd'")
     val deleteDf_empty_flag = deleteDf.rdd.isEmpty
     println(s"After Delete DF Empty Check : ${Calendar.getInstance().getTime()}")
     if (!deleteDf_empty_flag) {
       println(s"Inside Delete DF Empty Check : ${Calendar.getInstance().getTime()}")
       deleteDf = deleteDf.selectExpr("before.*", "op", "cast(ts_ms/1000 as timestamp) as debz_processed_time")
     }
//     var deleteDf = valueJsonDf.where("op = 'd'").selectExpr("before.*", "op", "cast(ts_ms/1000 as timestamp) as debz_processed_time")
     println(s"DeleteDf is loaded.:${Calendar.getInstance().getTime()}")

////     if (!createUpdateDf.rdd.isEmpty) createUpdateDf = createUpdateDf.selectExpr("after.*", "op", "cast(ts_ms/1000 as timestamp) as debz_processed_time")
////     println(s"CreateUpdateDf is loaded.:${Calendar.getInstance().getTime()}")
//
////     if (!deleteDf.rdd.isEmpty) deleteDf = deleteDf.selectExpr("before.*", "op", "cast(ts_ms/1000 as timestamp) as debz_processed_time")
////     println(s"DeleteDf is loaded.:${Calendar.getInstance().getTime()}")
//
//     val createUpdateSchema = createUpdateDf.columns.map(x => x.toLowerCase)
//     val deleteSchema = deleteDf.columns.map(x => x.toLowerCase)
//    /* println(s"""Schemas:
//             |createUpdateSchema:${createUpdateSchema.foreach(println)}
//             |deleteSchema: ${deleteSchema.foreach(println)}""".stripMargin)*/
//     val CUDschemaCheckFlag = Util.schemaCheck(createUpdateSchema, deleteSchema)
//     var dmlDf: DataFrame = null
//     println(s"CUDschemaCheckFlag : ${CUDschemaCheckFlag} : ${Calendar.getInstance().getTime()}")
////     if ((!createUpdateDf.rdd.isEmpty) && (!deleteDf.rdd.isEmpty)) {
//     if ((!createUpdateDf_empty_flag) && (!deleteDf_empty_flag)) {
//       println(s"createUpdateDf and deleteDf are not empty")
//       if (CUDschemaCheckFlag){
//         dmlDf = createUpdateDf.union(deleteDf)
//         println("cudschemacheckFlag : true ; createupdateDf.union(deleteDf)")
//       }
//       else {
//         // Very rare scenario For DDL changes in Delete records which is not in update or create statements. Only at that time, cartesian join will happen
//         val createUpdateArr = createUpdateDf.columns
//         val deleteArr = deleteDf.columns
//         val commonCols = createUpdateArr.intersect(deleteArr)
//         println("cudschemacheckFlag : false ; createupdateDf.intersect(deleteDf)")
//         dmlDf = createUpdateDf.join(deleteDf, commonCols, "outer")
//         println(s"createUpdateDf join delete df : ${Calendar.getInstance().getTime()}")
//       }
//     }
////     else if (!createUpdateDf.rdd.isEmpty) {
//     else if (!createUpdateDf_empty_flag) {
//       dmlDf = createUpdateDf
//       println(s"dmlDf = createUpdateDf : ${Calendar.getInstance().getTime()}")
//     }
//     else {
//       dmlDf = deleteDf
//       println(s"dmlDf = deleteDf : ${Calendar.getInstance().getTime()}")
//     }
//     println("------------dmlDf------------")
//     import org.apache.spark.sql.expressions.Window
//     import org.apache.spark.sql.functions.{col, rank}
//     val chg_cnt = dmlDf.count
//     println(s"Change Count: ${Calendar.getInstance().getTime()}", chg_cnt)
//     var rankDf: DataFrame = null
////     if (chg_cnt > 0) {
//     if (!dmlDf.rdd.isEmpty()) {
//       println(s"change count is greater than zero")
//       val orderBy_lst = List("debz_processed_time")
//       val byPrimaryKey = Window.partitionBy(partitionBy_lst.map(col): _*).orderBy(orderBy_lst.map(x => col(x) desc): _*)
//       rankDf = dmlDf.withColumn("rank", rank over byPrimaryKey).filter("rank = 1").drop("rank")
//       println(s"------------FirstRankDf :  ${Calendar.getInstance().getTime()}")
//     }
     //Confirm the same checks for snowflake db or not
    // val dbExistCheck = spark.catalog.databaseExists(database_name)
     println(s"dbExistCheck : ${dbExistCheck}")
//     if (!dbExistCheck) DeltaWrite.fullLoad(spark, rankDf, db_tbl, database_name, table_name, Process.configuration.get("delta_base_dir"), dbExistCheck)
     if (!dbExistCheck) DeltaWrite.fullLoad(spark, dmlDf, db_tbl, database_name, table_name, delta_base_dir, dbExistCheck)
     //case snowflakeDb => SnowflakeWrite.fullLoad(spark, rankDf, db_tbl, database_name, table_name, delta_base_dir, dbExistCheck)
     else if (dbExistCheck) {
       val tableExistCheck = spark.catalog.tableExists(s"${database_name}.${table_name}")
       println(s"tableExistCheck : ${tableExistCheck}")
//       if (!tableExistCheck) DeltaWrite.fullLoad(spark, rankDf, db_tbl, database_name, table_name, Process.configuration.get("delta_base_dir"), dbExistCheck)
       if (!tableExistCheck) DeltaWrite.fullLoad(spark, dmlDf, db_tbl, database_name, table_name, delta_base_dir, dbExistCheck)
       else {
         /*
        CHANGE PROCESSING
        */
         println(s"Incremental Load for Table ${table_name}")
         println("------------dmlDf------------")
         import org.apache.spark.sql.expressions.Window
         import org.apache.spark.sql.functions.{col, rank}
         val chg_cnt = dmlDf.count
         println(s"Change Count: ${Calendar.getInstance().getTime()}", chg_cnt)
         var rankDf: DataFrame = null
         //     if (chg_cnt > 0) {
         if (!dmlDf.rdd.isEmpty()) {
           println(s"change count is greater than zero")
           val orderBy_lst = List("debz_processed_time")
           val byPrimaryKey = Window.partitionBy(partitionBy_lst.map(col): _*).orderBy(orderBy_lst.map(x => col(x) desc): _*)
           rankDf = dmlDf.withColumn("rank", rank over byPrimaryKey).filter("rank = 1").drop("rank")
           println(s"------------FirstRankDf :  ${Calendar.getInstance().getTime()}")
         }
         rankDf.createOrReplaceTempView("staging_tbl")

         /*
         DDL CHECK
        */
         val stage_tbl_schema = spark.sql("select * from staging_tbl where 1 = 2").columns.map(x => x.toLowerCase)
         println(s"stage table schema Derived: ${Calendar.getInstance().getTime()}")

         val target_tbl_schema = spark.sql(s"select * from ${database_name}.${table_name} where 1 = 2").columns.map(x => x.toLowerCase)
         println(s"target table schema derived : ${Calendar.getInstance().getTime()}")
         //else if (target_db.equals("snowflakeDb")) target_tbl_schema = spark.read.format(Constants.SNOW_FLAKE_SOURCE_NAME).options(Process.snowflakeConnProps).option("query",s"create database if not exists ${database_name}").load().columns.map(_.toLowerCase)
         val stg_target_schemaCheckFlag = Util.schemaCheck(stage_tbl_schema, target_tbl_schema)
         println(s"stg_delta_schemaCheckFlag : ${stg_target_schemaCheckFlag} : ${Calendar.getInstance().getTime()}")

         if (!(stg_target_schemaCheckFlag)) {
           println(s" stg_target_schemaCheckFlag : false ,There are DDL changes : ${Calendar.getInstance().getTime()}")
           val emptyDf = rankDf.filter("1=2")
//         emptyDf.coalesce(1).write.option("mergeSchema", "true").mode("append").format("delta").save(Process.configuration.get("delta_base_dir") + database_name + "/" + table_name)
           emptyDf.coalesce(10).write.option("mergeSchema", "true").mode("append").format("delta").save(delta_base_dir + database_name + "/" + table_name)
           println(s"Data written to delta : ${Calendar.getInstance().getTime()}")
           //case snowflakeDb => SnowflakeWrite.incrementalLoad(emptyDf,table_name,snowflakeConnProps)
         }
         else {
           println(s"There are no DDL changes ; ${Calendar.getInstance().getTime()}")
         }
         //Primary Key Condition Generator for Merge statement

         val joinExpression = primaryKey_lst.map(x => s"source.${x}  = target.${x}").mkString(" and ")
         //val pri_key_const = pri_key_variable.mkString(" and ")
         println(s"pri_key_const in MERGE Statement : ${joinExpression} : ${Calendar.getInstance().getTime()}")
         /*
                 MERGE DATA INTO  TABLE
               */

         /*val merge_str = s"""MERGE INTO ${db_tbl} AS target
     USING staging_tbl AS source
     ON ${pri_key_const}
      WHEN MATCHED and source.op = 'u' THEN
       UPDATE SET *
      WHEN MATCHED and source.op = 'd' THEN
       delete
     WHEN NOT MATCHED and source.op = 'c' THEN
       INSERT *"""

        spark.sql(merge_str)*/
//         DeltaWrite.mergeToDelta(spark,Process.configuration.get("delta_base_dir"),database_name, table_name, joinExpression, rankDf)
         DeltaWrite.mergeToDelta(spark,delta_base_dir,database_name, table_name, joinExpression, rankDf)
         //case snowflakeDb => SnowflakeWrite.mergeToSnowflake(spark,db_tbl)

         println(s"Incremental Load Completed : ${Calendar.getInstance().getTime()}")
       }
     }
//     valueJsonDf.unpersist()
     println("Batch end time : " + Calendar.getInstance().getTime())
//   }
//    else{
//     println("Empty MicroBatch...")
//   }*/


