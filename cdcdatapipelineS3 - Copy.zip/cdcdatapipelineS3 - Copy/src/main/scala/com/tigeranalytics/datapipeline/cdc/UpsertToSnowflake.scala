package com.tigeranalytics.datapipeline.cdc

import java.util.Calendar

import com.tigeranalytics.datapipeline.cdc.Process.{configuration, spark}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.split


object UpsertToSnowflake {

  def writeToSnowflake(microBatchOutputDF: DataFrame, batchId: Long)  {

    import spark.implicits._
    val snowflakeConnProps = Map("sfUrl" -> "",
      "sfUser" -> configuration.get("sfUser"),
      "sfPassword" -> configuration.get("sfPassword"),
      "sfDatabase" -> configuration.get("sfDatabase"),
      "sfSchema" -> configuration.get("sfSchema"),
      "sfWarehouse" -> configuration.get("sfWarehouse"))

    println(s"Block start time :  ${Calendar.getInstance().getTimeInMillis()} \n BatchId : ${batchId} ")
    val keyJsonDf = Util.jsonRead(spark,microBatchOutputDF.withColumn("key",split($"KEY_VALUE","~").getItem(0)).drop("key_value").as[String])
    val partitionBy_lst,primaryKey_lst = keyJsonDf.select("payload.*").columns.toList
    println(s"keyJsonDf loaded: ${Calendar.getInstance().getTime()}")
    println(s"partitionBy_lst : ${partitionBy_lst} : ${Calendar.getInstance().getTime()}")

    val valueJsonDf = Util.jsonRead(spark,microBatchOutputDF.withColumn("value",split($"KEY_VALUE","~").getItem(1)).drop("key_value").as[String])
    println(s"valueJsonDf is loaded : ${Calendar.getInstance().getTime()}")

    val topicnameArray= Process.kafka_topic.split("\\.")
    val database_name = topicnameArray(topicnameArray.length - 2) //Process.dataBaseName //

    //val database_name = Process.dataBaseName
    val table_name_str = keyJsonDf.select("schema.name").take(1)(0).getString(0)
    println(s" table_name_str : $table_name_str : ${Calendar.getInstance().getTime()}")
    val lastElement = table_name_str.split("\\.").length - 2
    val table_name = table_name_str.split("\\.")(lastElement)
    val db_tbl = database_name + "." + table_name
    println(s"db_tbl : ${db_tbl} : ${Calendar.getInstance().getTime()}")

    var createUpdateDf = valueJsonDf.where("payload.op = 'c' or payload.op = 'u'")
    var deleteDf = valueJsonDf.where("payload.op = 'd'")
    if (!createUpdateDf.isEmpty)   createUpdateDf = createUpdateDf.selectExpr("payload.after.*","payload.op","cast(payload.ts_ms/1000 as timestamp) as debz_processed_time"); println(s"createUpdateDf is derived: ${Calendar.getInstance().getTime()}")
    if (!deleteDf.isEmpty)  deleteDf = deleteDf.selectExpr("payload.before.*","payload.op","cast(payload.ts_ms/1000 as timestamp) as debz_processed_time");println(s"deleteDf is derived : ${Calendar.getInstance().getTime()}")

    val createUpdateSchema = createUpdateDf.columns.map(x => x.toLowerCase)
    val deleteSchema = deleteDf.columns.map(x => x.toLowerCase)
    val CUDschemaCheckFlag = Util.schemaCheck(createUpdateSchema,deleteSchema)

    var dmlDf:DataFrame = null
    println(s"CUDschemaCheckFlag : ${CUDschemaCheckFlag} : ${Calendar.getInstance().getTime()}")
    if ((!createUpdateDf.isEmpty) && (!deleteDf.isEmpty))
    {
      println(s"crateUpdate and deleteDf are not empty : ${Calendar.getInstance().getTime()}")
      if (CUDschemaCheckFlag) { dmlDf = createUpdateDf.union(deleteDf) ; println(s" CUDCheckFlag is true : createUpdateDf.union(deleteDf) : ${Calendar.getInstance().getTime()}")}
      else
      {
        println(s"CUDCheckFlag is false. createUpdateDf.intertsect(deleteDf) : ${Calendar.getInstance().getTime()}")
        // Very rare scenario For DDL changes in Delete records which is not in update or create statements. Only at that time, cartesian join will happen
        val createUpdateArr = createUpdateDf.columns
        val deleteArr = deleteDf.columns
        val commonCols = createUpdateArr.intersect(deleteArr)
        dmlDf = createUpdateDf.join(deleteDf, commonCols, "outer")
        println(s"createUpdateDf.join(DeleteDf) : ${Calendar.getInstance().getTime()}")
      }
    }
    else if (!createUpdateDf.isEmpty) {dmlDf = createUpdateDf ; println("CreateUpdateDf is not empty, DmlDf is derived: ${Calendar.getInstance().getTime()}")}
    else dmlDf = deleteDf ; println(s"CreateUpdateDf is  empty, DmlDf is derived: ${Calendar.getInstance().getTime()}")
    import org.apache.spark.sql.expressions.Window
    import org.apache.spark.sql.functions.{col, rank}
    val chg_cnt = dmlDf.count
    var rankDf:DataFrame = null
    if (chg_cnt > 0)
    {
      println(s"Change Count is > 0 : ${Calendar.getInstance().getTime()}")
      val orderBy_lst = List("debz_processed_time")
      val byPrimaryKey = Window.partitionBy(partitionBy_lst.map(col): _*).orderBy(orderBy_lst.map(x => col(x) desc):_*)
      rankDf = dmlDf.withColumn("rank", rank over byPrimaryKey).filter("rank = 1").drop("rank")
      println("FirstRankDf")
    }
    //update
   /* val dbExistCheck = true // spark.read.format(Constants.SNOWFLAKE_SOURCE_NAME).options(snowflakeConnProps).option("query","show databases").load()
                       //.select("name").collect().map(_.getString(0).replace(" ","")).toList.contains(database_name)
    println(s"dbExistCheck : ${dbExistCheck}")*/

    val dbExistCheck = true
    if (!dbExistCheck) SnowflakeWrite.fullLoad(rankDf, db_tbl, database_name, table_name, dbExistCheck,snowflakeConnProps)
    //     case deltaDb => DeltaWrite.fullLoad(spark, rankDf, db_tbl, database_name, table_name, delta_base_dir, dbExistCheck)
    else if (dbExistCheck)
    {
//update this
      /*val tableExistCheck = spark.read.format(Constants.SNOWFLAKE_SOURCE_NAME).options(snowflakeConnProps).option("query",s"show tables in database ${database_name}").load()
            .select("name").collect().map(_.getString(0).replace(" ","")).toList.contains(database_name)
      println(s"tableExistCheck : ${tableExistCheck}")
*/
      val tableExistCheck = true
      if (!tableExistCheck) {
        /*target_db match {
          case deltaDb => DeltaWrite.fullLoad(spark, rankDf, db_tbl, database_name, table_name, delta_base_dir, dbExistCheck)
*/           SnowflakeWrite.fullLoad(rankDf, db_tbl, database_name, table_name, dbExistCheck,snowflakeConnProps)

      }
      else
      {
        /*
        CHANGE PROCESSING
        */
        println(s"Incremental Load for Table ${table_name}")
        rankDf.createOrReplaceTempView("staging_tbl")

        /*
         DDL CHECK
        */
        val stage_tbl_schema = spark.sql("select * from staging_tbl where 1 = 2").columns.map(x => x.toLowerCase)

        /*if(target_db.equals("deltaDb")) target_tbl_schema = spark.sql(s"select * from ${database_name}.${table_name} where 1 = 2").columns.map(x => x.toLowerCase)
        else if (target_db.equals("snowflakeDb"))*/
        val target_tbl_schema = spark.read.format(Constants.SNOWFLAKE_SOURCE_NAME).options(snowflakeConnProps).option("query",s"create database if not exists ${database_name}").load().columns.map(_.toLowerCase)
        val stg_target_schemaCheckFlag = Util.schemaCheck(stage_tbl_schema,target_tbl_schema)
        println(s"stg_delta_schemaCheckFlag : ${stg_target_schemaCheckFlag}")

        if (!(stg_target_schemaCheckFlag))
        {
          println("There are DDL changes")
          val emptyDf = rankDf.filter("1=2")
          /*target_db match {
            case deltaDb => emptyDf.coalesce(1).write.option("mergeSchema", "true").mode("append").format("delta").save(delta_base_dir + database_name + "/" + table_name)
            case snowflakeDb => */SnowflakeWrite.incrementalLoad(emptyDf,table_name,snowflakeConnProps)

        }
        else
        {
          println("There are no DDL changes")
        }
        //Primary Key Condition Generator for Merge statement

        val pri_key_variable = primaryKey_lst.map(x => "source." + x + " = " + "target." + x)
        val joinExpression = pri_key_variable.mkString(" and ")
        println(s"pri_key_const in MERGE Statement : ${joinExpression}")
           /*target_db match {
          case deltaDb => DeltaWrite.mergeToDelta(spark,db_tbl,pri_key_const)
          case snowflakeDb =>*/ SnowflakeWrite.mergeToSnowflake(spark,db_tbl,joinExpression,database_name,snowflakeConnProps)

        println("Incremental Load Completed")
      }
    }

    println("Block end time : " + Calendar.getInstance().getTime())
  }



}
