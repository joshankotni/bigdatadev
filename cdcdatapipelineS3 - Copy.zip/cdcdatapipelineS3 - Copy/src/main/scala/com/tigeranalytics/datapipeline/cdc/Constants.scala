package com.tigeranalytics.datapipeline.cdc

object Constants {
val SNOWFLAKE_SOURCE_NAME = "net.snowflake.spark.snowflake"
val DELTA_DB = "deltaDb"
val SNOW_FLAKE_DB = "snowflakeDb"
val TARGET_DB_LIST = "deltaDb,snowflakeDb"
}
