## Introduction 
---

This package contains the code for prevalidation ingestion of Tatasky PP Raw data, written in Spark Scala. 
The inputs are present in S3 and the output is stored as Parquet files in S3.
The output of this module is used as the input for ingestion of Tatasky PP as well as input for prevalidation of Tatasky PP Airflow DAGs.


## Input/Output Details
---

| Input Type                    | S3 Locations                                          |
| ------------------------------|-------------------------------------------------------|
| PP Raw Input                  | s3a://tataskyagg/active/pp/                           |
| PP Prevalidation Output       | s3a://tataskyagg/pp-prevalidation/                	|


*Note: The locations are set in ts-pp-pv-application.conf file 


## Process Description
---

The module has an uniform structure for all its submodules. They consist of packages of Ingestors, Transformers and Egestors. The main object is present outside these packages and serves as the entry point for running the process.

- Ingestors have methods to load the data, 
- Transformers have methods to parse Target and Market from the lines of the data and explode multiple TGs from a single line into multiple records. Also the function for the mapPartitions on the whole file is present here.
- Egestors have methods to write output to S3 as parquet files.


## Pre-Requisties before running the code
---

The following input sources must be ready before running the code.

- Built JAR of the code
- S3 input data

Once these pre-requisites are present, the jar can be run.


## Running the code
---

The jar can be run using the following spark-submit command:

```
export SPARK_MAJOR_VERSION=2
spark-submit --master yarn --queue jobs --num-executors 30 --executor-cores 1 --driver-memory 2G --executor-memory 7G \
--conf 'spark.driver.extraJavaOptions=-XX:+UseG1GC -Dconfig.file=/ebs_1/nithish/tspp/ts-pp-pv-application.conf' \
--conf 'spark.executor.extraJavaOptions=-XX:+UseG1GC -Dconfig.file=/ebs_1/nithish/tspp/ts-pp-pv-application.conf' \
--properties-file /ebs_1/nithish/tspp/spark-defaults.conf \
--packages com.typesafe:config:1.3.3 \
--class com.star.prism.tatasky.pp_prevalidation.PPPVMain /ebs_1/nithish/tspp/tatasky_2.11-0.1.jar > /ebs_1/nithish/tspp/tspppv.log 2>&1 

```

## Current Processing Time Information & Performance Optimizations Details from previous runs
---

Previously, it took ~35 min to pre-process all the files from a single week (to split into individual records).
Using this process, the time has been cut down to ~6 min per week.
