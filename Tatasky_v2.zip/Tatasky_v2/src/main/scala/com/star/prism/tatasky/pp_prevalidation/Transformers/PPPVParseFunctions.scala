package com.star.prism.tatasky.pp_prevalidation.Transformers

trait PPPVParseFunctions extends Serializable{

  def parseMarket(line: String)={
    line.contains("[All]") match{
      case true => Some(line.replaceAll("\"","").split(",").filter(_.length>1).map(_.trim).toList.head)
      case false => None
    }
  }

  def parseTarget(line: String) = {
    (line.contains("*") && !(line.contains("[All]"))) match{
      case true => Some(line.replaceAll("\"","").split(",").filter(_.length>1).map(_.trim).toList.distinct)
      case false => None
    }
  }

  def explodeRecord1(tg: List[String], market: String, line: String) = {
    line.split(",") match {
      case x: Array[String] if !x(8).contains("*") && x(8)!= "Universe" && (!tg.contains("fillerTarget1")) && (!line.replaceAll("\"","").contains("Channel,Date,Week sat-fri")) && (market !="fillerMarket") =>
        Some(List(
          List(x(0), x(1), x(2), x(3), x(4), x(5), x(6), x(7), x(8), x(9), x(10), x(11), x(12), x(13), tg(0), market).mkString(",")
        ))
      case _ => None
    }
  }

  def explodeRecord2(tg: List[String], market: String, line: String) = {
    line.split(",") match {
      case x: Array[String] if !x(8).contains("*") && x(8)!= "Universe" && (!tg.contains("fillerTarget1")) && (!line.replaceAll("\"","").contains("Channel,Date,Week sat-fri")) && (market !="fillerMarket") =>
        Some(List(
          List(x(0), x(1), x(2), x(3), x(4), x(5), x(6), x(7), x(8), x(9), x(10), x(11), x(12), x(13), tg(0), market).mkString(","),
          List(x(0), x(1), x(2), x(3), x(4), x(5), x(6), x(7), x(14), x(15), x(16), x(17), x(18), x(19), tg(1), market).mkString(",")
        ))
      case _ => None
    }
  }

}
