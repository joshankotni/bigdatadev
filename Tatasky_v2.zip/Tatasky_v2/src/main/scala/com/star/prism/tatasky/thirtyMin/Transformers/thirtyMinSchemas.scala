package com.star.prism.tatasky.thirtyMin.Transformers

case class thirtyMinInputSchema(universe: String,
                                target: String,
                                channel: String,
                                week_sun_sat: String,
                                week_date: String,
                                day: String,
                                daypart: String,
                                tvr_avgw: String,
                                impression_000_avgw: String,
                                reach_per_1min_count: String,
                                reach_000_1min_count: String,
                                share: String)

