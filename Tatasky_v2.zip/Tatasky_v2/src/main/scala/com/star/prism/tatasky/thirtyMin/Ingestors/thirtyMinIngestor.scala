package com.star.prism.tatasky.thirtyMin.Ingestors

import com.star.prism.tatasky.thirtyMin.Transformers.thirtyMinInputSchema
import com.typesafe.config.Config
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Encoders, SparkSession}

class thirtyMinIngestor extends Serializable {

  def dataLoader(loadPath: String)(implicit spark: SparkSession, appConf:Config): DataFrame = {

    // data load
    val loadDF = spark.
      read.
      format("csv").
      option("header", "false").
      option("delimiter", ",").
      schema(Encoders.product[thirtyMinInputSchema].schema).
      load(loadPath)

    loadDF

  }

  def dataLoaderMT(inputLocationYW: String, runYear:String) (implicit spark: SparkSession, appConf: Config): DataFrame = {

   spark.read.parquet(inputLocationYW).withColumn("year", lit(runYear).cast(IntegerType))

  }

}
