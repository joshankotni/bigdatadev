package com.star.prism.tatasky.commons.Mappers

import com.star.prism.tatasky.commons.HistoricalChannel
import com.typesafe.config.Config
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

trait channelRevisionMapper extends Serializable {

  def mapLatestChannelName(inputDF: DataFrame)(implicit spark: SparkSession, appConf: Config): DataFrame = {

    // Get historic mapping
    val channelRevMapping = new HistoricalChannel(appConf.getString("ts.channel-map-rev-path")).getMap.toSet.toList

    // build the map df
    val latestChannelMap = spark.
      createDataFrame(channelRevMapping).
      withColumnRenamed("_1", "channelName").
      withColumnRenamed("_2", "latestChannelName").
      withColumn("channelName", trim(upper(regexp_replace(col("channelName")," ","")))).
      withColumn("latestChannelName", trim(upper(regexp_replace(col("latestChannelName")," ","")))).
      distinct

    // join and map the latest channel name
    val mappedDF = mapChannels(inputDF, latestChannelMap)

    mappedDF

  }


  def mapChannels(inputDF: DataFrame, latestChannelMap: DataFrame)(implicit spark: SparkSession, appConf: Config): DataFrame = {

    import spark.implicits._

    val mappedDF = inputDF.
      withColumn("channelName", trim(upper(regexp_replace(col("channel"), " ", "")))).
      join(broadcast(latestChannelMap), Seq("channelName"), "leftouter").
      withColumn("latestChannelName",
        when($"latestChannelName".isNull, lit("NOT FOUND")).otherwise($"latestChannelName")).
      drop("channelName")

    mappedDF

  }

}
