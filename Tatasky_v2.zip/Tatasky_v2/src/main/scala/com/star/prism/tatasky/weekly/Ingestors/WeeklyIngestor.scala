package com.star.prism.tatasky.weekly.Ingestors

import com.star.prism.tatasky.weekly.Transformers.weeklyInputSchema
import com.typesafe.config.Config
import org.apache.spark.sql.{DataFrame, Encoders, SparkSession}

class WeeklyIngestor extends Serializable {

  def dataLoader(loadPath: String)(implicit spark: SparkSession, appConf:Config): DataFrame = {

    // data load
    val loadDF = spark.
      read.
      format("csv").
      option("header", "false").
      option("delimiter", ",").
      schema(Encoders.product[weeklyInputSchema].schema).
      load(loadPath)

    loadDF

  }

  def dataLoaderMT(inputLocationYW: String) (implicit spark: SparkSession, appConf: Config): DataFrame = {

    spark.read.parquet(inputLocationYW)
  }

}
