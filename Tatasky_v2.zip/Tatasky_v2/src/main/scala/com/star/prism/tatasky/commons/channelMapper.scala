package com.star.prism.tatasky.commons

import com.typesafe.config.Config
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Encoders, SparkSession}

class channelMapper extends Serializable {

  def mapLatestChannelName(inputDF: DataFrame, channelNameMapLocation: String)(implicit spark: SparkSession, appConf: Config): DataFrame = {

    // load the mapping file
    val loadDF = loadMapFile(channelNameMapLocation)

    // build the map df
    val latestChannelMap = transformMapFile(loadDF)

    // join and map the latest channel name
    val mappedDF = mapChannels(inputDF, latestChannelMap)

    mappedDF

  }

  def loadMapFile(channelNameMapLocation: String)(implicit spark: SparkSession, appConf: Config): DataFrame = {

    val loadDF = spark.
      read.
      option("header", "true").
      option("encoding", "UTF-8").
      schema(Encoders.product[channelRevisionMappingSchema].schema).
      csv(channelNameMapLocation)

    loadDF

  }

  def transformMapFile(loadDF: DataFrame)(implicit spark: SparkSession, appConf: Config): DataFrame = {

    import spark.implicits._

    val prepDF = loadDF.
      withColumn("latestChannelName", trim(upper(regexp_replace(col("channelCommon")," ","")))).
      withColumn("oldName1", upper(regexp_replace(col("channel1")," ",""))).
      withColumn("oldName2", upper(regexp_replace(col("channel2")," ",""))).
      withColumn("oldName3", upper(regexp_replace(col("channel3")," ",""))).
      withColumn("oldName4", upper(regexp_replace(col("channel4")," ",""))).
      withColumn("oldName5", upper(regexp_replace(col("channel5")," ",""))).
      withColumn("oldName6", upper(regexp_replace(col("channel6")," ",""))).
      select("latestChannelName", "oldName1", "oldName2", "oldName3", "oldName4", "oldName5", "oldName6")

    val transformDF = prepDF.
      withColumn("allChannelNames", concat_ws(",", prepDF.columns.map(c => col(c)):_*)).
      withColumn("splitChannelNames", split($"allChannelNames",",")).
      withColumn("explodeChannelNames", explode($"splitChannelNames")).
      withColumn("explodeChannelNames",
        when($"explodeChannelNames".isNull || $"explodeChannelNames" === lit(""), $"latestChannelName").
          otherwise($"explodeChannelNames"))

    val latestChannelMap = transformDF.
      selectExpr("TRIM(explodeChannelNames) AS channelName", "latestChannelName").
      distinct()

    latestChannelMap

  }

  def mapChannels(inputDF: DataFrame, latestChannelMap: DataFrame)(implicit spark: SparkSession, appConf: Config): DataFrame = {

    import spark.implicits._

    val mappedDF = inputDF.
      withColumn("channelName", trim(upper(regexp_replace(col("channel"), " ", "")))).
      join(broadcast(latestChannelMap), Seq("channelName"), "leftouter").
      withColumn("latestChannelName",
        when($"latestChannelName".isNull, lit("CHANNEL NOT FOUND")).otherwise($"latestChannelName")).
      drop("channelName")

    mappedDF

  }

}
