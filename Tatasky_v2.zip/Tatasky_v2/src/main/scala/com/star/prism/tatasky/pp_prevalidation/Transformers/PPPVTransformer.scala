package com.star.prism.tatasky.pp_prevalidation.Transformers

import com.star.prism.tatasky.commons.utilFunctions
import com.star.prism.tatasky.schemas.pp.outputSchemaTSPP
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.{lit, udf}
import org.apache.spark.sql.types.DoubleType
import org.apache.spark.sql.{DataFrame, Encoders, Row, SparkSession}

import scala.collection.mutable.ListBuffer

trait PPPVTransformer extends PPPVParseFunctions with utilFunctions with Serializable{

  def lineParser(inputRDD: RDD[String], year: String, week: String)(implicit spark: SparkSession): DataFrame = {

    import spark.sqlContext.implicits._

    val result = inputRDD.mapPartitions(lineIterator)
    val replaceQuotesRDD = result.map(x => x.replaceAll("\"",""))

    val outputDF = spark.
      createDataFrame(replaceQuotesRDD.map(a => Row.fromSeq(a.split(","))), Encoders.product[outputSchemaTSPP].schema).
      where("prog_title != 'Main Title'").
      withColumn("year", lit(year)).
      withColumn("week", lit(week)).
      withColumn("date", udf(formatDate).apply($"week_date")).
      drop("week_date").
      withColumnRenamed("date", "week_date").
      withColumn("dur_min_sum", $"dur_min_sum".cast(DoubleType)).
      withColumn("tvr_avgw", $"tvr_avgw".cast(DoubleType)).
      withColumn("impression_000_avgw", $"impression_000_avgw".cast(DoubleType)).
      withColumn("reach_per_1min_count", $"reach_per_1min_count".cast(DoubleType)).
      withColumn("reach_000_1min_count", $"reach_000_1min_count".cast(DoubleType)).
      withColumn("Program_Share", $"Program_Share".cast(DoubleType))

    outputDF

  }

  def lineIterator(lines: Iterator[String]): Iterator[String] = {

    var Market: String = "fillerMarket"
    var Target: List[String] = List("fillerTarget1", "fillerTarget2")

    def singleLineParser (line: String): List[String] = {

      var results = new ListBuffer[String]

      parseMarket(line) match {
        case Some(e) => Market = e
        case None =>
      }

      parseTarget(line) match {
        case Some(e) => Target = e
        case None =>
      }

      val parsedLines = line.split(",").length  match {
        case 14 => explodeRecord1(Target, Market, line)
        case 20 => explodeRecord2(Target, Market, line)
        case _ => None
      }

      parsedLines match {
        case Some(e) => e.foreach(splitLine => { results += splitLine })
        case None => None
      }

      results.toList
    }

    lines.flatMap(row => singleLineParser(row))

  }

}
