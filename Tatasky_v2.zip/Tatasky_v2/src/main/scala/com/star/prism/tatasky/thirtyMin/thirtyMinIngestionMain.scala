package com.star.prism.tatasky.thirtyMin

import java.io.File
import java.net.URI

import com.star.prism.tatasky.thirtyMin.Egestors.thirtyMinEgestor
import com.star.prism.tatasky.thirtyMin.Ingestors.thirtyMinIngestor
import com.star.prism.tatasky.thirtyMin.Transformers.thirtyMinTransformer
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.SparkSession

object thirtyMinIngestionMain {

  def main(args: Array[String]): Unit = {

    // get cmd line args

    val configFile = args(0)
    //    implicit val appConf: Config = ConfigFactory.load(configFile)
    implicit val appConf: Config = ConfigFactory.parseFile(new File(configFile)) // uses external config file

    val runYear = args(1)
    val runWeek = args(2)
    val repartitionToMT = args(3)

    if (args.length < 4) {
      throw new IllegalArgumentException("Insufficient argument list")
    }

    // creation of SparkSession
    implicit val spark: SparkSession = createSparkSession(appConf.getString("tatasky.30min.app.name") + " " + runYear + " " + runWeek)

    // set Application Props
    setAppProps()

    // construct paths for read/write
    val formattedWeek = "%02d".format(runWeek.toInt)

    // Fix added to check for file in S3 before reading it
    val loadPathCheck1 =  appConf.getString("ts.30min.input.s3.path.prefix") + s"year=$runYear/week=$formattedWeek/"
    val loadPathCheck2 =  appConf.getString("ts.30min.input.s3.path.prefix") + s"year=$runYear/week=$runWeek/"

    var loadPath = ""

    val uri = new URI(appConf.getString("ts.30min.input.s3.bucket"))

    val checkPath1 = FileSystem.get(uri, spark.sparkContext.hadoopConfiguration).exists(new Path(loadPathCheck1))
    val checkPath2 = FileSystem.get(uri, spark.sparkContext.hadoopConfiguration).exists(new Path(loadPathCheck2))

    if (checkPath1) {
      loadPath = loadPathCheck1
    } else if (checkPath2) {
      loadPath = loadPathCheck2
    }

    val channelNameMapLocation = appConf.getString("ts.channel.revision.mapping")
    val channelAttributesMapLocation = appConf.getString("ts.channel.attributes.mapping")

    val outputLocationYW =  appConf.getString("ts.30min.output.yw.prefix") + appConf.getString("ts.30min.output.yw.folder")

    val inputLocationYW = appConf.getString("ts.30min.output.yw.prefix") + appConf.getString("ts.30min.output.yw.folder") + s"/year=$runYear"
    val outputLocationMT =  appConf.getString("ts.30min.output.mt.prefix") + appConf.getString("ts.30min.output.mt.folder")

    val outputLocationError =  appConf.getString("ts.30min.output.yw.prefix") + appConf.getString("ts.error.output.folder")

    if (repartitionToMT == 0.toString) {

      // do main processing

      val loadDF = new thirtyMinIngestor().dataLoader(loadPath)

      val (df, errorDF) = new thirtyMinTransformer().applythirtyMinTransforms(runYear, runWeek, loadDF, channelNameMapLocation, channelAttributesMapLocation)

      //write to s3
      new thirtyMinEgestor().dataWriter(df, errorDF, outputLocationYW, outputLocationError)

    }

    else {

      // load df from YW partitions
      val df = new thirtyMinIngestor().dataLoaderMT(inputLocationYW, runYear)

      //write to s3 with MT partitions
      new thirtyMinEgestor().dataWriterMT(df, outputLocationMT)

    }

    // close SparkSession
    spark.close()

  }

  def createSparkSession(appName: String): SparkSession = {

    SparkSession
      .builder()
      .appName(appName)
      .enableHiveSupport()
      .config("hive.exec.dynamic.partition", "true")
      .config("hive.exec.dynamic.partition.mode", "nonstrict")
      .getOrCreate

  }

  def setAppProps()(implicit spark: SparkSession): Unit = {

    spark.conf.set("spark.shuffle.service.enabled", "true")
    spark.conf.set("spark.dynamicAllocation.enabled", "true")
    spark.conf.set("spark.dynamicAllocation.initialExecutors","11")
    spark.conf.set("spark.dynamicAllocation.minExecutors", "10")
    spark.conf.set("spark.dynamicAllocation.maxExecutors", "40")
    spark.conf.set("spark.shuffle.blockTransferService", "nio")
    spark.conf.set("spark.kryoserializer.buffer", "70")
    spark.conf.set("spark.driver.extraJavaOptions", "-XX:+UseG1GC")
    spark.conf.set("spark.executor.extraJavaOptions", "-XX:+UseG1GC")
    spark.conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    spark.conf.set("spark.sql.inMemoryColumnarStorage.compressed", "true")
    spark.conf.set("spark.sql.autoBroadcastJoinThreshold", (1024 * 1024 * 50).toString)
    spark.conf.set("spark.broadcast.compress", "true")
    spark.conf.set("spark.shuffle.compress", "true")
    spark.conf.set("spark.shuffle.spill.compress", "true")
    spark.conf.set("spark.io.compression.codec", "org.apache.spark.io.LZ4CompressionCodec")
    spark.conf.set("spark.hadoop.fs.s3a.readahead.range", "10000000")
    spark.conf.set("yarn.scheduler.capacity.node-locality-delay", "0")
    spark.conf.set("hive.metastore.pre.event.listeners", " ")

    spark.sparkContext.setLogLevel("WARN")

  }
}
