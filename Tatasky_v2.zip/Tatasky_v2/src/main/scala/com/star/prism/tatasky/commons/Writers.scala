package com.star.prism.tatasky.commons

import org.apache.spark.sql.{DataFrame, SparkSession}

trait Writers extends Serializable {

  def writer(df: DataFrame, saveMode:String, outputPath: String, partitions: Seq[String])(implicit spark: SparkSession): Unit = {

    df.
      write.
      mode(saveMode).
      partitionBy(partitions:_*).
      option("header", "true").
      parquet(outputPath)

  }

}
