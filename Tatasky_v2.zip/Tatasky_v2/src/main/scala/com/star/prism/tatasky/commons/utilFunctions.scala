package com.star.prism.tatasky.commons

import java.text.SimpleDateFormat
import java.util.Calendar

import org.apache.commons.lang.time.DateUtils

import scala.annotation.tailrec
import scala.collection.mutable.ListBuffer

trait utilFunctions extends Serializable {

  def formatDate: String => String = (dt: String) => {
    try {
      val possibleDateFormats: Array[String] = Array("yyyy-MM-dd", "yyyy/MM/dd", "dd/MM/yyyy", "dd-MM-yyyy")
      val sdf = new SimpleDateFormat("yyyy-MM-dd")
      val outputDate = DateUtils.parseDateStrictly(dt,
        possibleDateFormats)
      sdf.format(outputDate)
    }
    catch {
      case e: Exception => {
        println(e.getMessage)
      }
        ""
    }
  }

  def formatMarket: String => String = (market: String) => market.substring(3,market.length-5)

  def formatTarget: String => String = (target: String) => target.substring(4, target.length)

  def getWeekStartDate: (String, String, Int) => String = (run_year: String, run_week: String, add_date: Int) => {

    val sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val cal = Calendar.getInstance
    var derivedRunWeek = 0
    var derivedRunYear = 0

    if (run_week == "01") {
      derivedRunYear = run_year.toInt - 1
      derivedRunWeek = 52
    } else {
      derivedRunYear = run_year.toInt
      derivedRunWeek = run_week.toInt - 1
    }

    cal.set(Calendar.YEAR, derivedRunYear)
    cal.set(Calendar.WEEK_OF_YEAR, derivedRunWeek)
    cal.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY)
    cal.add(Calendar.DATE, add_date)

    val week_start_date = sdf.format(cal.getTime).substring(0, 10)

    week_start_date
  }

  def regionTransform: String => String = (region:String) => {

    val result = region match {
      case "KARNATAK" => "KARNATAKA"
      case "KERAL" => "KERALA"
      case "MAH / GO" => "MAH / GOA"
      case "ORISS" => "ORISSA"
      case _ => region
    }

    result

  }

  def handleTimeBand:String => String =
    (timeBand: String) => {
      timeBand.split(":")(0).toInt match {
        case hour if hour >= 18 && hour < 23 => "Prime"
        case _                               => "Non Prime"
      }
    }

  def getDayName:String => String = (date: String) => {

    val dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd")
    val dateNameFormat = new java.text.SimpleDateFormat("EEEE")

    val runDate = dateFormat.parse(date)

    val cal = Calendar.getInstance
    cal.setTime(runDate)
    val dayName = dateNameFormat.format(runDate)

    dayName

  }

  def timeTransform: String => String = (time:String) => {

    val splitHour = time.split(":")(0)
    val splitMin = time.split(":")(1)
    val splitSec = time.split(":")(2)
    var resultHour = splitHour

    if (splitHour == "00") resultHour = "24"
    else if (splitHour == "01") resultHour = "25"
    else if (splitHour == "02") resultHour = "26"

    val result = s"$resultHour:$splitMin:$splitSec"

    result
  }


  def roundStartTime: String => String = (startTimeAvg:String) => {

    val splitHour = startTimeAvg.split(":")(0)
    val splitMin = startTimeAvg.split(":")(1)

    val nextHour = "%02d".format(splitHour.toInt + 1)
    var startTimeRound = startTimeAvg

    if (splitMin.toInt >= 15 && splitMin.toInt < 45) {
      startTimeRound = s"$splitHour:30:00"
    }
    else if (splitMin.toInt >= 0 && splitMin.toInt < 15) {
      startTimeRound = s"$splitHour:00:00"
    }
    else if (splitMin.toInt >= 45) {
      startTimeRound = s"$nextHour:00:00"
    }

    startTimeRound
  }


  def twoDigitString(str: String, append: String = ""): String = f"${append}${str.toDouble}%02.0f"

  def fourDigitString(str: String): String = f"${str.toDouble}%04.0f"

  def getPPInputDir(week:String, year: String, append: String = ""): String = s"""${twoDigitString(week, append)}-${fourDigitString(year)}"""


  def buildCondition(filterCondition: List[String], condition:String, columnName: String):String = {

    var listBuffer = new ListBuffer[String]

    @tailrec
    def constructCondition(filterCondition: List[String]): Unit = {
      filterCondition match {
        case Nil => None
        case head :: tail =>
          listBuffer += s"$columnName = \'$head\' $condition "
          constructCondition(tail)
      }
    }

    constructCondition(filterCondition)
    val trimString = listBuffer.toList.mkString("").trim

    trimString.substring(0, trimString.length-2).trim

  }

}
