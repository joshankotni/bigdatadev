package com.star.prism.tatasky.commons

import java.time.Instant

import com.typesafe.config.Config
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, Encoders, SparkSession}

class channelAttributesMapper extends Serializable {

  def mapChannelAttributes(runYear: String, runWeek: String, inputDF: DataFrame, channelNameMapLocation:String, channelAttributesMapLocation: String, source:String, FileType:String)
                          (implicit spark: SparkSession, appConf: Config): (DataFrame, DataFrame) = {

    val loadDF = loadAttributesMapFile(channelAttributesMapLocation)

    val channelAttributesMap = transformAttributesMapFile(runYear, runWeek, loadDF, channelNameMapLocation)

    val (mappedDF, errDF) = mapAttributes(inputDF, channelAttributesMap)

    val errorDF = filterErrorChannels(runYear, runWeek, source, FileType, errDF)

    (mappedDF, errorDF)
  }


  def loadAttributesMapFile(channelAttributesMapLocation: String)(implicit spark: SparkSession, appConf: Config): DataFrame = {

    //load map file
    val loadDF = spark.
      read.
      option("header", "true").
      option("encoding", "UTF-8").
      schema(Encoders.product[channelMappingSchema].schema).
      csv(channelAttributesMapLocation)

    loadDF

  }

  def transformAttributesMapFile(runYear: String, runWeek:String, loadDF: DataFrame, channelNameMapLocation: String)(implicit spark: SparkSession, appConf: Config): DataFrame = {

    import spark.implicits._

    val transformDF = loadDF.
      filter($"year" === runYear && lpad($"week",2,"0") === runWeek).
      withColumn("channelInfo",
        concat( $"main_network", lit("|"), $"genre", lit("|"), $"channel_type", lit("|"), $"format"))

    // get latest channel names for map file
    val getLatestChannelNameTransformDF = new channelMapper().mapLatestChannelName(transformDF, channelNameMapLocation)

    val channelAttributesMap = getLatestChannelNameTransformDF.
      filter("latestChannelName != 'CHANNEL NOT FOUND'").
      select("latestChannelName", "channelInfo").
      distinct()

    channelAttributesMap

  }

  def mapAttributes(inputDF: DataFrame, channelAttributesMap: DataFrame)(implicit spark: SparkSession, appConf: Config): (DataFrame, DataFrame) = {

    import spark.implicits._

    // join with input df and get channel attrbutes info
    val mappedDF = inputDF.
      join(broadcast(channelAttributesMap), Seq("latestChannelName"), "inner").
      withColumn("mappingSplit", split($"channelInfo", "\\|")).
      withColumn("main_network",
        when($"channelInfo" === "NOT FOUND","NOT FOUND").otherwise($"mappingSplit".getItem(0))).
      withColumn("genre",
        when($"channelInfo" === "NOT FOUND","NOT FOUND").otherwise($"mappingSplit".getItem(1))).
      withColumn("channel_type",
        when($"channelInfo" === "NOT FOUND","NOT FOUND").otherwise($"mappingSplit".getItem(2))).
      withColumn("resolution_type",
        when($"channelInfo" === "NOT FOUND","NOT FOUND").otherwise($"mappingSplit".getItem(3))).
      drop("mappingSplit","channelInfo").
      na.fill("NOT FOUND", Seq("main_network", "genre", "channel_type", "resolution_type"))

    val noInfo = mappedDF.
      where(" genre = 'NOT FOUND' or main_network = 'NOT FOUND' or channel_type = 'NOT FOUND' or " +
        "resolution_type = 'NOT FOUND' or genre = 'CHANNEL NOT FOUND' or main_network = 'CHANNEL NOT FOUND' or " +
        "channel_type = 'CHANNEL NOT FOUND' or resolution_type = 'CHANNEL NOT FOUND' ").
      select("channel")

    val errDF = inputDF.
      join(broadcast(channelAttributesMap), Seq("latestChannelName"), "leftanti").select("channel").
      union(noInfo).
      distinct()

    (mappedDF, errDF)

  }


  def filterErrorChannels(runYear: String, runWeek: String, source: String, fileType: String, df:DataFrame)
                         (implicit spark: SparkSession, appConf: Config): DataFrame = {

    // fetch error df (with no channel mapping present)
    val runDate = Instant.now.toString

    val errorDF = df.
      withColumn("run_year", lit(runYear).cast(IntegerType)).
      withColumn("run_week", lit(runWeek).cast(IntegerType)).
      withColumn("source", lit(source)).
      withColumn("file_type", lit(fileType)).
      withColumn("run_date", lit(runDate)).
      select("source", "file_type", "run_year", "run_week", "channel", "run_date").
      distinct()

    errorDF

  }

}
