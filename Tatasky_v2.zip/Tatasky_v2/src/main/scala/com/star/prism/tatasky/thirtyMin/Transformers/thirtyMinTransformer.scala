package com.star.prism.tatasky.thirtyMin.Transformers

import com.star.prism.tatasky.commons.{channelAttributesMapper, channelMapper}
import com.typesafe.config.Config
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}

class thirtyMinTransformer extends Serializable {

  def applythirtyMinTransforms(runYear: String, runWeek: String, loadDF:DataFrame, channelNameMapLocation: String, channelAttributesMapLocation: String)
                              (implicit spark: SparkSession, appConf: Config): (DataFrame, DataFrame) = {

    //apply market/target transforms
    val transformationsDF = applyTransforms(runYear, runWeek, loadDF)

    // channel revision and attributes mapping
    val formattedWeek = "%02d".format(runWeek.toInt)
    val source = "TATASKY"
    val fileType = "30MIN"

    val channelRevisionMappedDF = new channelMapper().mapLatestChannelName(transformationsDF, channelNameMapLocation)

    val (channelAttributesMappedDF, errorDF) = new channelAttributesMapper().
      mapChannelAttributes(runYear, formattedWeek, channelRevisionMappedDF, channelNameMapLocation, channelAttributesMapLocation, source, fileType)

    // transform to redshift schema and fetch the error channels which have no mapping present
    val writeDF = redshiftSchemaTransformer(channelAttributesMappedDF)

    (writeDF, errorDF)

  }

  def applyTransforms(runYear: String, runWeek: String, loadDF:DataFrame)(implicit spark: SparkSession, appConf: Config): DataFrame = {

    import spark.implicits._

    val transformFunc = new transformFunctions()

    // apply market-target transformations and add few columns required for redshift schema
    val transformationsDF = loadDF.
      filter("universe is not null").
      filter("UPPER(universe) != 'UNIVERSE'").
      filter("UPPER(tvr_avgw) != 'TRP (AVGW)'").
      filter("UPPER(tvr_avgw) != 'UNITS'").
      withColumn("universe", udf(transformFunc.formatUniverse).apply(col("universe"))).
      withColumn("target", udf(transformFunc.formatTarget).apply(col("target"))).
      withColumn("universe", transformFunc.regionTransformUDF($"universe")).
      withColumn("week_date", udf(transformFunc.formatDate).apply($"week_date").cast(DateType)).
      withColumn("start_wk_date", lit(transformFunc.getWeekStartDate(runYear, runWeek, 0)).cast(DateType)).
      withColumn("start_time", concat(substring($"daypart",1,2), lit(":"), substring($"daypart",3,2))).
      withColumn("timezone", transformFunc.timezoneUDF($"start_time")).
      withColumn("channel", upper($"channel")).
      withColumn("year", lit(runYear).cast(IntegerType)).
      withColumn("week", lit(runWeek).cast(IntegerType)).
      withColumn("ns_flag", lit(0))

      transformationsDF
  }


  def redshiftSchemaTransformer(df:DataFrame)(implicit spark: SparkSession, appConf: Config): DataFrame = {

    import spark.implicits._

    // transform to redshift schema
    val writeDF = df.
      select($"universe".as("market"),
        $"channel",
        $"target",
        $"week_sun_sat",
        $"week_date",
        $"day",
        $"daypart",
        $"tvr_avgw".cast(DoubleType),
        $"impression_000_avgw".cast(DoubleType),
        $"reach_per_1min_count".cast(DoubleType),
        $"reach_000_1min_count".cast(DoubleType),
        $"share".cast(DoubleType),
        $"year",
        $"week",
        $"timezone",
        $"start_wk_date",
        $"genre",
        $"main_network".as("network"),
        $"channel_type",
        $"ns_flag",
        $"resolution_type",
        $"start_time")

    writeDF
  }

}
