package com.star.prism.tatasky.commons

import org.apache.spark.sql.SparkSession

import scala.annotation.tailrec

class HistoricalChannel(path: String)(implicit spark:SparkSession) {

  def loadFileData: List[String] = {
    spark.read.format("CSV").option("encoding","utf-8").load(path).collect().toList.map(x => x.mkString(","))
  }

  def TSRecentNameToStarHistoricalName(line: List[String]): List[(String, String)] = {
    val filteredLine = line.filterNot(_ == null)
    createMapOfTargetChannelToSourceChannel(filteredLine.tail, filteredLine.head, Nil)
      .reverse
  }

  @tailrec
  final def createMapOfTargetChannelToSourceChannel(inp: List[String], first: String, output: List[(String, String)]):
  List[(String, String)] = inp match {
    case head :: tail => {
      createMapOfTargetChannelToSourceChannel(tail, first, output :+ (head -> first))
    }
    case Nil => output
  }


  def getMap = {
    loadFileData
      .drop(HistoricalChannel.Header)
      .filter(elem => elem.size>0)
      .map(elem => elem.split(",").toList)
      .filter(elem => elem.size>0)
      .map(TSRecentNameToStarHistoricalName)
      .flatten

  }

}

object HistoricalChannel {
  val Header = 1
  val Encoder = "UTF-8"
}
