package com.star.prism.tatasky.pp.Ingestors

import com.star.prism.tatasky.pp.Transformers.{ppdatascehma, ppsummary}
import com.star.prism.tatasky.pp.Transformers.transformFunctions
import com.typesafe.config.Config
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, StringType}
import org.apache.spark.sql.{DataFrame, Encoders, SparkSession}

class PpIngestor extends Serializable {




  def ppdataLoader(path: String)(implicit spark: SparkSession, appConf: Config): DataFrame = {


    import spark.implicits._

    val ppdata = spark.read.format("csv").
      option("delimiter", ",").
      schema(Encoders.product[ppdatascehma].schema).
      load(path).filter($"Duration_min1" rlike "^\\d*$").
      withColumn("filename", input_file_name()).
      withColumn("Start_Time_New",
        when(split($"Start_Time", ":")(0).cast(IntegerType) > 23, concat(concat(concat(concat(lpad((split($"Start_Time", ":")(0).cast(IntegerType) % 24).cast(StringType), 2, "0"), lit(":")), split($"Start_Time", ":")(1)), lit(":")), split($"Start_Time", ":")(2))).otherwise($"Start_Time")).
      drop($"Start_Time").
      withColumn("End_Time_New",
        when(split($"End_Time", ":")(0).cast(IntegerType) > 23, concat(concat(concat(concat(lpad((split($"End_Time", ":")(0).cast(IntegerType) % 24).cast(StringType), 2, "0"), lit(":")), split($"End_Time", ":")(1)), lit(":")), split($"End_Time", ":")(2))).otherwise($"End_Time")).
      drop($"End_Time").
      withColumn("Start_Time_New_Roundoff",
        when((split($"Start_Time_New", ":")(1).cast(IntegerType) > 15) && (split($"Start_Time_New", ":")(1).cast(IntegerType) < 46), concat(split($"Start_Time_New", ":")(0), lit(":30:00"))).
          when((split($"Start_Time_New", ":")(1).cast(IntegerType) > 0) && (split($"Start_Time_New", ":")(1).cast(IntegerType) < 16), concat(split($"Start_Time_New", ":")(0), lit(":00:00"))).
          when(((split($"Start_Time_New", ":")(1).cast(IntegerType) > 45) && (split($"Start_Time_New", ":")(1).cast(IntegerType) <= 59) && (split($"Start_Time_New", ":")(0).cast(IntegerType) < 23)), concat(lpad((split($"Start_Time_New", ":")(0).cast(IntegerType) + 1).cast(StringType), 2, "0"), lit(":00:00"))).
          when(((split($"Start_Time_New", ":")(1).cast(IntegerType) > 45) && (split($"Start_Time_New", ":")(1).cast(IntegerType) <= 59) && (split($"Start_Time_New", ":")(0) === "23")), lit("00:00:00")).
          otherwise(concat(split($"Start_Time_New", ":")(0), lit(":"), split($"Start_Time_New", ":")(1), lit(":00")))).
      withColumn("End_Time_New_Roundoff",
        when((split($"End_Time_New", ":")(1).cast(IntegerType) > 15) && (split($"End_Time_New", ":")(1).cast(IntegerType) < 46), concat(split($"End_Time_New", ":")(0), lit(":30:00"))).
          when((split($"End_Time_New", ":")(1).cast(IntegerType) > 0) && (split($"End_Time_New", ":")(1).cast(IntegerType) < 16), concat(split($"End_Time_New", ":")(0), lit(":00:00"))).
          when(((split($"End_Time_New", ":")(1).cast(IntegerType) > 45) && (split($"End_Time_New", ":")(1).cast(IntegerType) <= 59) && (split($"End_Time_New", ":")(0).cast(IntegerType) < 23)), concat(lpad((split($"End_Time_New", ":")(0).cast(IntegerType) + 1).cast(StringType), 2, "0"), lit(":00:00"))).
          when(((split($"End_Time_New", ":")(1).cast(IntegerType) > 45) && (split($"End_Time_New", ":")(1).cast(IntegerType) <= 59) && (split($"End_Time_New", ":")(0) === "23")), lit("00:00:00")).
          otherwise(concat(split($"End_Time_New", ":")(0), lit(":"), split($"End_Time_New", ":")(1), lit(":00")))).as("ppdata")

    val Market_load = spark.read.format("csv").
      option("header", "true").
      option("delimiter", ",").
      load(path).
      withColumn("filename", input_file_name()).
      filter($"Universe" like "*%").
      withColumn("test", when($"Universe" like "%All%", "Y").otherwise("N")).
      withColumn("Market", when(($"test"  like "Y"),lit($"Universe"))).
      select("filename","Market").filter($"Market" isNotNull).as("Market_load")
    val Target_load = spark.read.format("csv").
      option("header", "true").
      option("delimiter", ",").
      load(path).
      withColumn("filename", input_file_name()).
      filter($"Universe" like "*%").
      withColumn("test", when($"Universe" like "%All%", "Y").otherwise("N")).
      withColumn("Target_new", when(($"test" like "N"),lit($"Universe"))).
      select("filename","Target_new").filter($"Target_new" isNotNull).as("Target_load")
    //filter($"Market" isNotNull).
    // filter($"Target_new" isNotNull)
    val Tm_load= Market_load.join(Target_load,col("Market_load.filename") === col("Target_load.filename"), "inner").
      select("Market_load.filename","Market","Target_new").as("Tm_load")

    val df_load1 = Tm_load.join(ppdata,col("ppdata.filename") === col("Tm_load.filename"), "inner")

    df_load1

  }

  def ppsportsLoader(path: String)(implicit spark: SparkSession, appConf: Config): DataFrame = {


    import spark.implicits._

    val sports_load = spark.read.format("csv").
      option("delimiter", ",").
      schema(Encoders.product[ppsummary].schema).option("delimiter", ",").load(path).
      filter("UPPER(universe) != 'UNIVERSE'")
      //withColumn("dt", udf(new transformFunctions().formatDate).apply(col("date"))).
      //withColumn("market", udf(new transformFunctions().formatUniverse).apply(col("universe"))).
      //withColumn("target_new", udf(new transformFunctions().formatTarget).apply(col("target")))


    sports_load

  }

  def ppnonportsLoader(path: String, df: DataFrame)(implicit spark: SparkSession, appConf: Config): DataFrame = {

    //val fmt_week = "%02d".format(run_week.toInt)
    //val load_path = appConf.getString("ts.pp.input.s3.path.prefix") + s"year=$run_year/week=$fmt_week/"

    // data load
    import spark.implicits._
    var df_load =spark.emptyDataFrame
    var flag = 0
    try{
      df_load = spark.
        read.format("csv").
        option("header", "true").
        option("encoding", "UTF-8").
        schema(Encoders.product[ppsummary].schema).option("delimiter", ",").load(path).
        filter("UPPER(universe) != 'UNIVERSE'")
        //.
        //withColumn("dt", udf(new transformFunctions().formatDate).apply(col("date"))).
        //withColumn("market", udf(new transformFunctions().formatUniverse).apply(col("universe"))).
        //withColumn("target_new", udf(new transformFunctions().formatTarget).apply(col("target")))
        .union(df)
    }catch{
      case e: org.apache.spark.sql.AnalysisException =>{
        println(s"NO Non Sports Summary Files For This Run")
        flag = 1
      }
      case unknown: Exception => {
        println(unknown.getMessage)
        flag = 1
      }
    }
    if (flag == 1) {
      df_load = df
    }

    df_load



  }

  def dataLoaderMT(inputLocationYW: String, year:String) (implicit spark: SparkSession, appConf: Config): DataFrame = {

    spark.read.parquet(inputLocationYW).withColumn("year",lit(year).cast(IntegerType))
  }

}
