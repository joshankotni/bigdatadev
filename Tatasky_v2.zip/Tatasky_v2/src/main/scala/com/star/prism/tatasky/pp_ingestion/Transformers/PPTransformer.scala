package com.star.prism.tatasky.pp_ingestion.Transformers

import com.star.prism.tatasky.commons.Mappers.{channelMapper, channelRevisionMapper}
import com.star.prism.tatasky.commons.utilFunctions
import com.typesafe.config.Config
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}

trait PPTransformer extends utilFunctions with channelMapper with channelRevisionMapper with Serializable {

  def ppTransformer(runYear: String, runWeek: String, loadDF: DataFrame, sportsSummaryInput: DataFrame)
                   (implicit spark: SparkSession, appConf: Config): DataFrame = {

    val source = appConf.getString("ts.pp.source")
    val fileType = appConf.getString("ts.pp.fileType")
    val formattedWeek = "%02d".format(runWeek.toInt)

    redshiftSchemaTransformer( // Post Merge Redshift Schema transforms
      mapChannelAttributes( // Channel Mapping
        runYear,
        formattedWeek,
        mapLatestChannelName( // Channel Revision Mapping
          ltMergeTransformer( // L/T Merge
            preMergeTransformer(loadDF), //apply market/target transforms
            preMergeTransformerSportsSummary(sportsSummaryInput)     //apply market/target transforms
          )
        ), source, fileType),
      runYear, runWeek
    )

  }

  def preMergeTransformer(loadDF:DataFrame)(implicit spark: SparkSession, appConf: Config): DataFrame = {

    // apply market-target-date transformations and add few columns required for redshift schema
    loadDF.
      withColumn("market", udf(formatMarket).apply(col("market"))).
      withColumn("target", udf(formatTarget).apply(col("target"))).
      withColumn("market", udf(regionTransform).apply(col("market"))).
      drop("week_sat_fri").
      drop("weekday")

  }

  def preMergeTransformerSportsSummary(loadDF:DataFrame)(implicit spark: SparkSession, appConf: Config): DataFrame = {

    import spark.implicits._

    // apply market-target-date transformations for joining with PP Data
    loadDF.
      filter("week != 'Week'").
      withColumn("week_date", udf(formatDate).apply($"date")).
      withColumn("dur_min_sum", ($"duration_sec"/60).cast(IntegerType)).
      withColumn("market", udf(formatMarket).apply(col("market"))).
      withColumn("target", udf(formatTarget).apply(col("target"))).
      withColumn("market", udf(regionTransform).apply(col("market"))).
      drop("year").
      drop("week").
      drop("weekday").
      drop("date").
      drop("duration_sec")

  }

  def ltMergeTransformer(ppDF: DataFrame, sportsSummaryDF: DataFrame)
                        (implicit spark: SparkSession, appConf: Config): DataFrame = {

    import spark.implicits._

    val ltSessionizeDF = ppDF.
      where("prog_title LIKE 'L/T%'").
      select(
        "market",
        "target",
        "channel",
        "prog_title",
        "type_subject",
        "week_date",
        "start_time",
        "end_time"
      ).
      groupBy("market", "target", "channel", "prog_title", "type_subject", "week_date").
      agg(min($"start_time").as("start_time"), max($"end_time").as("end_time"))

    val joinColumns = Seq("market", "target", "channel", "prog_title", "type_subject", "week_date")

    val ltMergedDF = ltSessionizeDF.
      join(sportsSummaryDF, joinColumns, "inner").
      select(
        "market",
        "target",
        "channel",
        "prog_title",
        "type_subject",
        "week_date",
        "start_time",
        "end_time",
        "dur_min_sum",
        "tvr_avgw",
        "impression_000_avgw",
        "reach_per_1min_count",
        "reach_000_1min_count",
        "Program_Share"
      )

    val nonMergedDF = ppDF.
      join(sportsSummaryDF, joinColumns, "leftanti").
      select(
        "market",
        "target",
        "channel",
        "prog_title",
        "type_subject",
        "week_date",
        "start_time",
        "end_time",
        "dur_min_sum",
        "tvr_avgw",
        "impression_000_avgw",
        "reach_per_1min_count",
        "reach_000_1min_count",
        "Program_Share"
      )

    // union of merged and non-merged data
    val outputPPDF = nonMergedDF.union(ltMergedDF)

    outputPPDF

  }

  def redshiftSchemaTransformer(df:DataFrame, runYear: String, runWeek:String)
                               (implicit spark: SparkSession, appConf: Config): DataFrame = {

    import spark.implicits._

    // transform to redshift schema
    df.
      withColumn("ns_flag", lit(0)).
      withColumn("channel_org", lit("No")).
      withColumn("day", udf(getDayName).apply($"week_date")).
      withColumn("start_wk_date", lit(getWeekStartDate(runYear, runWeek, 0)).cast(DateType)).
      withColumn("year", lit(runYear).cast(IntegerType)).
      withColumn("week", lit(runWeek).cast(IntegerType)).
      withColumn("week_sun_sat", concat(lit(runYear),lit("w"),lit("%02d".format(runWeek.toInt)))).
      withColumn("start_time_round", udf(roundStartTime).apply($"start_time")).
      withColumn("time_zone", udf(handleTimeBand).apply(col("start_time_round"))).
      withColumn("channel", upper($"channel")). // Should be done only after channel mapping
      select(
      $"channel",
      $"week_date",
      $"week_sun_sat",
      $"prog_title",
      $"type_subject",
      $"day",
      $"start_time",
      $"end_time",
      $"dur_min_sum".cast(LongType),
      $"tvr_avgw".cast(DoubleType),
      $"impression_000_avgw".cast(DoubleType),
      $"reach_per_1min_count".cast(DoubleType),
      $"reach_000_1min_count".cast(DoubleType),
      $"Program_Share".as("program_share").cast(DoubleType),
      $"market",
      $"target",
      $"year",
      $"week",
      $"start_time_round",
      $"time_zone",
      $"start_wk_date",
      $"genre",
      $"main_network".as("network"),
      $"channel_type",
      $"ns_flag",
      $"resolution_type",
      $"channel_org"
    )

  }

}
