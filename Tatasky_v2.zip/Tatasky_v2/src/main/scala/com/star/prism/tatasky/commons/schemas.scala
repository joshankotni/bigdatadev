package com.star.prism.tatasky.commons

case class channelRevisionMappingSchema(channelCommon: String,
                                        channel1: String,
                                        channel2: String,
                                        channel3: String,
                                        channel4: String,
                                        channel5: String,
                                        channel6: String)

case class channelMappingSchema(channel: String,
                                week: String,
                                year: String,
                                genre: String,
                                main_network: String,
                                channel_type: String,
                                format: String)
