package com.star.prism.tatasky.pp_prevalidation

import java.io.File

import com.star.prism.tatasky.commons.{Loaders, Writers}
import com.star.prism.tatasky.pp_prevalidation.Transformers.PPPVTransformer
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql.SparkSession

object PPPVMain extends PPPVTransformer with Loaders with Writers with Serializable {

  def main(args: Array[String]) {

//    val run_year = args(0)
//    val run_week = args(1)

    val configFile = System.getProperty("config.file")
    implicit val appConf: Config = ConfigFactory.parseFile(new File(configFile))

    val run_year = appConf.getString("ts.pp.pre-validation.year")
    val run_week = appConf.getString("ts.pp.pre-validation.week")

    val formattedWeek = "%02d".format(run_week.toInt)
    val run_week_string = s"w$formattedWeek-$run_year/"

    implicit val spark: SparkSession = createSparkSession(appConf.getString("ts.pp.pre-validation.name") + " - " + run_year + " - " + run_week)
//    spark.sparkContext.hadoopConfiguration.setInt("mapreduce.input.fileinputformat.split.minsize", 500*1024*1024) // Moved to config file

    val inputRDD = dataLoader(appConf.getString("ts.pp.pre-validation.input-path") + run_week_string)
    val outputDF = lineParser(inputRDD, run_year, run_week).repartition(5)

    writer(outputDF,
      "append",
      appConf.getString("ts.pp.pre-validation.output-path"),
      Seq("year", "week", "week_date"))

  }

  def createSparkSession(appName: String): SparkSession = {

    SparkSession
      .builder()
      .appName(appName)
      .enableHiveSupport()
      .config("hive.exec.dynamic.partition", "true")
      .config("hive.exec.dynamic.partition.mode", "nonstrict")
      .getOrCreate

  }

}
