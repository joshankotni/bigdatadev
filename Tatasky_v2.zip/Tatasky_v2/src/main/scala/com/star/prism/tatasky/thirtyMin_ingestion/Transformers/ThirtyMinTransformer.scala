package com.star.prism.tatasky.thirtyMin_ingestion.Transformers

import com.star.prism.tatasky.commons.Mappers.{channelMapper, channelRevisionMapper}
import com.star.prism.tatasky.commons.utilFunctions
import com.typesafe.config.Config
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}

trait ThirtyMinTransformer extends utilFunctions with channelMapper with channelRevisionMapper with Serializable {

  def ThirtyMinTransformer(runYear: String, runWeek: String, loadDF: DataFrame)
                          (implicit spark: SparkSession, appConf: Config): DataFrame = {

    val source = appConf.getString("ts.thirtymin.source")
    val fileType = appConf.getString("ts.thirtymin.fileType")
    val formattedWeek = "%02d".format(runWeek.toInt)

    redshiftSchemaTransformer(     // Post Merge Redshift Schema transforms
      mapChannelAttributes( // Channel Mapping
        runYear,
        formattedWeek,
        mapLatestChannelName( // Channel Revision Mapping
          applyThirtyMinTranforms(  //apply market/target/date transforms
            loadDF,
            runYear,
            runWeek
          )
        ),
        source,
        fileType)
    )

  }

  def applyThirtyMinTranforms(loadDF:DataFrame, runYear: String, runWeek:String)
                             (implicit spark: SparkSession, appConf: Config): DataFrame = {

    import spark.implicits._

    // apply market-target-date transformations and add few columns required for redshift schema
    loadDF.
      filter("market is not null").
      filter("UPPER(market) != 'UNIVERSE'").
      filter("UPPER(tvr_avgw) != 'TRP (AVGW)'").
      filter("UPPER(tvr_avgw) != 'UNITS'").
      withColumn("market", udf(formatMarket).apply(col("market"))).
      withColumn("target", udf(formatTarget).apply(col("target"))).
      withColumn("market", udf(regionTransform).apply(col("market"))).
      withColumn("week_date", udf(formatDate).apply($"date").cast(DateType)).
      withColumn("day", udf(getDayName).apply($"week_date")).
      withColumn("start_wk_date", lit(getWeekStartDate(runYear, runWeek, 0)).cast(DateType)).
      withColumn("start_time", concat(substring($"daypart",1,2), lit(":"), substring($"daypart",3,2))).
      withColumn("timezone", udf(handleTimeBand).apply(col("start_time"))).
      withColumn("ns_flag", lit(0)).
      withColumn("year", lit(runYear).cast(IntegerType)).
      withColumn("week", lit(runWeek).cast(IntegerType)).
      withColumn("week_sun_sat", concat(lit(runYear),lit("w"),lit("%02d".format(runWeek.toInt)))).
      drop("week_sat_fri").
      drop("weekday").
      drop("date")

  }


  def redshiftSchemaTransformer(df:DataFrame)(implicit spark: SparkSession, appConf: Config): DataFrame = {

    import spark.implicits._

    // transform to redshift schema
    df.
      withColumn("channel", upper($"channel")). // Should be done only after channel mapping
      select(
      $"market",
      $"channel",
      $"target",
      $"week_sun_sat",
      $"week_date",
      $"day",
      $"daypart",
      $"tvr_avgw".cast(DoubleType),
      $"impression_000_avgw".cast(DoubleType),
      $"reach_per_1min_count".cast(DoubleType),
      $"reach_000_1min_count".cast(DoubleType),
      $"share".cast(DoubleType),
      $"year",
      $"week",
      $"timezone",
      $"start_wk_date",
      $"genre",
      $"main_network".as("network"),
      $"channel_type",
      $"ns_flag",
      $"resolution_type",
      $"start_time"
    )

  }

}
