package com.star.prism.tatasky.pp
import java.io.File

import com.star.prism.tatasky.pp.Egestors.ppegestor
import com.star.prism.tatasky.pp.Ingestors.PpIngestor
import com.star.prism.tatasky.pp.Transformers.ppTransformer
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql.SparkSession

object PpIngestionMain {
  def main(args: Array[String]): Unit = {

    val configFile = args(0)
    //    implicit val appConf: Config = ConfigFactory.load(configFile)
    implicit val appConf: Config = ConfigFactory.parseFile(new File(configFile)) // uses external config file

    val run_year = args(1)
    val run_week = args(2)
    val repartitionToMT = args(3)
    if (args.length < 4) {
      throw new IllegalArgumentException("Insufficient argument list")
    }


    // creation of SparkSession
    implicit val spark:SparkSession = createSparkSession("tatasky_pp_ingestion" + " " + run_year + " " + run_week)

    // set Application Props

    setAppProps()
    //Load the pp data
    val formattedWeek = "%02d".format(run_week.toInt)
    //Load the pp data
    val datapath = appConf.getString("ts.pp.input.s3.path.prefix") + s"pp/year=$run_year/week=$formattedWeek/"
    //load sports summary data
    val sportspath = appConf.getString("ts.pp.input.s3.path.prefix") + s"/LiveSports_Summary/Sports/year=$run_year/week=$formattedWeek/"
    val nonsportspath = appConf.getString("ts.pp.input.s3.path.prefix") + s"/LiveSports_Summary/Non sports/year=$run_year/week=$formattedWeek/"
    val yearweekoutput = appConf.getString("ts.pp.output.yw.prefix") + appConf.getString("ts.pp.output.yw.folder")
    val inputLocationYW = appConf.getString("ts.pp.output.yw.prefix") + appConf.getString("ts.pp.output.yw.folder") +s"/year=$run_year"
    val mtoutput = appConf.getString("ts.pp.output.yw.prefix") + appConf.getString("ts.pp.output.mt.folder")
    val channelNameMapLocation = appConf.getString("ts.channel.revision.mapping")
    val channelAttributesMapLocation = appConf.getString("ts.channel.attributes.mapping")
    val any_target_name= appConf.getString("ts.any.target.name")
    val yearweekerror = appConf.getString("ts.pp.output.yw.prefix") + appConf.getString("ts.error.output.folder")
    val yearweekerrorcounts = appConf.getString("ts.pp.output.yw.prefix") + appConf.getString("ts.error.counts.output.folder")
    if (repartitionToMT == 0.toString) {
      // load pp data
      val load_df = new PpIngestor().ppdataLoader(datapath)
      //load livesports summary
      val sports_df = new PpIngestor().ppsportsLoader(sportspath)
      //load live non sports summary
      val nonsports_df = new PpIngestor().ppnonportsLoader(nonsportspath, sports_df)
      //l/t merge and ammping channel information
      val (ppjoined_latest, countdf, errordf) = new ppTransformer().ppmap(load_df, nonsports_df, channelNameMapLocation, channelAttributesMapLocation, run_year, formattedWeek, "TATASKY", any_target_name)
      //writing into output
      new ppegestor().dataWriter(ppjoined_latest, countdf, errordf, yearweekoutput, yearweekerror, yearweekerrorcounts)
    } else {
      //load year week date data
      val df = new PpIngestor().dataLoaderMT(inputLocationYW, run_year)
      //partition based on market and traget
      new ppegestor().dataWriterMT(df, mtoutput)

    }

    //close spark session
    spark.close()

  }

  def createSparkSession(appName: String): SparkSession = {

    SparkSession
      .builder()
      .appName(appName)
      .enableHiveSupport()
      .config("hive.exec.dynamic.partition", "true")
      .config("hive.exec.dynamic.partition.mode", "nonstrict")
      .getOrCreate

  }

  def setAppProps()(implicit spark: SparkSession): Unit = {

    spark.conf.set("spark.shuffle.service.enabled", "true")
    spark.conf.set("spark.dynamicAllocation.enabled", "true")
    spark.conf.set("spark.dynamicAllocation.initialExecutors","11")
    spark.conf.set("spark.dynamicAllocation.minExecutors", "10")
    spark.conf.set("spark.dynamicAllocation.maxExecutors", "40")
    spark.conf.set("spark.shuffle.blockTransferService", "nio")
    spark.conf.set("spark.kryoserializer.buffer", "70")
    spark.conf.set("spark.driver.extraJavaOptions", "-XX:+UseG1GC")
    spark.conf.set("spark.executor.extraJavaOptions", "-XX:+UseG1GC")
    spark.conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    spark.conf.set("spark.sql.inMemoryColumnarStorage.compressed", "true")
    spark.conf.set("spark.sql.autoBroadcastJoinThreshold", (1024 * 1024 * 50).toString)
    spark.conf.set("spark.broadcast.compress", "true")
    spark.conf.set("spark.shuffle.compress", "true")
    spark.conf.set("spark.shuffle.spill.compress", "true")
    spark.conf.set("spark.io.compression.codec", "org.apache.spark.io.LZ4CompressionCodec")
    spark.conf.set("spark.hadoop.fs.s3a.readahead.range", "10000000")
    spark.conf.set("yarn.scheduler.capacity.node-locality-delay", "0")
    spark.conf.set("hive.metastore.pre.event.listeners", " ")

    spark.sparkContext.setLogLevel("WARN")

  }

}
