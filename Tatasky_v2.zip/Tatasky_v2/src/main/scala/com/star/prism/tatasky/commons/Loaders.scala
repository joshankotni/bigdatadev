package com.star.prism.tatasky.commons

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Encoders, SparkSession}

import scala.reflect.runtime.universe.TypeTag

trait Loaders extends Serializable {

  def dataLoader[T <: Product: TypeTag](loadPath: String, fileType:FileType)(implicit spark: SparkSession): DataFrame = {

    val mapping = Encoders.product[T]

    fileType match {
      case PARQUET => spark.read.parquet(loadPath)
      case CSV => spark.read.
        schema(mapping.schema).
        option("header", "true").
        option("encoding", "UTF-8").
        csv(loadPath)
    }

  }

  def dataLoader(loadPath: String)(implicit spark: SparkSession): RDD[String] = spark.sparkContext.textFile(loadPath)

}
