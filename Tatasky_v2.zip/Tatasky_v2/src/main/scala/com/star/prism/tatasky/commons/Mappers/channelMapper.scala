package com.star.prism.tatasky.commons.Mappers

import java.time.Instant

import com.star.prism.tatasky.commons._
import com.typesafe.config.Config
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession}

trait channelMapper extends channelRevisionMapper with Loaders with Serializable {

  def mapChannelAttributes(runYear: String, runWeek: String, inputDF: DataFrame, source: String, fileType: String)
                          (implicit spark: SparkSession, appConf: Config): DataFrame = {

    val loadMappingDF = dataLoader[channelMappingSchema](appConf.getString("ts.channel-mapping-path"), CSV)
    val channelAttributesMap = transformMappingFile(runYear, runWeek, loadMappingDF)

    val revisedNameMap = mapLatestChannelName(channelAttributesMap).
      filter("latestChannelName != 'NOT FOUND'").
      select("latestChannelName", "channelInfo").
      distinct()

    val (mappedDF, errDF) = mapAttributes(inputDF, revisedNameMap)
    val errorDF = filterErrorChannels(runYear, runWeek, errDF, source, fileType)

    //(mappedDF, errorDF) // Error DF not required for now, provision is available
    mappedDF

  }

  def transformMappingFile(runYear: String, runWeek:String, loadDF: DataFrame)
                          (implicit spark: SparkSession, appConf: Config): DataFrame = {

    import spark.implicits._

    loadDF.
      filter($"year" === runYear && lpad($"week",2,"0") === runWeek).
      withColumn("channelInfo",
        concat( $"main_network", lit("|"), $"genre", lit("|"), $"channel_type", lit("|"), $"format")).
      select("channel", "channelInfo")

  }

  def mapAttributes(inputDF: DataFrame, channelAttributesMap: DataFrame)
                   (implicit spark: SparkSession, appConf: Config): (DataFrame, DataFrame) = {

    import spark.implicits._

    // join with input df and get channel attributes info
    // use joinType inner to exclude records whose mapping is not present in channel mapping. Use left joinType to include them with mapping values as NOT FOUND
    val mappedDF = inputDF.
      join(broadcast(channelAttributesMap), Seq("latestChannelName"), "left").
      withColumn("mappingSplit", split($"channelInfo", "\\|")).
      withColumn("main_network",
        when($"channelInfo" === "NOT FOUND","NOT FOUND").otherwise($"mappingSplit".getItem(0))).
      withColumn("genre",
        when($"channelInfo" === "NOT FOUND","NOT FOUND").otherwise($"mappingSplit".getItem(1))).
      withColumn("channel_type",
        when($"channelInfo" === "NOT FOUND","NOT FOUND").otherwise($"mappingSplit".getItem(2))).
      withColumn("resolution_type",
        when($"channelInfo" === "NOT FOUND","NOT FOUND").otherwise($"mappingSplit".getItem(3))).
      drop("mappingSplit","channelInfo").
      na.fill("NOT FOUND", Seq("main_network", "genre", "channel_type", "resolution_type"))

    // Find Unmapped Channels
    val noInfo = mappedDF.
      where(" genre = 'NOT FOUND' or main_network = 'NOT FOUND' or channel_type = 'NOT FOUND' or " +
        "resolution_type = 'NOT FOUND'").
      select("channel")

    val errDF = inputDF.
      join(broadcast(channelAttributesMap), Seq("latestChannelName"), "leftanti").select("channel").
      union(noInfo).
      distinct()

    (mappedDF, errDF)

  }

  def filterErrorChannels(runYear: String, runWeek: String, df:DataFrame, source: String, fileType: String)
                         (implicit spark: SparkSession, appConf: Config): DataFrame = {

    // fetch error df (with no channel mapping present)
    val runDate = Instant.now.toString

    val errorDF = df.
      withColumn("run_year", lit(runYear).cast(IntegerType)).
      withColumn("run_week", lit(runWeek).cast(IntegerType)).
      withColumn("source", lit(source)).
      withColumn("file_type", lit(fileType)).
      withColumn("run_date", lit(runDate)).
      select("source", "file_type", "run_year", "run_week", "channel", "run_date").
      distinct()

    errorDF

  }

}
