package com.star.prism.tatasky.pp.Egestors

import com.typesafe.config.Config
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

class ppegestor extends Serializable {

  def dataWriter(df: DataFrame, errorDF:DataFrame,countDF:DataFrame, outputLocationYW: String, outputLocationError:String, outputLocationErrorCounts:String)
                (implicit spark: SparkSession, appConf: Config): Unit = {

     df.
      repartition(1).
      write.
      mode("append").
       partitionBy("year", "week", "week_date").
      parquet(outputLocationYW)

    if (errorDF.head(1).nonEmpty) {

      errorDF.
        repartition(1).
        write.
        mode("append").
        partitionBy("source", "file_type").
        option("header", "true").
        csv(outputLocationError)

    }

    countDF.
      repartition(1).
      write.
      mode("append").
      partitionBy("source", "file_type").
      option("header", "true").
      csv(outputLocationErrorCounts)

    }

  def dataWriterMT(df: DataFrame, outputLocationMT: String) (implicit spark: SparkSession, appConf: Config): Unit = {

    df.
      repartition(4).
      write.
      mode("append").
      partitionBy("market", "target").
      parquet(outputLocationMT)

  }



}
