package com.star.prism.tatasky.commons

trait FileType

case object PARQUET extends FileType

case object CSV extends FileType

case object ORC extends FileType
