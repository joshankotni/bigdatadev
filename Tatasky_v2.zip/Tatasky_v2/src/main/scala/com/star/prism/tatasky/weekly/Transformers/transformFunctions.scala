package com.star.prism.tatasky.weekly.Transformers

import java.util.Calendar

import org.apache.spark.sql.functions._

class transformFunctions extends Serializable {

  def formatUniverse: String => String = (universe: String) => {
    try {
      if (universe.substring(3, universe.length).replaceAll("\\[All\\]", "").toUpperCase() == " ALL INDIA"){
        "ALL INDIA"
      }
      else if (universe.substring(3, universe.length).replaceAll("\\[All\\]", "").toUpperCase().contains("%ODISHA%")){
        "ORISSA"
      }
      else{
        universe.substring(3, universe.length).replaceAll("\\[All\\]", "").toUpperCase()
      }
    }
    catch {
      case e: Exception => {
        println(e.getMessage)
      }
        ""
    }
  }

  def formatTarget: String => String = (target: String) => {
    try {
      target.substring(4, target.length)
    }
    catch {
      case e: Exception => {
        println(e.getMessage)
      }
        ""
    }
  }

  def getWeekStartDate: (String, String, Int) => String = (run_year: String, run_week: String, add_date: Int) => {

    val sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val cal = Calendar.getInstance
    var derivedRunWeek = 0
    var derivedRunYear = 0

    if (run_week == "01") {
      derivedRunYear = run_year.toInt - 1
      derivedRunWeek = 52
    } else {
      derivedRunYear = run_year.toInt
      derivedRunWeek = run_week.toInt - 1
    }

    cal.set(Calendar.YEAR, derivedRunYear)
    cal.set(Calendar.WEEK_OF_YEAR, derivedRunWeek)
    cal.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY)
    cal.add(Calendar.DATE, add_date)

    val week_start_date = sdf.format(cal.getTime).substring(0, 10)

    week_start_date
  }


  def regionTransform: String => String = (region: String) => {

    var result = ""

    if (region == "KARNATAK") result = "KARNATAKA"
    else if (region == "KERAL") result = "KERALA"
    else if (region == "MAH / GO") result = "MAH / GOA"
    else if (region == "ORISS") result = "ORISSA"
    else if (region == "ALL INDIA") result = " ALL INDIA"
    else result = region

    result
  }

  val regionTransformUDF = udf(regionTransform(_ :String))

}
