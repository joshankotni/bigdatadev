package com.star.prism.tatasky.weekly.Transformers

case class weeklyInputSchema(universe: String,
                             target: String,
                             channel: String,
                             year_week: String,
                             daypart: String,
                             trp_avgw: String,
                             impression_in_000_avgw: String,
                             min_1_count_per: String,
                             min_1_count: String,
                             share: String)

