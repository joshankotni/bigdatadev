package com.star.prism.tatasky.thirtyMin_ingestion

import java.io.File

import com.star.prism.tatasky.commons.{CSV, Loaders, Writers, utilFunctions}
import com.star.prism.tatasky.schemas.thirtyMin.thirtyMinSchema
import com.star.prism.tatasky.thirtyMin_ingestion.Transformers.ThirtyMinTransformer
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

import scala.collection.JavaConverters._

object ThirtyMinIngestionMain extends Loaders with ThirtyMinTransformer with Writers with utilFunctions with Serializable {

  def main(args: Array[String]) {

    val configFile = System.getProperty("config.file")
    implicit val appConf: Config = ConfigFactory.parseFile(new File(configFile)) // uses external config file

    val run_year = appConf.getString("ts.thirtymin.year")
    val run_week = appConf.getString("ts.thirtymin.week")

    implicit val spark: SparkSession = createSparkSession(appConf.getString("ts.thirtymin.name") + " - " + run_year + " - " + run_week)
    spark.sparkContext.setLogLevel("WARN")

    val formattedWeek = "%02d".format(run_week.toInt)
    val run_week_string = s"w$formattedWeek-$run_year/"
    val filterTargets = appConf.getStringList("ts.thirtymin.tgFilter").asScala.toList

    val inputPath = appConf.getString("ts.thirtymin.input-path") + run_week_string
    val outputPathYWD = appConf.getString("ts.thirtymin.output-path-ywd")

    val thirtyMinInputDF = dataLoader[thirtyMinSchema](inputPath, CSV).filter(buildCondition(filterTargets, "OR", "target"))

    val thirtyMinOutput = ThirtyMinTransformer(run_year, run_week, thirtyMinInputDF).
      repartition(400, col("year"), col("week"), col("week_date"))

    writer(thirtyMinOutput, "append", outputPathYWD, Seq("year", "week", "week_date"))

  }

  def createSparkSession(appName: String): SparkSession = {

    SparkSession
      .builder()
      .appName(appName)
      .enableHiveSupport()
      .config("hive.exec.dynamic.partition", "true")
      .config("hive.exec.dynamic.partition.mode", "nonstrict")
      .getOrCreate

  }

}
