package com.star.prism.tatasky.pp_ingestion

import java.io.File

import com.star.prism.tatasky.commons._
import com.star.prism.tatasky.pp_ingestion.Transformers.PPTransformer
import com.star.prism.tatasky.schemas.pp.{ppSchema, ppSummary}
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import com.star.prism.tatasky.commons.{Loaders, Writers}

import scala.collection.JavaConverters._

object PPIngestionMain extends Loaders with PPTransformer with Writers with utilFunctions with Serializable {

  def main(args: Array[String]) {

    val configFile = System.getProperty("config.file")
    implicit val appConf: Config = ConfigFactory.parseFile(new File(configFile)) // uses external config file

    val run_year = appConf.getString("ts.pp.year")
    val run_week = appConf.getString("ts.pp.week")

    implicit val spark: SparkSession = createSparkSession(appConf.getString("ts.pp.name") + " - " + run_year + " - " + run_week)
    spark.sparkContext.setLogLevel("WARN")

    val formattedWeek = "%02d".format(run_week.toInt)
    val run_week_string = s"w$formattedWeek-$run_year/"
    val filterTargets = appConf.getStringList("ts.pp.tgFilter").asScala.toList

    val inputPath = appConf.getString("ts.pp.input-path") + s"/year=$run_year/week=$run_week/"
    val outputPathYWD = appConf.getString("ts.pp.output-path-ywd")

    val sportsSummaryPathSports = appConf.getString("ts.pp.sportsSummary-input-path") + run_week_string + "sports"
    val sportsSummaryPathNonSports = appConf.getString("ts.pp.sportsSummary-input-path") + run_week_string + "non-sports"

    val ppPVInputData = dataLoader[ppSchema](inputPath, PARQUET).filter(buildCondition(filterTargets, "OR", "target"))
    val sportsSummarySportsInput = dataLoader[ppSummary](sportsSummaryPathSports, CSV)
    val sportsSummaryNonSportsInput = dataLoader[ppSummary](sportsSummaryPathNonSports, CSV)
    val sportsSummaryInput = sportsSummarySportsInput.union(sportsSummaryNonSportsInput)

    val ppOutput = ppTransformer(run_year, run_week, ppPVInputData, sportsSummaryInput).
      repartition(400, col("year"), col("week"), col("week_date"))

    writer(ppOutput, "append", outputPathYWD,Seq("year", "week", "week_date"))

  }

  def createSparkSession(appName: String): SparkSession = {

    SparkSession
      .builder()
      .appName(appName)
      .enableHiveSupport()
      .config("hive.exec.dynamic.partition", "true")
      .config("hive.exec.dynamic.partition.mode", "nonstrict")
      .getOrCreate

  }

}
