package com.star.prism.tatasky.pp.Transformers

import com.star.prism.tatasky.commons.{channelAttributesMapper, channelMapper}
import com.typesafe.config.Config
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import com.typesafe.config.Config

class ppTransformer extends Serializable {


  /* This metthod is used for transforming the pp data*/
  def ppdatatransform(loaddf: DataFrame)
                     (implicit spark: SparkSession, appConf: Config): (DataFrame,DataFrame) = {

    import spark.implicits._

    val transformationdf = loaddf.
      filter("UPPER(Market) != 'UNIVERSE'").
      withColumn("dt", udf(new transformFunctions().formatDate).apply(col("week_date"))).
      withColumn("Universe", udf(new transformFunctions().formatUniverse).apply(col("Market"))).
      withColumn("target", udf(new transformFunctions().formatTarget).apply(col("Target_new"))).
      withColumn("universe", new transformFunctions().regionTransformUDF($"Market")).
      withColumn("channel", col("Channel"))

    transformationdf.coalesce(9).createOrReplaceTempView("transformationdf")

    val pp_data =spark.sql("SELECT " +
      "CASE WHEN SUBSTRING( REGEXP_REPLACE(REGEXP_REPLACE(REGEXP_REPLACE(UPPER(Market), '\\\\s', ''),'/','-'),'\\\\[ALL\\\\]',''),4)='ODISHA-ORISSA' OR " +
      "SUBSTRING( REGEXP_REPLACE(REGEXP_REPLACE(REGEXP_REPLACE(UPPER(Market), '\\\\s', ''),'/','-'),'\\\\[ALL\\\\]',''),4)='ORISSA' THEN 'ORISSA' " +
      "WHEN SUBSTRING( REGEXP_REPLACE(REGEXP_REPLACE(REGEXP_REPLACE(UPPER(Market), '\\\\s', ''),'/','-'),'\\\\[ALL\\\\]',''),4)='ALLINDIA' " +
      "THEN ' ALL INDIA' " +
      "ELSE SUBSTRING( REGEXP_REPLACE(UPPER(Market),'\\\\[ALL\\\\]',''),4) END AS Market, " +
      "target , UPPER(Channel) as channel, " +
      " SUBSTRING(Week_Date,4,2) AS Month , main_title as prog_title, programme_genre as type_subject, " +
      "Start_Time_New as start_time, " +
      "End_Time_New as end_time, " +
      "Duration_min1 as dur_min_sum, TRP_avgw1 AS tvr_avgw, Impression_000_avgw1 AS Impression_000_avgw ," +
      "Reach_per_1min_count1 AS Reach_per_1min_count, Reach_000_1min_count1 AS Reach_000_1min_count, Program_Share1 AS program_share, " +
      "dt as week_date FROM transformationdf WHERE UPPER(Channel) !='TOTAL'").
      withColumn("starttime",
      when(split($"start_time", ":")(0).cast(IntegerType) < 2, concat(concat(concat(concat((split($"start_time", ":")(0).cast(IntegerType) + 24).cast(StringType), lit(":")), split($"start_time", ":")(1)), lit(":")), split($"start_time", ":")(2))).otherwise($"start_time")).
      withColumn("endtime",
        when(split($"end_time", ":")(0).cast(IntegerType) < 3 && split($"start_time", ":")(0).cast(IntegerType) < 2, concat(concat(concat(concat((split($"end_time", ":")(0).cast(IntegerType) + 24).cast(StringType), lit(":")), split($"end_time", ":")(1)), lit(":")), split($"end_time", ":")(2))).otherwise($"end_time")).
      drop($"end_time").drop($"start_time")

    pp_data.createOrReplaceTempView("pp_data")

    val sports_summary_data = spark.sql( "SELECT Market, Target, channel, " +
      " FIRST(month) AS month, prog_title, type_subject, " +
      " MIN(starttime) AS starttime, MAX(endtime) AS endtime, " +
      //" SUM(dur_min_sum) AS dur_min_sum, " +
      " week_date " +
      " FROM pp_data " +
      " WHERE prog_title LIKE 'L/T%' " +
      " GROUP BY Market, Target, channel, week_date, prog_title, type_subject ")
    (pp_data,sports_summary_data)
  }
  /*This metthos is used for transforming the pp summary data*/
  def ppsummarytransform (loaddf: DataFrame )
                         (implicit spark: SparkSession, appConf: Config): DataFrame = {
    import spark.implicits._
    val df = loaddf.
      filter("UPPER(universe) != 'UNIVERSE'").
      withColumn("dt", udf(new transformFunctions().formatDate).apply(col("date"))).
      withColumn("market", udf(new transformFunctions().formatUniverse).apply(col("universe"))).
      withColumn("target_new", udf(new transformFunctions().formatTarget).apply(col("target")))
    //val channelRevisionMappedDF = new channelMapper().mapLatestChannelName(df, channelNameMapLocation)

    df
  }

  /*This method is used for joining the pp L/t data with pp summary and left join with whole data*/

  def ppjoin (df1:DataFrame,df2: DataFrame,df3:DataFrame,source :String, file_type: String, run_year:String, run_week: String)
             (implicit spark: SparkSession, appConf: Config): (DataFrame,DataFrame) ={
    import spark.implicits._
    df1.createOrReplaceTempView("df1") //Detail pp data
    df2.createOrReplaceTempView("df2") // Only L/T program title data
    df3.createOrReplaceTempView("df3") // pp summary data

    val df_PP_data_merged_metrics_joined = spark.sql("SELECT A.Market, A.Target, A.channel, " +
      "A.month, A.prog_title, A.type_subject, " +
      "A.starttime,  A.endtime, " +
      "INT(B.duration_sec/60) AS dur_min_sum, " +
      "B.trp_avgw AS tvr_avgw, B.impression_000_avgw, " +
      "B.reach_per_1min_count, B.reach_000_1min_count, B.program_share, " +
      "A.week_date,A.latestChannelName " +
      "FROM df2 A JOIN df3 B " +
      "ON (UPPER(REGEXP_REPLACE(A.Market,' ',''))=UPPER(REGEXP_REPLACE(B.market,' ','')) AND UPPER(A.Target)=UPPER(B.target_new) AND " +
      "UPPER(REGEXP_REPLACE(A.latestChannelName,' ',''))=UPPER(REGEXP_REPLACE(B.latestChannelName,' ','')) AND " +
      "A.week_date=B.dt AND " +
      "UPPER(REGEXP_REPLACE(A.prog_title,' ',''))=UPPER(REGEXP_REPLACE(B.main_title,' ','')))")
    df_PP_data_merged_metrics_joined.createOrReplaceTempView("df_PP_data_merged_metrics_joined")
    val merged_count = df_PP_data_merged_metrics_joined.count
    val summary_count = df3.count
    var error_flag = "N"
    if (summary_count != merged_count) {
      error_flag = "Y"
    }
    val psql_summary_df = Seq((source, file_type, run_year.toInt, run_week.toInt, summary_count, merged_count, error_flag)).
      toDF("source", "file_type", "run_year", "run_week", "summary_count", "merged_count", "error_flag")
    //psqlInsert(header_table1, psql_summary_df)
    val pp_data_df_removed_merged = spark.sql("SELECT A.* FROM df1 A LEFT JOIN df_PP_data_merged_metrics_joined B " +
      " ON A.Market = B.Market AND " +
      " A.latestChannelName = B.latestChannelName AND " +
      " A.Target = B.Target AND " +
      " A.week_date = B.week_date AND " +
      " A.prog_title = B.prog_title " +
      " WHERE B.prog_title IS NULL").
      select("Market", "Target", "channel", "month", "prog_title", "type_subject", "starttime", "endtime", "dur_min_sum",
        "tvr_avgw", "impression_000_avgw", "reach_per_1min_count", "reach_000_1min_count", "program_share", "week_date", "latestChannelName")
      .union(df_PP_data_merged_metrics_joined).
      withColumn("start_time_round",
      when((split($"starttime", ":")(1).cast(IntegerType) >= 15) && (split($"starttime", ":")(1).cast(IntegerType) < 45), concat(split($"starttime", ":")(0), lit(":30:00"))).
        when((split($"starttime", ":")(1).cast(IntegerType) >= 0) && (split($"starttime", ":")(1).cast(IntegerType) < 15), concat(split($"starttime", ":")(0), lit(":00:00"))).
        when(split($"starttime", ":")(1).cast(IntegerType) >= 45, concat(lpad((split($"starttime", ":")(0).cast(IntegerType) + 1).cast(StringType), 2, "0"), lit(":00:00")))).
      withColumn("end_time_round",
        when((split($"endtime", ":")(1).cast(IntegerType) >= 15) && (split($"endtime", ":")(1).cast(IntegerType) < 45), concat(split($"endtime", ":")(0), lit(":30:00"))).
          when((split($"endtime", ":")(1).cast(IntegerType) >= 0) && (split($"endtime", ":")(1).cast(IntegerType) < 15), concat(split($"endtime", ":")(0), lit(":00:00"))).
          when(split($"endtime", ":")(1).cast(IntegerType) >= 45, concat(lpad((split($"endtime", ":")(0).cast(IntegerType) + 1).cast(StringType), 2, "0"), lit(":00:00"))))


    (pp_data_df_removed_merged,psql_summary_df)
  }

  def redshiftSchemaTransformer(df:DataFrame,run_year:String,run_week:String,source:String,file_type:String)(implicit spark: SparkSession, appConf: Config): DataFrame = {
    import spark.implicits._

    val start_wk_date = new transformFunctions().getWeekStartDate(run_year,run_week,0)
    val df1= df.withColumn("year", lit(run_year).cast(IntegerType)).
      withColumn("week", lit(run_week).cast(IntegerType)).
      withColumn("start_wk_date", lit(start_wk_date).cast(DateType))
    df1.createOrReplaceTempView("df")

    val final_df = spark.sql(" SELECT channel, cast(week_date as date)," +
     "CONCAT('${run_year}','w','${run_week}') as week_sun_sat, prog_title,type_subject," +
      "date_format(week_date,'EEEE') as day, starttime as start_time, endtime as end_time, cast(dur_min_sum as int)," +
      "cast(tvr_avgw as double) ,cast(impression_000_avgw as double) , cast(reach_per_1min_count as double) , cast(reach_000_1min_count as double) , cast(program_share as double) ," +
      "Market,Target,year,week,start_time_round," +
      "CASE WHEN CAST(SUBSTRING(start_time_round,1,2) AS INT) >= 18 AND CAST(SUBSTRING(start_time_round,1,2) AS INT) < 23 THEN " +
      "'Prime' ELSE 'Non Prime' END AS timezone, " +
      "start_wk_date, genre,main_network,channel_type," +
      "0 AS ns_flag,resolution_type " +
      "from df" )

    final_df

  }
  def ppmap (ppdata: DataFrame, ppsummary: DataFrame, channelNameMapLocation:String,channelAttributesMapLocation:String,run_year:String,run_week:String,Source:String,File_type:String)
            (implicit spark: SparkSession, appConf: Config): (DataFrame,DataFrame,DataFrame) =    {

    val (detaildf, groupdf)= ppdatatransform(ppdata)
    val ppsummarydf = ppsummarytransform(ppsummary)
    val groupdf_latest= new channelMapper().mapLatestChannelName(groupdf, channelNameMapLocation)
    val detaildf_latest = new channelMapper().mapLatestChannelName(detaildf,channelNameMapLocation)
    val ppsummarydf_latest = new channelMapper().mapLatestChannelName(ppsummarydf,channelNameMapLocation)
    val (ppjoined,errordf) = ppjoin(detaildf_latest,groupdf_latest,ppsummarydf_latest, Source,File_type,run_year,run_week)
    val (joined_latest,countdf)  = new channelAttributesMapper().
      mapChannelAttributes(run_year, run_week, ppjoined, channelNameMapLocation, channelAttributesMapLocation,Source,File_type)
    val final_df= redshiftSchemaTransformer(joined_latest,run_year,run_week,Source,File_type)

    (final_df,countdf,errordf)
  }
}








