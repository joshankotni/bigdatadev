package com.star.prism.tatasky.schemas.pp

case class outputSchemaTSPP (channel: String,
                             week_date: String,
                             week_sat_fri: String,
                             prog_title: String,
                             type_subject: String,
                             weekday: String,
                             start_time: String,
                             end_time: String,
                             dur_min_sum: String,
                             tvr_avgw: String,
                             impression_000_avgw: String,
                             reach_per_1min_count: String,
                             reach_000_1min_count: String,
                             Program_Share: String,
                             target: String,
                             market: String) extends Serializable
