package com.star.prism.tatasky.schemas.thirtyMin

case class thirtyMinSchema (market: String,
                            target: String,
                            channel: String,
                            week_sat_fri: String,
                            date: String,
                            weekday: String,
                            daypart: String,
                            tvr_avgw: String,
                            impression_000_avgw: String,
                            reach_per_1min_count: String,
                            reach_000_1min_count: String,
                            share: String) extends Serializable
