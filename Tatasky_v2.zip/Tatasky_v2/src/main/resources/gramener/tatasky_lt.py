# -*- coding: utf-8 -*-
"""
Created on Fri Dec 08 19:37:00 2017

@author: Muthuvel
"""
import os
import io
import glob
import sqlalchemy as sa
import time
import subprocess
import boto3
import pandas as pd
from datetime import datetime
import sys

error_log_file = open("tata_sports_error.log", "a")
status_log_file = open("upload_status.log", "a")
tata_sport_files = open("tata_sport_files.txt", "a")

week_no = 'w'
na_occurence = 0
process_date = "{}".format(datetime.now().date())
process_start_time = "{}".format(datetime.now().time())

while True:
    week_no = sys.argv[1]
    if (week_no.startswith('w')) or (week_no.startswith('W')):
        break

AWS_ACCESS_KEY_ID = ''
AWS_SECRET_ACCESS_KEY = ''
region = 'ap-south-1'

bucket = 'tataskyagg'
prefix = 'sports_pp/' + week_no + '/'
week_no_int = week_no.split('-')[0][-2:]
year_no_int = week_no.split('-')[1]

s3 = boto3.resource(
    's3', region_name=region,
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY
)

operation_parameters = {'Bucket': bucket,
                        'Prefix': prefix}
s3_client = boto3.client('s3', region_name=region,
                         aws_access_key_id=AWS_ACCESS_KEY_ID,
                         aws_secret_access_key=AWS_SECRET_ACCESS_KEY)


def redshift_connector():
    db_user_pass = "postgresql://admin:Admin123@"
    host_addr = "gramenerrs-new.cabwqpj0rd6q.ap-south-1.redshift.amazonaws.com"
    port_no = "5439"
    database = "prod"
    con_string = db_user_pass + host_addr + ":" + port_no + "/" + database
    engine = sa.create_engine(con_string, encoding='utf-8')
    return engine.connect()


def create_sports_temp_table():
    start_time = time.time()
    log_start_time = "{}".format(datetime.now().time())
    print '1. Raw Sports Data insert table creation'

    sports_raw_table_query = """
        DROP table tatasky_sports;
        create table tatasky_sports
        (
            market VARCHAR(100),
            target VARCHAR(100),
            channel VARCHAR(100),
            main_title VARCHAR(256),
            week_sat_fri VARCHAR(50),
            year VARCHAR(50),
            date VARCHAR(50),
            Weekday VARCHAR(50),
            programme_genre VARCHAR(100),
            duration_sec VARCHAR(50),
            trp VARCHAR(50),
            impression VARCHAR(50),
            reach_per VARCHAR(50),
            reach_absolute VARCHAR(50),
            prog_share VARCHAR(50)
        );
        commit;
    """
    con = redshift_connector()
    con.execute(sports_raw_table_query)
    con.close()

    end_time = "{}".format(datetime.now().time())
    tot_time = time.time() - start_time
    time_taken = log_start_time + ',' + end_time + ',' + "{}".format(tot_time)
    status_log_file.write("*" * 50 + "\n")
    status_log_file.write("Tatasky table creation \n")
    status_log_file.write("*" * 50 + "\n")
    status_log_file.write("Raw temp table creation," + process_date + ',' + time_taken + "\n")
    print("     Completed in %s seconds ---" % (tot_time))


# Load sports data to temp table
def load_tata_sports_temp_table(file, con):
    table_name = 'tatasky_sports'
    # bucket_location = 's3://barcagg/sports_pp/w22-2018/'
    bucket_location = 's3://tataskyagg/sports_pp/'+ week_no +'/' + file
    sql = """
        COPY %s FROM '%s'
        CREDENTIALS 'aws_access_key_id=%s;aws_secret_access_key=%s'
        IGNOREHEADER 2 delimiter ',' CSV;
    """ % (table_name, bucket_location,
           AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY)
    # print ("...........\n", sql)
    trans = con.begin()

    try:
        con.execute(sql)
        trans.commit()
    except sa.exc.SQLAlchemyError:
        trans.rollback()
        raise


def read_files():
    con = redshift_connector()
    # print ("...78")
    paginator = s3_client.get_paginator('list_objects')
    page_iterator = paginator.paginate(**operation_parameters)

    for page in page_iterator:
        response = page['Contents']
        for files in response:
            # print ("------->", files)
            # Get the file name
            file_list = files['Key'].rsplit('/', 2)
            # print (file_list)
            # print ("......>>", file_list[2])
            filename = file_list[1]+'/'+file_list[2]
            if (filename != '') and (file_list[2].startswith('Programmes')):
                print (filename)
                try:
                    tata_sport_files.write(filename + '\n')
                    load_tata_sports_temp_table(filename, con)
                    # print ("completed")
                    # move_processed_files(filename)
                except Exception as err:
                    print ("not_completed")
                    raise
                    # pass
        # break
    con.close()


def pp_sports_transformation():
    start_time = time.time()
    log_start_time = "{}".format(datetime.now().time())
    print '3. Transformation in progress'

    con = redshift_connector()

    add_query = """
        alter table tatasky_sports
        add column ns_flag int
        default NULL;
    """
    con.execute(add_query)

    # ---rename megacities
    update_query = """
        update tatasky_sports
        set ns_flag = case
            when trp = 9999 then 1
            when impression = 9999 then 1
        else
            0
        end;
        commit;
        ---------------------------------
        update tatasky_sports
        set target = ltrim(target, left(target,4));
        commit;

        update tatasky_sports
        set market = ltrim(market, left(market,3));
        commit;

        update tatasky_sports
        set market = rtrim(market, right(market,5));
        commit;
        ---------------------------------
        update tatasky_sports
        set market = 'KARNATAKA'
        where market = 'KARNATAK';
        update tatasky_sports
        set market = 'KERALA'
        where market = 'KERAL';
        update tatasky_sports
        set market = 'MAH / GOA'
        where market = 'MAH / GO';
        update tatasky_sports
        set market = 'ORISSA'
        where market = 'ORISS';
        update tatasky_sports
        set market = upper(market);
        commit;
        update tatasky_sports
        set target = '15+MALES'
        where target ='5+MALES';
        commit;
        update tatasky_sports
        set target = '15+MALES-FEMALES ABC'
        where target ='5+MALES-FEMALES ABC';
        commit;
    """
    con.execute(update_query)

    # ---get the L/t from the PP tables
    sports_master_temp_query = """
        drop table tatasky_sports_temp;
        create table tatasky_sports_temp as
        select *
        from encoding_tatasky_pp_detail_mapped_optimized
        where
            week in (%s) and year=%s
            and prog_title in (select distinct main_title from tatasky_sports);
        commit;
    """% (week_no_int, year_no_int)
    print (sports_master_temp_query)
    con.execute(sports_master_temp_query)

    # select count(*) from tatasky_sports_temp limit 10;

    # ---group by L/T rows from the PP table
    sports_grp_qry = """
        drop table tatasky_sports_grouped;
        create table tatasky_sports_grouped as
        select market,target, day, year, week_sun_sat, channel, prog_title, type_subject, week_date, week, min(start_time) as start_time ,max(end_time) as end_time
        from tatasky_sports_temp
        group by channel,prog_title,type_subject, week_date,week,
        market, target, day, year, week_sun_sat;
        commit;
    """
    con.execute(sports_grp_qry)

    update_query = """
        update tatasky_sports
        set date =  split_part(date,'/',3)||'-'||split_part(date,'/',2)||'-'||split_part(date,'/',1);
        commit;
    """
    con.execute(update_query)

    # -----------------------------------------------
    alter_query = """
        alter table tatasky_sports
        add column week int
        default NULL;
        commit;
    """
    con.execute(alter_query)

    update_query = """
        update tatasky_sports
        set year = cast(substring(tatasky_sports.week_sat_fri,1,4) as int), week = cast(substring(tatasky_sports.week_sat_fri,6,7) as int);
        commit;
    """
    con.execute(update_query)

    # -- merge new L/T rows with the older L/T rows and get the distinct columns
    sports_merge_qry = """
        drop table IF EXISTS tatasky_sports_merged CASCADE;
        commit;
        create table tatasky_sports_merged
        as select
        tatasky_sports_grouped.market,
        tatasky_sports_grouped.target,
        tatasky_sports_grouped.channel,
        tatasky_sports_grouped.week_date,
        tatasky_sports_grouped.day,
        tatasky_sports_grouped.prog_title,
        tatasky_sports_grouped.type_subject,
        tatasky_sports_grouped.start_time,
        tatasky_sports_grouped.end_time,
                case
                    when tatasky_sports_grouped.start_time < 18 then 'Non Prime'
                    when tatasky_sports_grouped.start_time > 23 then 'Non Prime'
                else
                'Prime'
                end as timezone,
        tatasky_sports.duration_sec/60 as dur_min_sum,
        cast(tatasky_sports.trp as float) tvr_avgw,
        tatasky_sports.channel as channel_1,
        tatasky_sports.main_title,
        cast(tatasky_sports.impression as float) impression_000_avgw,
        cast(tatasky_sports.reach_per as float) reach_per_1min_count,
        cast(tatasky_sports.reach_absolute as float) reach_000_1min_count,
        cast(tatasky_sports.prog_share as float) program_share,
        cast(tatasky_sports_grouped.year as integer),
        cast(tatasky_sports_grouped.week as integer),
        tatasky_sports_grouped.week_sun_sat,
                case
                    when tatasky_sports.trp = 9999 then 1
                    when tatasky_sports.impression = 9999 then 1
                    when tatasky_sports.target = 9999 then 1
                else
                    0
                    end as ns_flag
                    from
                    tatasky_sports
                    LEFT JOIN tatasky_sports_grouped
                    on
                    (upper(tatasky_sports_grouped.channel) = upper(tatasky_sports.channel))
                    and (upper(tatasky_sports_grouped.prog_title) = upper(tatasky_sports.main_title))
                    and tatasky_sports_grouped.market = tatasky_sports.market
                    and tatasky_sports_grouped.target = tatasky_sports.target
                    and tatasky_sports_grouped.week = tatasky_sports.week
                    and tatasky_sports_grouped.year = tatasky_sports.year
                    and tatasky_sports_grouped.day = tatasky_sports.weekday;

        drop table if exists tatasky_pp_newformat_temp;
        create table tatasky_pp_newformat_temp as
        select * from tatasky_sports_merged;
        commit;
    """
    print (sports_merge_qry)
    con.execute(sports_merge_qry)


def pp_sports_genre_mapping():
    start_time = time.time()
    log_start_time = "{}".format(datetime.now().time())
    print '4. Genre/Network mapping in progress'

    # map the raw row with the network and genre mapping file
    genre_mapping_query = """
        drop table IF EXISTS tatasky_pp_program_details_mapped;
        create table tatasky_pp_program_details_mapped
        As select
        upper(tatasky_pp_newformat_temp.channel) as channel,
        cast(tatasky_pp_newformat_temp.week_date as date),
        tatasky_pp_newformat_temp.week_sun_sat,
        upper(tatasky_pp_newformat_temp.prog_title) as prog_title,
        tatasky_pp_newformat_temp.type_subject,
        tatasky_pp_newformat_temp.day,
        tatasky_pp_newformat_temp.start_time,
        tatasky_pp_newformat_temp.end_time,
        cast(tatasky_pp_newformat_temp.dur_min_sum as integer),
        cast(tatasky_pp_newformat_temp.tvr_avgw as float),
        cast(tatasky_pp_newformat_temp.impression_000_avgw as float),
        cast(tatasky_pp_newformat_temp.reach_per_1min_count as float),
        cast(tatasky_pp_newformat_temp.reach_000_1min_count as float),
        cast(tatasky_pp_newformat_temp.program_share as float),
        tatasky_pp_newformat_temp.market,
        tatasky_pp_newformat_temp.target,
        tatasky_pp_newformat_temp.year,
        tatasky_pp_newformat_temp.week,
        start_time_roundoff(tatasky_pp_newformat_temp.start_time) as start_time_round,
        case
            when split_part(start_time_roundoff(tatasky_pp_newformat_temp.start_time),':',1) < 18 then 'Non Prime'
            when split_part(start_time_roundoff(tatasky_pp_newformat_temp.start_time),':',1) > 23 then 'Non Prime'
        else
        'Prime'
        end as timezone,
        (to_date(tatasky_pp_newformat_temp.week || '-' || tatasky_pp_newformat_temp.year, 'IW-IYYY')- interval '2 day')::date as start_wk_date,
        tatasky_weekly_mapping.genre,
        tatasky_weekly_mapping.network,
        tatasky_weekly_mapping.channel_type,
        tatasky_pp_newformat_temp.ns_flag,
        tatasky_weekly_mapping.resolution_type

        FROM
        tatasky_pp_newformat_temp
        LEFT JOIN tatasky_weekly_mapping
        on
        (upper(tatasky_pp_newformat_temp.channel) = upper(tatasky_weekly_mapping.channel))
        and
        (tatasky_pp_newformat_temp.week = tatasky_weekly_mapping.week)
        and
        (tatasky_pp_newformat_temp.year = tatasky_weekly_mapping.year);
        commit;
        """
    con = redshift_connector()
    con.execute(genre_mapping_query)
    con.close()


def delete_sports_pp_master():
    start_time = time.time()
    log_start_time = "{}".format(datetime.now().time())
    print 'PP Master delete sports records'

    #  delete the rows from the PP master table and insert the new rows
    delete_sports_query = """
        DELETE from encoding_tatasky_pp_detail_mapped_optimized
        using tatasky_pp_program_details_mapped
        where tatasky_pp_program_details_mapped.week=encoding_tatasky_pp_detail_mapped_optimized.week
        and tatasky_pp_program_details_mapped.day=encoding_tatasky_pp_detail_mapped_optimized.day
        and tatasky_pp_program_details_mapped.year=encoding_tatasky_pp_detail_mapped_optimized.year
        and tatasky_pp_program_details_mapped.channel=encoding_tatasky_pp_detail_mapped_optimized.channel
        and tatasky_pp_program_details_mapped.prog_title=encoding_tatasky_pp_detail_mapped_optimized.prog_title;
    """
    con = redshift_connector()
    trans = con.begin()
    try:
        result = con.execute(delete_sports_query)
        rows_affected = '{}'.format(result.rowcount)
        status_log_file.write("Number of records deleted from Tatasky Master PP - " + rows_affected + "\n")
        status_log_file.write("========================\n")
        trans.commit()
    except sa.exc.SQLAlchemyError:
        trans.rollback()
        raise
    con.close()


def load_pp_sports_master_table():
    start_time = time.time()
    log_start_time = "{}".format(datetime.now().time())
    print '5. Insert sports data to Final PP Master table'

    con = redshift_connector()
    # -- Final master table to be updated
    insert_query = '''
        INSERT into  encoding_tatasky_pp_detail_mapped_optimized
        select channel,week_date,week_sun_sat,prog_title,type_subject,day,start_time,
        end_time,dur_min_sum,tvr_avgw,
        impression_000_avgw,
        reach_per_1min_count,
        reach_000_1min_count,program_share,market,
        target,year,week,start_time_round,
        timezone,start_wk_date,genre,
        network,channel_type, ns_flag, resolution_type from tatasky_pp_program_details_mapped;
        commit;
    '''
    con.execute(insert_query)
    con.close()

    end_time = "{}".format(datetime.now().time())
    tot_time = time.time() - start_time
    time_taken = log_start_time + ',' + end_time + ',' + "{}".format(tot_time)
    status_log_file.write("Data to master table," + process_date + ',' + time_taken + "\n")
    print("     Completed in %s seconds ---" % (end_time))


def data_qc_log_count():
    con = redshift_connector()
    status_log_file.write("="*30 + "\n")
    raw_sports_qry = """select count(*) from tatasky_sports;"""
    result = con.execute(raw_sports_qry)
    tot_records = '{}'.format(result.fetchone()['count'])
    status_log_file.write("Number of Tatasky raw records from L/T files - " + tot_records + "\n")

    raw_sports_mapped_qry = """select count (*) from tatasky_pp_program_details_mapped;"""
    result = con.execute(raw_sports_mapped_qry)
    tot_records = '{}'.format(result.fetchone()['count'])
    status_log_file.write("Number of mapped raw records from L/T files - " + tot_records + "\n")
    status_log_file.write("------------------\n")

    sports_from_pp_master = """select count(*) from tatasky_sports_temp;"""
    result = con.execute(sports_from_pp_master)
    tot_records = '{}'.format(result.fetchone()['count'])
    status_log_file.write("Number of Tatasky records picked from PP master - " + tot_records + "\n")
    con.close()


overall_start_time = time.time()
try:
    create_sports_temp_table()
    read_files()
    pp_sports_transformation()
    pp_sports_genre_mapping()
    data_qc_log_count()
    delete_sports_pp_master()
    load_pp_sports_master_table()
except Exception, e:
    error_log_file.write("----------------------------" + "\n")
    error_log_file.write("Log: " + "{}".format(datetime.now()) + "\n")
    error_log_file.write("----------------------------" + "\n")

    error_log_file.write("\n")
    error_log_file.write("{}".format(e) + "\n")
    error_log_file.close()
    raise

print "============= Overall time taken ====================="
print("--- %s seconds ---" % (time.time() - overall_start_time))
print "=" * 20

process_end_time = "{}".format(datetime.now().time())
overall_time = time.time() - overall_start_time
time_taken = process_start_time + ',' + process_end_time + ',' + "{}".format(overall_time)
status_log_file.write("Total time," + process_date + ',' + time_taken + "\n")
status_log_file.write("\n")
tata_sport_files.close()
status_log_file.close()
