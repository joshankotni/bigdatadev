# coding: utf-8

import os
import io
import glob
import sqlalchemy as sa
import time
import subprocess
import boto3
import pandas as pd
from datetime import datetime
import sys

error_log_file = open("tata_pp_upload_error.log", "a")
status_log_file = open("upload_status.log", "a")
tatasky_files = open("tata_pp_files_list.txt", "a")

week_no = 'w'
na_occurence = 0
process_date = "{}".format(datetime.now().date())
process_start_time = "{}".format(datetime.now().time())

while True:
    week_no = sys.argv[1]
    if (week_no.startswith('w')) or (week_no.startswith('W')):
        break

AWS_ACCESS_KEY_ID = ''
AWS_SECRET_ACCESS_KEY = ''
region = 'ap-south-1'

bucket = 'tataskyagg'
prefix = 'active/pp/' + week_no +'/'

s3 = boto3.resource(
    's3', region_name=region,
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY
)

operation_parameters = {'Bucket': bucket,
                        'Prefix': prefix}
s3_client = boto3.client('s3', region_name=region,
                         aws_access_key_id=AWS_ACCESS_KEY_ID,
                         aws_secret_access_key=AWS_SECRET_ACCESS_KEY)

common_cols = ['Channel',
               'Date',
               'Week sat-fri',
               'Main Title',
               'Programme Genre',
               'Weekday',
               'Time (sec)',
               'To Time (sec)']


def redshift_connector():
    db_user_pass = "postgresql://admin:Admin123@"
    host_addr = "gramenerrs-new.cabwqpj0rd6q.ap-south-1.redshift.amazonaws.com"
    port_no = "5439"
    database = "prod"
    con_string = db_user_pass + host_addr + ":" + port_no + "/" + database
    engine = sa.create_engine(con_string, encoding='utf-8')
    return engine.connect()


def create_pp_temp_table():
    start_time = time.time()
    log_start_time = "{}".format(datetime.now().time())
    print '1. Raw Data insert temporary table creation'

    pp_raw_table_query = """
        DROP TABLE IF EXISTS tatasky_pp_raw_newformat_temp CASCADE;
        COMMIT;
        CREATE TABLE tatasky_pp_raw_newformat_temp
        (
        channel               varchar(256),
        week_date             varchar(15),
        week_sun_sat          varchar(256),
        prog_title            varchar(256),
        type_subject          varchar(256),
        day                   varchar(50),
        start_time            varchar(50),
        end_time              varchar(50),
        dur_min_sum           varchar(50),
        tvr_avgw              varchar(50),
        impression_000_avgw   varchar(50),
        reach_per_1min_count  varchar(50),
        reach_000_1min_count  varchar(50),
        program_share         varchar(50),
        market                varchar(100),
        target                varchar(100)
        );
        COMMIT;
    """
    con = redshift_connector()
    con.execute(pp_raw_table_query)
    con.close()

    end_time = "{}".format(datetime.now().time())
    tot_time = time.time() - start_time
    time_taken = log_start_time + ',' + end_time + ',' + "{}".format(tot_time)
    status_log_file.write("Raw temp table creation," + process_date + ',' + time_taken + "\n")
    print("     Completed in %s seconds ---" % (tot_time))


# Load processed data into database
def load_tata_pp_temp_table(con):
    table_name = 'tatasky_pp_raw_newformat_temp'
    # bucket_location = 's3://starlab123/lab1_manifest.json'
    file_location = 's3://tataskyagg/active/pp_processed_temp.csv'
    sql = """
    COPY %s FROM '%s'
    CREDENTIALS 'aws_access_key_id=%s;aws_secret_access_key=%s'
    IGNOREHEADER 1 delimiter ',' CSV;
    """ % (table_name, file_location,
           AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY)
    trans = con.begin()

    try:
        con.execute(sql)
        trans.commit()
    except sa.exc.SQLAlchemyError:
        trans.rollback()
        raise


def read_pp_file(s3_file_obj):
    data = pd.read_csv(io.BytesIO(s3_file_obj['Body'].read()), header=[1,2,3], encoding='utf-8')

    temp = data.copy()
    temp.columns = temp.columns.droplevel(0)
    temp.columns = temp.columns.droplevel(0)
    temp = temp.reset_index()

    temp.drop('index', axis=1, inplace=True)
    temp_1 = temp[common_cols]

    regions = []
    for reg in data.columns.levels[0]:
        if reg[:5] != 'Unnam':
            regions.append(reg)

    targets = []
    for tar in data.columns.levels[1]:
        if tar[:5] != 'Unnam':
            targets.append(tar)

    f_data=pd.DataFrame()
    for region in regions:
        for target in targets:
            temp_df = temp_1.join(data[region][target].reset_index())
            temp_df['Market'] = region
            temp_df['Target'] = target
            temp_df['Market'] = temp_df['Market'].str[3:]
            temp_df['Target'] = temp_df['Target'].str[4:]

            del(temp_df['index'])
            f_data=f_data.append(temp_df)

    f_data.to_csv('./pp_output/pp_processed_temp.csv', index = False, encoding='utf-8')
    print ('S3 Upload in progress ....')
    # subprocess.check_output(
    #     ["aws", 's3', 'sync', "./pp_processed_temp.csv", 's3://tataskyagg/active'])
    cwd = os.getcwd()
    output_path = cwd + '\pp_output'
    file_path = r''+output_path
    result = subprocess.check_output(
        ["aws", "s3", "sync", file_path, "s3://tataskyagg/active"], shell=True)
    # # == upload files dynamically to S3 - working
    # # == This works - but taking long time to upload
    # s3.meta.client.upload_file(
    #     './pp_processed_temp.csv', 'tataskyagg',
    #     'pp_processed_temp.csv', ExtraArgs={'ACL': 'public-read'})

def read_files():
    print '2. Raw PP Data format conversion'
    con = redshift_connector()
    paginator = s3_client.get_paginator('list_objects')
    page_iterator = paginator.paginate(**operation_parameters)
    target_list = ['T010200', 'T111200' , 'T192000', 'T373800', 'T474800', 'T555600', 'T616200', 'T636400','T293000']

    for page in page_iterator:
        response = page['Contents']
        for files in response:
            # Get the file name
            file_list = files['Key'].rsplit('/', 1)
            filename = file_list[1]
            if (filename != '') and (filename.endswith('.csv')):
                try:
                    print (filename)
                    filename_without_ext = filename.split('.')[0]
                    filename_without_ext = filename_without_ext[:-5]
                    start_index = filename_without_ext.find('T')
                    target_name = filename_without_ext[start_index:]

                    if target_name in target_list:
                        obj = s3_client.get_object(Bucket= bucket, Key= files['Key'])
                        read_pp_file(obj)
                        load_tata_pp_temp_table(con)
                        tatasky_files.write(filename + '\n')
                except Exception, err:
                    print ("error -------------")
                    print (err)
                    error_log_file.write(filename + '\n')
                    raise
                # break
        # break
    con.close()


def pp_transformation():
    start_time = time.time()
    log_start_time = "{}".format(datetime.now().time())
    print '3. Transformation in progress'

    con = redshift_connector()

    # keep targets which are needed
    delete_qry = '''DELETE from tatasky_pp_raw_newformat_temp
    where target not in ('4+','15+','15+MALES','15+FEMALES','15+MALES AB','15+FEMALES AB','15+ A',
    '15+MALES-FEMALES ABC', '15+MALES ABC', '15+FEMALES ABC','15+AB','13+AB');
    commit;'''
    con.execute(delete_qry)

    # Create Week column
    alter_query = '''ALTER table tatasky_pp_raw_newformat_temp
    add column week int
    default NULL;
    commit;'''
    con.execute(alter_query)

    # Create Year column
    alter_query = '''ALTER table tatasky_pp_raw_newformat_temp
    add column year int
    default NULL;
    commit;'''
    con.execute(alter_query)

    # Create ns_flag column
    alter_query = '''ALTER table tatasky_pp_raw_newformat_temp
    add column ns_flag int
    default NULL;
    commit;'''
    con.execute(alter_query)

    # Update week and year value
    update_query = '''UPDATE tatasky_pp_raw_newformat_temp
    set year = cast(substring(tatasky_pp_raw_newformat_temp.week_sun_sat,1,4) as int),
    week = cast(substring(tatasky_pp_raw_newformat_temp.week_sun_sat,6,7) as int);
    commit;'''
    con.execute(update_query)

    update_query = '''UPDATE tatasky_pp_raw_newformat_temp
    set ns_flag = case
        when tvr_avgw = 9999 then 1
        when impression_000_avgw = 9999 then 1
    else
        0
    end;
    commit;'''
    con.execute(update_query)

    # ---format market names
    update_query = '''UPDATE tatasky_pp_raw_newformat_temp
    set market = rtrim(market, right(market,5));
    commit;'''
    con.execute(update_query)

    # ---correct market names
    update_query = '''
        UPDATE tatasky_pp_raw_newformat_temp
        set market = 'KARNATAKA' where market = 'KARNATAK';
        UPDATE tatasky_pp_raw_newformat_temp
        set market = 'KERALA' where market = 'KERAL';
        UPDATE tatasky_pp_raw_newformat_temp
        set market = 'MAH / GOA' where market = 'MAH / GO';
        UPDATE tatasky_pp_raw_newformat_temp
        set market = 'ORISSA' where market = 'ORISS';
        commit;

        UPDATE tatasky_pp_raw_newformat_temp
        set market = upper(market);
        commit;

        UPDATE tatasky_pp_raw_newformat_temp
        set target = '15+MALES'
        where target ='5+MALES';
        commit;
        '''
    con.execute(update_query)

    # ---format week_date
    update_query = '''UPDATE tatasky_pp_raw_newformat_temp
    set week_date =  split_part(week_date,'/',3)||'-'||split_part(week_date,'/',2)||'-'||split_part(week_date,'/',1);
    commit;'''
    con.execute(update_query)


def pp_genre_mapping():
    start_time = time.time()
    log_start_time = "{}".format(datetime.now().time())
    print '4. Genre/Network mapping in progress'

    # map the raw row with the network and genre mapping file
    genre_mapping_query = """
        DROP TABLE IF EXISTS tatasky_pp_program_details_mapped CASCADE;
        commit;

        CREATE TABLE tatasky_pp_program_details_mapped
        As select
        upper(tatasky_pp_raw_newformat_temp.channel) as channel,
        cast(tatasky_pp_raw_newformat_temp.week_date as date),
        tatasky_pp_raw_newformat_temp.week_sun_sat,
        upper(tatasky_pp_raw_newformat_temp.prog_title) as prog_title,
        tatasky_pp_raw_newformat_temp.type_subject,
        tatasky_pp_raw_newformat_temp.day,
        tatasky_pp_raw_newformat_temp.start_time,
        tatasky_pp_raw_newformat_temp.end_time,
        cast(tatasky_pp_raw_newformat_temp.dur_min_sum as integer),
        cast(tatasky_pp_raw_newformat_temp.tvr_avgw as float),
        cast(tatasky_pp_raw_newformat_temp.impression_000_avgw as float),
        cast(tatasky_pp_raw_newformat_temp.reach_per_1min_count as float),
        cast(tatasky_pp_raw_newformat_temp.reach_000_1min_count as float),
        cast(tatasky_pp_raw_newformat_temp.program_share as float),
        tatasky_pp_raw_newformat_temp.market,
        tatasky_pp_raw_newformat_temp.target,
        tatasky_pp_raw_newformat_temp.year,
        tatasky_pp_raw_newformat_temp.week,
        start_time_roundoff(tatasky_pp_raw_newformat_temp.start_time) as start_time_round,
        case
            when split_part(start_time_roundoff(tatasky_pp_raw_newformat_temp.start_time),':',1) < 18 then 'Non Prime'
            when split_part(start_time_roundoff(tatasky_pp_raw_newformat_temp.start_time),':',1) > 23 then 'Non Prime'
        else
        'Prime'
        end as timezone,
        (to_date(tatasky_pp_raw_newformat_temp.week || '-' || tatasky_pp_raw_newformat_temp.year, 'IW-IYYY')- interval '2 day')::date as start_wk_date,
        tatasky_weekly_mapping.genre,
        tatasky_weekly_mapping.network,
        tatasky_weekly_mapping.channel_type,
        tatasky_pp_raw_newformat_temp.ns_flag,
        tatasky_weekly_mapping.resolution_type

        FROM
        tatasky_pp_raw_newformat_temp
        LEFT JOIN tatasky_weekly_mapping
        on
        (upper(tatasky_pp_raw_newformat_temp.channel) = upper(tatasky_weekly_mapping.channel))
        and
        (tatasky_pp_raw_newformat_temp.week = tatasky_weekly_mapping.week)
        and
        (tatasky_pp_raw_newformat_temp.year = tatasky_weekly_mapping.year);
        commit;
    """
    con = redshift_connector()
    con.execute(genre_mapping_query)
    con.close()


def load_pp_master_table():
    start_time = time.time()
    log_start_time = "{}".format(datetime.now().time())
    print '5. Load Data to Final Master table'

    con = redshift_connector()
    # -- Final master table to be updated
    insert_query = '''
        INSERT into  encoding_tatasky_pp_detail_mapped_optimized
        SELECT channel,week_date,week_sun_sat,prog_title,type_subject,day,start_time,
        end_time,dur_min_sum,tvr_avgw,
        impression_000_avgw,
        reach_per_1min_count,
        reach_000_1min_count,program_share,market,
        target,year,week,start_time_round,
        timezone,start_wk_date,genre,
        network,channel_type, ns_flag, resolution_type from tatasky_pp_program_details_mapped;
        commit;
        '''
    con.execute(insert_query)
    con.close()

    end_time = "{}".format(datetime.now().time())
    tot_time = time.time() - start_time
    time_taken = log_start_time + ',' + end_time + ',' + "{}".format(tot_time)
    status_log_file.write("Data to master table," + process_date + ',' + time_taken + "\n")
    print("     Completed in %s seconds ---" % (end_time))


overall_start_time = time.time()
try:
    if not os.path.exists('./pp_output'):
        os.makedirs('./pp_output')
    create_pp_temp_table()
    read_files()
    pp_transformation()
    pp_genre_mapping()
    load_pp_master_table()
except Exception, e:
    error_log_file.write("----------------------------" + "\n")
    error_log_file.write("Log: " + "{}".format(datetime.now()) + "\n")
    error_log_file.write("----------------------------" + "\n")

    error_log_file.write("\n")
    error_log_file.write("{}".format(e) + "\n")
    error_log_file.close()
    raise

print "============= Overall time taken ====================="
print("--- %s seconds ---" % (time.time() - overall_start_time))
print "=" * 20

process_end_time = "{}".format(datetime.now().time())
overall_time = time.time() - overall_start_time
time_taken = process_start_time + ',' + process_end_time + ',' + "{}".format(overall_time)
status_log_file.write("Total time," + process_date + ',' + time_taken + "\n")
status_log_file.close()
