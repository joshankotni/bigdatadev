package com.star.prism.tatasky.pp_prevalidation.Transformers

import com.star.prism.tatasky.commonSparkSession
import org.scalatest.FunSuite
import org.scalatest.prop.Checkers

class PPPVTransformerSpec  extends FunSuite with Checkers with commonSparkSession with Serializable with PPPVTransformer {

  test(" Testing lineParser ") {

    val runWeek = "1"
    val runYear = "2019"

    val inputData = List(
      ",,,,,,,,Universe,Target,Units,,,,,,,,,",
      ",,,,,,,,*01PUN / HAR / CHA / HP / J&K[All],*01PUN / HAR / CHA / HP / J&K[All],*01PUN / HAR / CHA / HP / J&K[All],*01PUN / HAR / CHA / HP / J&K[All],*01PUN / HAR / CHA / HP / J&K[All],*01PUN / HAR / CHA / HP / J&K[All],*01PUN / HAR / CHA / HP / J&K[All],*01PUN / HAR / CHA / HP / J&K[All],*01PUN / HAR / CHA / HP / J&K[All],*01PUN / HAR / CHA / HP / J&K[All],*01PUN / HAR / CHA / HP / J&K[All],*01PUN / HAR / CHA / HP / J&K[All]",
      ",,,,,,,,*01 4+,*01 4+,*01 4+,*01 4+,*01 4+,*01 4+,*02 15+,*02 15+,*02 15+,*02 15+,*02 15+,*02 15+",
      "Channel,Date,Week sat-fri,Main Title,Programme Genre,Weekday,Time (sec),To Time (sec),Duration,TRP (avgW),'000 (avg),Cover (1min cont),Cover000 (1min cont),Prog Share,Duration,TRP (avgW),'000 (avg),Cover (1min cont),Cover000 (1min cont),Prog Share",
      "DD National,29/12/2018,2019w01,AAP KI BAAT,Interviews/Portraits/Discussions,Saturday,09:01:16,09:25:27,24,0.0000,0.0000,0.0000,0.0000,0.0000,24,0.0000,0.0000,0.0000,0.0000,0.0000",
      "Star Sports 1,29/12/2018,2019w01,L/T VODAFONE PBL-18-19 NOR/DEL-PUN,Live Telecast/Sports,Saturday,19:06:43,22:34:37,207,0.0005,0.0142,0.0136,0.3760,0.0021,207,0.0006,0.0142,0.0158,0.3760,0.0025"
    )

    val inputRDD = spark.sparkContext.parallelize(inputData,1)
    object pppv extends PPPVTransformer with Serializable
    val ppDF = pppv.lineParser(inputRDD, runYear, runWeek)

    assert(ppDF.count == 4)
    assert(ppDF.columns.length == 18)

  }

}