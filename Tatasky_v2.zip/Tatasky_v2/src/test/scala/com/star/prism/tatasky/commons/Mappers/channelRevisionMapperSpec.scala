package com.star.prism.tatasky.commons.Mappers

import com.star.prism.tatasky.commonSparkSession
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql.{Encoders, Row}
import org.scalatest.FunSuite
import org.scalatest.prop.Checkers

class channelRevisionMapperSpec extends FunSuite with Checkers with channelRevisionMapper with commonSparkSession {

  implicit val appConf: Config = ConfigFactory.load("pp-ingestion-application.conf")
  case class channelMapSchema (channelName: String, latestChannelName: String )

  test("test mapChannels") {

    import spark.implicits._

    val inputDF = spark.sparkContext.parallelize(List("Sony", "Asianet HD", "&Flix HD", "Zee Studio HD")).toDF("channel")

    val channelMapData = Seq(
      Row("SET", "SET"),
      Row("SONY", "SET"),
      Row("&FLIXHD", "&FLIXHD"),
      Row("ZEESTUDIOHD", "&FLIXHD"),
      Row("ASIANETHD", "ASIANETHD")
    )

    val latestChannelMap = spark.createDataFrame(spark.sparkContext.parallelize(channelMapData), Encoders.product[channelMapSchema].schema)
    val df = mapChannels(inputDF, latestChannelMap)

    assertResult("SET") {
      df.filter("channel = 'Sony'").select("latestChannelName").distinct().head().getString(0)
    }

    assertResult("&FLIXHD") {
      df.filter("channel = 'Zee Studio HD'").select("latestChannelName").distinct().head().getString(0)
    }

  }

}
