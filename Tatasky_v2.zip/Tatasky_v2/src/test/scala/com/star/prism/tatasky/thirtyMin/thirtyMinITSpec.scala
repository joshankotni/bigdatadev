package com.star.prism.tatasky.thirtyMin

import java.io.File

import com.star.prism.tatasky.commonSparkSession
import com.star.prism.tatasky.thirtyMin.Egestors.thirtyMinEgestor
import com.star.prism.tatasky.thirtyMin.Transformers.{thirtyMinInputSchema, thirtyMinTransformer}
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql.Encoders
import org.scalatest.FunSuite
import org.scalatest.prop.Checkers


class thirtyMinITSpec extends FunSuite with Checkers with commonSparkSession {

  implicit val appConf: Config = ConfigFactory.load("thirtyMin-test-application.conf")

  val resourcesDirectory: String = new File(appConf.getString("test.path")).getAbsolutePath

  val thirtyMinIngestor = new Ingestors.thirtyMinIngestor()
  val thirtyMinEgestor = new thirtyMinEgestor()

  // run one test at a time (second one's input is the output of the first)

  test(" Integration Testing for all modules (YW) ") {

    val runWeek = "40"
    val runYear = "2018"
    val formattedWeek = "%02d".format(runWeek.toInt)

    val confPath =  appConf.getString("ts.30min.input.s3.path.prefix") + s"year=$runYear/week=$formattedWeek"

    val loadPath = resourcesDirectory + confPath
    val channelNameMapLocation = resourcesDirectory + appConf.getString("ts.channel.revision.mapping")
    val channelAttributesMapLocation = resourcesDirectory + appConf.getString("ts.channel.attributes.mapping")

    val outputLocationYW = resourcesDirectory + appConf.getString("ts.30min.output.yw.prefix") + appConf.getString("ts.30min.output.yw.folder")
    val outputLocationError = resourcesDirectory + appConf.getString("ts.30min.output.yw.prefix") + appConf.getString("ts.error.output.folder")

    val inputDF = thirtyMinIngestor.dataLoader(loadPath)
    val (df, errorDF) = new thirtyMinTransformer().applythirtyMinTransforms(runYear, runWeek, inputDF, channelNameMapLocation, channelAttributesMapLocation)
    thirtyMinEgestor.dataWriter(df, errorDF, outputLocationYW, outputLocationError)

    //testing count and schema
    assert(inputDF.count() > 0)
    assert(inputDF.schema === Encoders.product[thirtyMinInputSchema].schema)
    assert(df.count() > 0)
    assert(errorDF.count() >= 0)

  }


  test(" Integration Testing for MT Repartition ") {

    val confPath =  appConf.getString("ts.30min.output.yw.prefix") + appConf.getString("ts.30min.output.yw.folder")

    val inputLocationYW = resourcesDirectory + confPath
    val outputLocationMT = resourcesDirectory + appConf.getString("ts.30min.output.mt.prefix") + appConf.getString("ts.30min.output.mt.folder")

    val df = thirtyMinIngestor.dataLoaderMT(inputLocationYW, "2018")
    thirtyMinEgestor.dataWriterMT(df, outputLocationMT)

    //testing count
    assert(df.count() > 0)

  }

}
