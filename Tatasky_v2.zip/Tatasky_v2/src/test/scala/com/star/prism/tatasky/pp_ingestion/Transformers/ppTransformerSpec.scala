package com.star.prism.tatasky.pp_ingestion.Transformers

import com.star.prism.tatasky.commonSparkSession
import com.star.prism.tatasky.pp_ingestion._
import com.star.prism.tatasky.schemas.pp.ppSummary
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql.{Encoders, Row}
import org.scalatest.prop.Checkers
import org.scalatest.{FunSuite, Matchers}

class ppTransformerSpec extends FunSuite with Checkers with commonSparkSession with Matchers with Serializable with PPTransformer{

  implicit val appConf: Config = ConfigFactory.load("pp-ingestion-application.conf")

  test(" Test preMergeTransformer ") {

    import spark.implicits._

    val inputData = Seq(
      Row("DD National","2019w01","AAP KI BAAT","Interviews/Portraits/Discussions","Saturday","09:01:16","09:25:27",24.0,0.0,0.0,0.0,0.0,0.0,"*01 4+","*01PUN / HAR / CHA / HP / J&K[All]",2019,1,"2018-12-29"),
      Row("DD National","2019w01","AAP KI BAAT","Interviews/Portraits/Discussions","Saturday","09:01:16","09:25:27",24.0,0.0,0.0,0.0,0.0,0.0,"*02 15+","*01PUN / HAR / CHA / HP / J&K[All]",2019,1,"2018-12-29"),
      Row("Star Sports 1","2019w01","L/T VODAFONE PBL-18-19 NOR/DEL-PUN","Live Telecast/Sports","Saturday","19:06:43","22:34:37",207.0,5.0E-4,0.0142,0.0136,0.376,0.0021,"*01 4+","*01PUN / HAR / CHA / HP / J&K[All]",2019,1,"2018-12-29"),
      Row("Star Sports 1","2019w01","L/T VODAFONE PBL-18-19 NOR/DEL-PUN","Live Telecast/Sports","Saturday","19:06:43","22:34:37",207.0,6.0E-4,0.0142,0.0158,0.376,0.0025,"*02 15+","*01PUN / HAR / CHA / HP / J&K[All]",2019,1,"2018-12-29")
    )

    val inputDF = spark.createDataFrame(spark.sparkContext.parallelize(inputData), Encoders.product[ppInputSchema].schema)
    val ppTransformedDF = preMergeTransformer(inputDF)

    assert(ppTransformedDF.columns.length == 16)
    ppTransformedDF.select("target").distinct.map(r => r.getString(0)).collect.toList should contain theSameElementsAs Iterable("4+", "15+")

    assertResult("PUN / HAR / CHA / HP / J&K") {
      ppTransformedDF.select("market").distinct().head().getString(0)
    }

  }


  test(" Test preMergeTransformerSportsSummary ") {

    import spark.implicits._

    val sportSummaryData = List(
      "*01PUN / HAR / CHA / HP / J&K[All],*01 4+,Star Sports 1,L/T VODAFONE PBL-18-19 NOR/DEL-PUN,2019w01,2019,29-12-2018,Saturday,Live Telecast/Sports,12475,0.000512,0.01416,0.013583,0.376,0.00214",
      "*01PUN / HAR / CHA / HP / J&K[All],*02 15+,Star Sports 1,L/T VODAFONE PBL-18-19 NOR/DEL-PUN,2019w01,2019,29-12-2018,Saturday,Live Telecast/Sports,12475,0.000595,0.01416,0.015794,0.376,0.002513"
    )

    val sportSummaryDF = spark.
      createDataFrame(spark.sparkContext.parallelize(sportSummaryData).map(a => Row.fromSeq(a.split(","))),
        Encoders.product[ppSummary].schema)

    val sportSummaryTransformedDF = preMergeTransformerSportsSummary(sportSummaryDF)

    assert(sportSummaryTransformedDF.columns.length == 12)
    sportSummaryTransformedDF.select("target").distinct.map(r => r.getString(0)).collect.toList should contain theSameElementsAs Iterable("4+", "15+")

    assertResult("PUN / HAR / CHA / HP / J&K") {
      sportSummaryTransformedDF.select("market").distinct().head().getString(0)
    }

  }


  test(" Test ltMergeTransformer ") {

    val ppTransformedData = Seq(
      Row("DD National","AAP KI BAAT","Interviews/Portraits/Discussions","09:01:16","09:25:27",24.0,0.0,0.0,0.0,0.0,0.0,"4+","2018-12-29","PUN / HAR / CHA / HP / J&K"),
      Row("DD National","AAP KI BAAT","Interviews/Portraits/Discussions","09:01:16","09:25:27",24.0,0.0,0.0,0.0,0.0,0.0,"15+","2018-12-29","PUN / HAR / CHA / HP / J&K"),
      Row("Star Sports 1","L/T VODAFONE PBL-18-19 NOR/DEL-PUN PRE","Live Telecast/Sports","19:06:43","22:34:37",207.0,5.0E-4,0.0142,0.0136,0.376,0.0021,"4+","2018-12-29","PUN / HAR / CHA / HP / J&K"),
      Row("Star Sports 1","L/T VODAFONE PBL-18-19 NOR/DEL-PUN","Live Telecast/Sports","19:06:43","22:34:37",207.0,5.0E-4,0.0142,0.0136,0.376,0.0021,"4+","2018-12-29","PUN / HAR / CHA / HP / J&K"),
      Row("Star Sports 1","L/T VODAFONE PBL-18-19 NOR/DEL-PUN","Live Telecast/Sports","19:06:43","22:34:38",207.0,5.0E-4,0.0142,0.0136,0.376,0.0021,"4+","2018-12-29","PUN / HAR / CHA / HP / J&K"),
      Row("Star Sports 1","L/T VODAFONE PBL-18-19 NOR/DEL-PUN PRE","Live Telecast/Sports","19:06:43","22:34:37",207.0,6.0E-4,0.0142,0.0158,0.376,0.0025,"15+","2018-12-29","PUN / HAR / CHA / HP / J&K"),
      Row("Star Sports 1","L/T VODAFONE PBL-18-19 NOR/DEL-PUN","Live Telecast/Sports","19:06:43","22:34:37",207.0,6.0E-4,0.0142,0.0158,0.376,0.0025,"15+","2018-12-29","PUN / HAR / CHA / HP / J&K"),
      Row("Star Sports 1","L/T VODAFONE PBL-18-19 NOR/DEL-PUN","Live Telecast/Sports","19:06:43","22:34:38",207.0,6.0E-4,0.0142,0.0158,0.376,0.0025,"15+","2018-12-29","PUN / HAR / CHA / HP / J&K")
    )

    val sportSummaryTransformedData = List(
      Row("PUN / HAR / CHA / HP / J&K","4+","Star Sports 1","L/T VODAFONE PBL-18-19 NOR/DEL-PUN","Live Telecast/Sports","0.000512","0.01416","0.013583","0.376","0.00214","2018-12-29",207),
      Row("PUN / HAR / CHA / HP / J&K","15+","Star Sports 1","L/T VODAFONE PBL-18-19 NOR/DEL-PUN","Live Telecast/Sports","0.000512","0.01416","0.013583","0.376","0.00214","2018-12-29",207)
    )

    val ppTransformedDF = spark.createDataFrame(spark.sparkContext.parallelize(ppTransformedData), Encoders.product[ppTransformedSchema].schema)
    val sportSummaryTransformedDF = spark.createDataFrame(spark.sparkContext.parallelize(sportSummaryTransformedData), Encoders.product[sportSummaryTransformedSchema].schema)
    val ppAfterLTDF = ltMergeTransformer(ppTransformedDF, sportSummaryTransformedDF)

    assert(ppAfterLTDF.columns.length == 14)

    assertResult("22:34:38") {
      ppAfterLTDF.filter("prog_title = 'L/T VODAFONE PBL-18-19 NOR/DEL-PUN'").select("end_time").distinct().head().getString(0)
    }


  }

  test(" Test redshiftSchemaTransformer ") {

    val ppBeforeRedshiftTransformsData = Seq(
      Row("DDNATIONAL","PUN / HAR / CHA / HP / J&K","4+","DD National","AAP KI BAAT","Interviews/Portraits/Discussions","2018-12-29","09:01:16","09:25:27",24.0,"0.0","0.0","0.0","0.0","0.0","DD Network","Hindi GEC","FTA","SD"),
      Row("DDNATIONAL","PUN / HAR / CHA / HP / J&K","15+","DD National","AAP KI BAAT","Interviews/Portraits/Discussions","2018-12-29","09:01:16","09:25:27",24.0,"0.0","0.0","0.0","0.0","0.0","DD Network","Hindi GEC","FTA","SD"),
      Row("STARSPORTS1","PUN / HAR / CHA / HP / J&K","4+","Star Sports 1","L/T VODAFONE PBL-18-19 NOR/DEL-PUN PRE","Live Telecast/Sports","2018-12-29","19:06:43","22:34:37",207.0,"5.0E-4","0.0142","0.0136","0.376","0.0021","Star Network","Sport","Paid","SD"),
      Row("STARSPORTS1","PUN / HAR / CHA / HP / J&K","15+","Star Sports 1","L/T VODAFONE PBL-18-19 NOR/DEL-PUN PRE","Live Telecast/Sports","2018-12-29","19:06:43","22:34:37",207.0,"6.0E-4","0.0142","0.0158","0.376","0.0025","Star Network","Sport","Paid","SD"),
      Row("STARSPORTS1","PUN / HAR / CHA / HP / J&K","15+","Star Sports 1","L/T VODAFONE PBL-18-19 NOR/DEL-PUN","Live Telecast/Sports","2018-12-29","19:06:43","22:34:38",207.0,"0.000512","0.01416","0.013583","0.376","0.00214","Star Network","Sport","Paid","SD"),
      Row("STARSPORTS1","PUN / HAR / CHA / HP / J&K","4+","Star Sports 1","L/T VODAFONE PBL-18-19 NOR/DEL-PUN","Live Telecast/Sports","2018-12-29","19:06:43","22:34:38",207.0,"0.000512","0.01416","0.013583","0.376","0.00214","Star Network","Sport","Paid","SD")
    )

    val ppBeforeRedshiftTransformsDF = spark.createDataFrame(spark.sparkContext.parallelize(ppBeforeRedshiftTransformsData), Encoders.product[ppBeforeRedshiftTransformsSchema].schema)
    val ppAfterRedshiftTransformsDF = redshiftSchemaTransformer(ppBeforeRedshiftTransformsDF, "2019", "1")

    assert(ppAfterRedshiftTransformsDF.columns.length == 27)

    assertResult("2019w01") {
      ppAfterRedshiftTransformsDF.select("week_sun_sat").distinct().head().getString(0)
    }

    assertResult(0) {
      ppAfterRedshiftTransformsDF.select("ns_flag").distinct().head().getInt(0)
    }

    assertResult("No") {
      ppAfterRedshiftTransformsDF.select("channel_org").distinct().head().getString(0)
    }

  }

}
