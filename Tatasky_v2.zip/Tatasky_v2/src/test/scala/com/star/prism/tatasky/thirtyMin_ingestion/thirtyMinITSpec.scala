package com.star.prism.tatasky.thirtyMin_ingestion

import com.star.prism.tatasky.commonSparkSession
import com.star.prism.tatasky.commons.Mappers.{channelMapper, channelRevisionMapper}
import com.star.prism.tatasky.commons.{channelMappingSchema, channelRevisionMappingSchema}
import com.star.prism.tatasky.schemas.thirtyMin.thirtyMinSchema
import com.star.prism.tatasky.thirtyMin_ingestion.Transformers.ThirtyMinTransformer
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Encoders, Row}
import org.scalatest.FunSuite
import org.scalatest.prop.Checkers

import scala.annotation.tailrec

class thirtyMinITSpec extends FunSuite with Checkers with commonSparkSession with Serializable with ThirtyMinTransformer with channelRevisionMapper with channelMapper{

  def TSRecentNameToStarHistoricalName(line: List[String]): List[(String, String)] = {
    val filteredLine = line.filterNot(_ == null)
    createMapOfTargetChannelToSourceChannel(filteredLine.tail, filteredLine.head, Nil)
      .reverse
  }

  @tailrec
  final def createMapOfTargetChannelToSourceChannel(inp: List[String], first: String, output: List[(String, String)]):
  List[(String, String)] = inp match {
    case head :: tail => {
      createMapOfTargetChannelToSourceChannel(tail, first, output :+ (head -> first))
    }
    case Nil => output
  }

  test(" Integration Testing for all modules ") {

    implicit val appConf: Config = ConfigFactory.load("thirtyMin-ingestion-application.conf")

    val runWeek = "1"
    val runYear = "2019"
    val formattedWeek = "%02d".format(runWeek.toInt)

    val inputData = Seq(
      Row("","","","","","","","Units","","","",""),
      Row("Universe","Target","Channel","Week sat-fri","Date","Weekday","Daypart","TRP (avgW)","'000 (avg)","Cover (1min cont)","Cover000 (1min cont)","Share"),
      Row("*01PUN / HAR / CHA / HP / J&K[All]","*01 4+","All Channels","2019w01","29/12/2018","Saturday","0200 - 0229","0.2063","5.7102","0.4663","12.9085","100.0000"),
      Row("*01PUN / HAR / CHA / HP / J&K[All]","*01 4+","DD National","2019w01","30/12/2018","Sunday","0200 - 0229","0.0000","0.0000","0.0000","0.0000","0.0000"),
      Row("*01PUN / HAR / CHA / HP / J&K[All]","*01 4+","DD National","2019w01","30/12/2018","Sunday","0230 - 0259","0.0000","0.0000","0.0000","0.0000","0.0000"),
      Row("*01PUN / HAR / CHA / HP / J&K[All]","*01 4+","DD","2019w01","30/12/2018","Sunday","0230 - 0259","0.0000","0.0000","0.0000","0.0000","0.0000"),
      Row("*01PUN / HAR / CHA / HP / J&K[All]","*01 4+","Star Sports 1","2019w01","31/12/2018","Monday","2000 - 2029","0.0000","0.0000","0.0000","0.0000","0.0000"),
      Row("*01PUN / HAR / CHA / HP / J&K[All]","*01 4+","Star Sports 1","2019w01","31/12/2018","Monday","2030 - 2059","0.0000","0.0000","0.0000","0.0000","0.0000")
    )

    val inputDF = spark.createDataFrame(spark.sparkContext.parallelize(inputData), Encoders.product[thirtyMinSchema].schema)

    // transform 30 min
    val transformedDF = applyThirtyMinTranforms(inputDF, runYear, runWeek)

    // create channel revision mapping data
    val channelRevisionMappingData = Seq(
      Row("Channel Common", "channel 1", "channel 2", "channel 3", "channel 4", "channel 5", "channel 6"),
      Row("All Channels", "All Channels", "", "", "", "", ""),
      Row("DD National", "DD National", "", "", "", "", ""),
      Row("Star Sports 1", "Star Sports 1", "", "", "", "", "")
    )

    // apply channel revision mapping on 30min data
    val channelRevisionMappingLoadDF = spark.createDataFrame(spark.sparkContext.parallelize(channelRevisionMappingData), Encoders.product[channelRevisionMappingSchema].schema)

    val channelRevMapping = channelRevisionMappingLoadDF.collect().toList.map(x => x.mkString(","))
      .drop(1)
      .filter(elem => elem.size>0)
      .map(elem => elem.split(",").toList)
      .filter(elem => elem.size>0)
      .map(TSRecentNameToStarHistoricalName)
      .flatten

    val transformCRM = spark.
      createDataFrame(channelRevMapping).
      withColumnRenamed("_1", "channelName").
      withColumnRenamed("_2", "latestChannelName").
      withColumn("channelName", trim(upper(regexp_replace(col("channelName")," ","")))).
      withColumn("latestChannelName", trim(upper(regexp_replace(col("latestChannelName")," ",""))))

    val channelRevisionMappedPPDF = mapChannels(transformedDF, transformCRM)

    // create channel mapping data
    val channelMapData = Seq(
      Row("All Channels", "01", "2019", "ANY TV", "ANY TV", "ANY TV", "ANY TV"),
      Row("DD National", "01", "2019", "Hindi GEC", "DD Network", "FTA", "SD"),
      Row("Star Sports 1", "01", "2019", "Sport", "Star Network", "Paid", "SD")
    )

    // apply channel revision mapping on channel mapping data
    val channelMapLoadDF = spark.createDataFrame(spark.sparkContext.parallelize(channelMapData), Encoders.product[channelMappingSchema].schema)
    val channelAttributesMap = transformMappingFile(runYear, formattedWeek, channelMapLoadDF)

    val revisedNameMap = mapChannels(channelAttributesMap, transformCRM).
      filter("latestChannelName != 'NOT FOUND'").
      select("latestChannelName", "channelInfo").
      distinct()

    // perform channel mapping on pp data followed by transforming to final redshift schema
    val (channelAttributesMappedDF, errDF) = mapAttributes(channelRevisionMappedPPDF, revisedNameMap)
    val redshiftTransformedDF = redshiftSchemaTransformer(channelAttributesMappedDF)

    assert(redshiftTransformedDF.columns.length == 22)
    assert(redshiftTransformedDF.count == 6)
    assert(errDF.count == 1)

    assertResult("DD") {
      errDF.select("channel").distinct().head().getString(0)
    }

  }

}
