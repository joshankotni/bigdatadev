package com.star.prism.tatasky.pp_prevalidation.Transformers

import org.scalatest.{FunSuite, Matchers}

class PPPVParseFunctionsSpec extends FunSuite with Matchers with PPPVParseFunctions {

  test("determine Target"){
    val data= ",,,,,,,,*61 15+MALES-FEMALES ABC,*61 15+MALES-FEMALES ABC,*61 15+MALES-FEMALES ABC,*61 15+MALES-FEMALES ABC,*61 15+MALES-FEMALES ABC,*61 15+MALES-FEMALES ABC,*62 15+MALES ABC,*62 15+MALES ABC,*62 15+MALES ABC,*62 15+MALES ABC,*62 15+MALES ABC,*62 15+MALES ABC"
    val output = parseTarget(data)
    output.get should equal  (List("*61 15+MALES-FEMALES ABC","*62 15+MALES ABC"))
    val data2 = ",,,,,,,,*63 15+FEMALES ABC,*63 15+FEMALES ABC,*63 15+FEMALES ABC,*63 15+FEMALES ABC,*63 15+FEMALES ABC,*63 15+FEMALES ABC"
    val output2 = parseTarget(data2)
    output2.get should equal (List("*63 15+FEMALES ABC"))
    val data3 = ",,,,,,,,*18South[All],*18South[All],*18South[All],*18South[All],*18South[All],*18South[All]"
    parseTarget(data3) should equal (None)
    val data4 = ",,,,,,,,*18South[All],*18South[All],*18South[All],*18South[All],*18South[All],*18South[All],*18South[All],*18South[All],*18South[All],*18South[All],*18South[All],*18South[All]"
    parseTarget(data4) should equal (None)
    val data5 = ",,,,,,,,Universe,Target,Units,,,,,,,,,"
    parseTarget(data5) should equal (None)
    val data6 = ",,,,,,,,Universe,Target,Units,,,"
    parseTarget(data6) should equal (None)
    val data7 = "DD National,05/01/2019,2019w02,AANGAN,Serials,Saturday,21:30:38,21:56:54,26,0.0188,1.9509,0.2269,23.5337,0.0728,26,0.0328,1.8403,0.4069,22.8060,0.1332"
    parseTarget(data7) should equal (None)
    val data8 = "DD National,05/01/2019,2019w02,AANGAN,Serials,Saturday,21:30:38,21:56:54,26,0.0023,0.1106,0.0153,0.7277,0.0085"
    parseTarget(data8) should equal (None)
    val data9 = "Channel,Date,Week sat-fri,Main Title,Programme Genre,Weekday,Time (sec),To Time (sec),Duration,TRP (avgW),'000 (avg),Cover (1min cont),Cover000 (1min cont),Prog Share,Duration,TRP (avgW),'000 (avg),Cover (1min cont),Cover000 (1min cont),Prog Share"
    parseTarget(data9) should equal (None)
    val data10= "Channel,Date,Week sat-fri,Main Title,Programme Genre,Weekday,Time (sec),To Time (sec),Duration,TRP (avgW),'000 (avg),Cover (1min cont),Cover000 (1min cont),Prog Share"
    parseTarget(data10) should equal (None)
    val data11 = "\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"*01 4+\",\"*01 4+\",\"*01 4+\",\"*01 4+\",\"*01 4+\",\"*01 4+\",\"*02 15+\",\"*02 15+\",\"*02 15+\",\"*02 15+\",\"*02 15+\",\"*02 15+\""
    val output3 = parseTarget(data11)
    output3.get should equal  (List("*01 4+","*02 15+"))
  }

  test("determine Market"){
    val data = ",,,,,,,,*18South[All],*18South[All],*18South[All],*18South[All],*18South[All],*18South[All],*18South[All],*18South[All],*18South[All],*18South[All],*18South[All],*18South[All]"
    val output = parseMarket(data)
    output.get should equal ("*18South[All]")
    val data2 = ",,,,,,,,*18South[All],*18South[All],*18South[All],*18South[All],*18South[All],*18South[All]"
    val output2 = parseMarket(data2)
    output2.get should equal ("*18South[All]")
    val data3 = ",,,,,,,,*63 15+FEMALES ABC,*63 15+FEMALES ABC,*63 15+FEMALES ABC,*63 15+FEMALES ABC,*63 15+FEMALES ABC,*63 15+FEMALES ABC"
    parseMarket(data3) should equal (None)
    val data4= ",,,,,,,,*61 15+MALES-FEMALES ABC,*61 15+MALES-FEMALES ABC,*61 15+MALES-FEMALES ABC,*61 15+MALES-FEMALES ABC,*61 15+MALES-FEMALES ABC,*61 15+MALES-FEMALES ABC,*62 15+MALES ABC,*62 15+MALES ABC,*62 15+MALES ABC,*62 15+MALES ABC,*62 15+MALES ABC,*62 15+MALES ABC"
    parseMarket(data4) should equal (None)
    val data5 = ",,,,,,,,Universe,Target,Units,,,,,,,,,"
    parseMarket(data5) should equal (None)
    val data6 = ",,,,,,,,Universe,Target,Units,,,"
    parseMarket(data6) should equal (None)
    val data7 = "DD National,05/01/2019,2019w02,AANGAN,Serials,Saturday,21:30:38,21:56:54,26,0.0188,1.9509,0.2269,23.5337,0.0728,26,0.0328,1.8403,0.4069,22.8060,0.1332"
    parseMarket(data7) should equal (None)
    val data8 = "DD National,05/01/2019,2019w02,AANGAN,Serials,Saturday,21:30:38,21:56:54,26,0.0023,0.1106,0.0153,0.7277,0.0085"
    parseMarket(data8) should equal (None)
    val data9 = "Channel,Date,Week sat-fri,Main Title,Programme Genre,Weekday,Time (sec),To Time (sec),Duration,TRP (avgW),'000 (avg),Cover (1min cont),Cover000 (1min cont),Prog Share,Duration,TRP (avgW),'000 (avg),Cover (1min cont),Cover000 (1min cont),Prog Share"
    parseMarket(data9) should equal (None)
    val data10= "Channel,Date,Week sat-fri,Main Title,Programme Genre,Weekday,Time (sec),To Time (sec),Duration,TRP (avgW),'000 (avg),Cover (1min cont),Cover000 (1min cont),Prog Share"
    parseMarket(data10) should equal (None)
    val data11 = "\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"*01PUN / HAR / CHA / HP / J&K[All]\",\"*01PUN / HAR / CHA / HP / J&K[All]\",\"*01PUN / HAR / CHA / HP / J&K[All]\",\"*01PUN / HAR / CHA / HP / J&K[All]\",\"*01PUN / HAR / CHA / HP / J&K[All]\",\"*01PUN / HAR / CHA / HP / J&K[All]\",\"*01PUN / HAR / CHA / HP / J&K[All]\",\"*01PUN / HAR / CHA / HP / J&K[All]\",\"*01PUN / HAR / CHA / HP / J&K[All]\",\"*01PUN / HAR / CHA / HP / J&K[All]\",\"*01PUN / HAR / CHA / HP / J&K[All]\",\"*01PUN / HAR / CHA / HP / J&K[All]\""
    val output3 = parseMarket(data11)
    output3.get should equal ("*01PUN / HAR / CHA / HP / J&K[All]")
  }


  test("explode for 1 TG") {

    val data = "DD National,05/01/2019,2019w02,AANGAN,Serials,Saturday,21:30:38,21:56:54,26,0.0023,0.1106,0.0153,0.7277,0.0085"
    val TG = List("*63 15+FEMALES ABC")
    val market = "*18South[All]"

    val output: Option[List[String]] = explodeRecord1(TG, market, data)
    output.get should equal (List("DD National,05/01/2019,2019w02,AANGAN,Serials,Saturday,21:30:38,21:56:54,26,0.0023,0.1106,0.0153,0.7277,0.0085,*63 15+FEMALES ABC,*18South[All]"))

    val data2 = ",,,,,,,,Universe,Target,Units,,,,,,,,,"
    explodeRecord1(TG, market, data2) should equal (None)

    val data3 = ",,,,,,,,*18South[All],*18South[All],*18South[All],*18South[All],*18South[All],*18South[All]"
    explodeRecord1(TG, market, data3) should equal (None)

    val data4 = ",,,,,,,,*63 15+FEMALES ABC,*63 15+FEMALES ABC,*63 15+FEMALES ABC,*63 15+FEMALES ABC,*63 15+FEMALES ABC,*63 15+FEMALES ABC"
    explodeRecord1(TG, market, data4) should equal (None)

    val data5 ="Channel,Date,Week sat-fri,Main Title,Programme Genre,Weekday,Time (sec),To Time (sec),Duration,TRP (avgW),'000 (avg),Cover (1min cont),Cover000 (1min cont),Prog Share"
    explodeRecord1(TG, market, data5) should equal (None)

  }


  test("explode for 2 TGs"){

    val data = "DD National,05/01/2019,2019w02,AANGAN,Serials,Saturday,21:30:38,21:56:54,26,0.0188,1.9509,0.2269,23.5337,0.0728,26,0.0328,1.8403,0.4069,22.8060,0.1332"
    val TG = List("*61 15+MALES-FEMALES ABC","*62 15+MALES ABC")
    val market = "*18South[All]"
    val output: Option[List[String]] = explodeRecord2(TG,market,data)
    output.get should equal(List("DD National,05/01/2019,2019w02,AANGAN,Serials,Saturday,21:30:38,21:56:54,26,0.0188,1.9509,0.2269,23.5337,0.0728,*61 15+MALES-FEMALES ABC,*18South[All]",
      "DD National,05/01/2019,2019w02,AANGAN,Serials,Saturday,21:30:38,21:56:54,26,0.0328,1.8403,0.4069,22.8060,0.1332,*62 15+MALES ABC,*18South[All]"))

    val data2 = ",,,,,,,,*18South[All],*18South[All],*18South[All],*18South[All],*18South[All],*18South[All],*18South[All],*18South[All],*18South[All],*18South[All],*18South[All],*18South[All]"
    explodeRecord2(TG, market, data2) should equal (None)

    val data3 = ",,,,,,,,*61 15+MALES-FEMALES ABC,*61 15+MALES-FEMALES ABC,*61 15+MALES-FEMALES ABC,*61 15+MALES-FEMALES ABC,*61 15+MALES-FEMALES ABC,*61 15+MALES-FEMALES ABC,*62 15+MALES ABC,*62 15+MALES ABC,*62 15+MALES ABC,*62 15+MALES ABC,*62 15+MALES ABC,*62 15+MALES ABC"
    explodeRecord2(TG, market, data3) should equal (None)

    val data4 = "Channel,Date,Week sat-fri,Main Title,Programme Genre,Weekday,Time (sec),To Time (sec),Duration,TRP (avgW),'000 (avg),Cover (1min cont),Cover000 (1min cont),Prog Share,Duration,TRP (avgW),'000 (avg),Cover (1min cont),Cover000 (1min cont),Prog Share"
    explodeRecord2(TG, market, data4) should equal (None)
  }

}
