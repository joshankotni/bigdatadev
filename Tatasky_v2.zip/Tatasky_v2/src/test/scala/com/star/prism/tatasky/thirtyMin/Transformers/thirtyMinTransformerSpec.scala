package com.star.prism.tatasky.thirtyMin.Transformers

import java.io.File

import com.star.prism.tatasky.commonSparkSession
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql.{Encoders, Row}
import org.scalatest.prop.Checkers
import org.scalatest.{FunSuite, Matchers}

class thirtyMinTransformerSpec extends FunSuite with Checkers with commonSparkSession with Matchers {

  implicit val appConf: Config = ConfigFactory.load("thirtyMin-test-application.conf")
  val resourcesDirectory: String = new File(appConf.getString("test.path")).getAbsolutePath

  val thirtyMinTransformer = new thirtyMinTransformer()

    test("test thirtyMinTransformer.applythirtyMinTransforms") {

      val channelNameMapLocation = resourcesDirectory + appConf.getString("ts.channel.revision.mapping")
      val channelAttributesMapLocation = resourcesDirectory + appConf.getString("ts.channel.attributes.mapping")

      val data = Seq(
        Row("*01PUN / HAR / CHA / HP / J&K[All]", "*64 13+AB", "All Channels", "2018w40", "29/09/2018", "Saturday", "1900 - 1929", "8.598", "204.4548", "99.5414", "2361.216", "100"),
        Row("*01PUN / HAR / CHA / HP / J&K[All]", "*64 13+AB", "DD National", "2018w40", "29/09/2018", "Saturday", "0200 - 0229", "0.0127", "0.3016", "8.0471", "190.8845", "0.1475"),
        Row("*01PUN / HAR / CHA / HP / J&K[All]", "*64 13+AB", "Zee TV", "2018w40", "29/09/2018", "Saturday", "1900 - 1929", "0.1768", "4.2074", "26.6082", "631.1709", "2.0568"),
        Row("*01PUN / HAR / CHA / HP / J&K[All]", "*64 13+AB", "Zee TV", "2018w40", "29/09/2018", "Saturday", "0200 - 0229", "0.1768", "4.2074", "26.6082", "631.1709", "2.0568"),
        Row("*01PUN / HAR / CHA / HP / J&K[All]", "*64 13+AB", "Star Sports First", "2018w40", "29/09/2018", "Saturday", "1900 - 1929", "0", "0", "0", "0", "0")
      )

      val inputDF = spark.createDataFrame(spark.sparkContext.parallelize(data), Encoders.product[thirtyMinInputSchema].schema)

      val (df, errorDF) = thirtyMinTransformer.applythirtyMinTransforms("2018", "40", inputDF, channelNameMapLocation, channelAttributesMapLocation)

      assert(df.count() >= 0)
      assert(errorDF.count() >= 0)
//      assert(df.count() < 0) // To test for failure

    }

    test("test thirtyMinTransformer.applyTransforms") {

      import spark.implicits._

      val data = Seq(
        Row("Universe", "*64 13+AB", "All Channels", "2018w40", "29/09/2018", "Saturday", "0200 - 0229", "8.598", "204.4548", "99.5414", "2361.216", "100"),
        Row("*02KARNATAK[All]", "*64 13+AB", "All Channels", "2018w40", "29/09/2018", "Saturday", "0230 - 0259", "8.598", "204.4548", "99.5414", "2361.216", "100"),
        Row("*01PUN / HAR / CHA / HP / J&K[All]", "*64 13+AB", "All Channels", "2018w40", "29/09/2018", "Saturday", "1900 - 1929", "8.598", "204.4548", "99.5414", "2361.216", "100"),
        Row("*01PUN / HAR / CHA / HP / J&K[All]", "*64 13+AB", "Zee TV", "2018w40", "29/09/2018", "Saturday", "2200 - 2229", "0.1768", "4.2074", "26.6082", "631.1709", "2.0568"),
        Row("*01PUN / HAR / CHA / HP / J&K[All]", "*64 13+AB", "Star Sports First", "2018w40", "29/09/2018", "Saturday", "2200 - 2229", "0", "0", "0", "0", "0")
      )

      val inputDF = spark.createDataFrame(spark.sparkContext.parallelize(data), Encoders.product[thirtyMinInputSchema].schema)

      val df = thirtyMinTransformer.applyTransforms("2018", "40", inputDF)

      assert(df.count() > 0)
      assertResult("13+AB"){df.select("target").distinct().head().getString(0)}
      assertResult(0){df.select("ns_flag").distinct().head().getInt(0)}
      assertResult(0){df.filter($"universe".contains("[All]")).count()}
//          assert(df.count() < 0) // To test for failure

    }

}
