package com.star.prism.tatasky.commons.Mappers

import com.star.prism.tatasky.commonSparkSession
import com.star.prism.tatasky.commons.channelMappingSchema
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql.{Encoders, Row}
import org.scalatest.prop.Checkers
import org.scalatest.{FunSuite, Matchers}

class channelMapperSpec extends FunSuite with Checkers with channelMapper with commonSparkSession with Matchers {

  implicit val appConf: Config = ConfigFactory.load("pp-ingestion-application.conf")

  test("test transformMappingFile") {

    val channelMapData = Seq(
      Row("Sony", "01", "2019", "Hindi GEC", "Sony Network", "Paid", "SD"),
      Row("Zee Studio HD", "01", "2019", "English Movies", "Zee Network", "Paid", "HD"),
      Row("Asianet HD", "01", "2019", "Malayalam GEC", "Star Network", "Paid", "HD")
    )

    val channelMapLoadDF = spark.createDataFrame(spark.sparkContext.parallelize(channelMapData), Encoders.product[channelMappingSchema].schema)
    val channelMapDF = transformMappingFile("2019", "01", channelMapLoadDF)

    assert(channelMapDF.columns.length == 2)

  }


  case class channelAttributesMapSchema(latestChannelName: String, channelInfo: String)
  case class inputChannelSchema (channel: String, latestChannelName: String )

  test("test channelAttributesMapper.mapAttributes") {

    val inputData = Seq(
      Row("SET", "SET"),
      Row("Sony", "SET"),
      Row("&Flix HD", "&FLIXHD"),
      Row("Zee Studio HD", "&FLIXHD"),
      Row("Khushboo Bangla", "KHUSHBOOBANGLA"),
      Row("Asianet HD", "ASIANETHD")
    )

    val inputDF = spark.createDataFrame(spark.sparkContext.parallelize(inputData), Encoders.product[inputChannelSchema].schema)

    val channelMapData = Seq(
      Row("SET", "Sony Network|Hindi GEC|Paid|SD"),
      Row("&FLIXHD", "Zee Network|English Movies|Paid|HD"),
      Row("ASIANETHD", "Star Network|Malayalam GEC|Paid|HD")
    )

    val latestChannelMap = spark.createDataFrame(spark.sparkContext.parallelize(channelMapData), Encoders.product[channelAttributesMapSchema].schema)
    val (df, errorDF) = mapAttributes(inputDF, latestChannelMap)

    assert(inputDF.select("channel").distinct().count() === df.select("channel").union(errorDF.select("channel")).distinct().count())

    assertResult("Khushboo Bangla") {
      errorDF.select("channel").distinct().head().getString(0)
    }

    assertResult("Sony Network") {
      df.filter("latestChannelName = 'SET'").select("main_network").distinct().head().getString(0)
    }

    assertResult("Hindi GEC") {
      df.filter("latestChannelName = 'SET'").select("genre").distinct().head().getString(0)
    }

    assertResult("Paid") {
      df.filter("latestChannelName = 'SET'").select("channel_type").distinct().head().getString(0)
    }

    assertResult("SD") {
      df.filter("latestChannelName = 'SET'").select("resolution_type").distinct().head().getString(0)
    }

  }


  case class inputSchema(channel: String, genre: String, main_network: String, channel_type: String, resolution_type: String)

  test("test filterErrorChannels") {

    import spark.implicits._

    val data = Seq(
      Row("Hello World TV", "NOT FOUND", "NOT FOUND", "NOT FOUND", "NOT FOUND"),
      Row("NOT FOUND", "NOT FOUND", "NOT FOUND", "NOT FOUND", "NOT FOUND"),
      Row("Wrong TV", "NOT FOUND", "NOT FOUND", "NOT FOUND", "NOT FOUND")
    )

    val inputDF = spark.createDataFrame(spark.sparkContext.parallelize(data), Encoders.product[inputSchema].schema)

    val df = filterErrorChannels("2019", "01", inputDF, "TATASKY", "PP")

    assert(df.count() > 0)

    df.select("channel").map(r => r.getString(0)).collect.toList should contain theSameElementsAs Iterable("Hello World TV", "NOT FOUND", "Wrong TV")

  }

}
