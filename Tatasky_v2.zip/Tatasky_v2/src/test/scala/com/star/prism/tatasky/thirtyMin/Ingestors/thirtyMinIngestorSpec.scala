package com.star.prism.tatasky.thirtyMin.Ingestors

import java.io.File

import com.star.prism.tatasky.commonSparkSession
import com.star.prism.tatasky.thirtyMin.Ingestors
import com.star.prism.tatasky.thirtyMin.Transformers.thirtyMinInputSchema
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.Encoders
import org.scalatest.FunSuite
import org.scalatest.prop.Checkers

class thirtyMinIngestorSpec extends FunSuite with Checkers with commonSparkSession {

  implicit val appConf = ConfigFactory.load("thirtyMin-test-application.conf")

  val thirtyMinIngestor = new Ingestors.thirtyMinIngestor()

  test("test thirtyMinIngestor.dataLoader") {

//    implicit val spark = SparkSessionProvider.sparkSession
    spark.sparkContext.setLogLevel("WARN")

    val runWeek = "40"
    val runYear = "2018"
    val formattedWeek = "%02d".format(runWeek.toInt)

    val confPath =  appConf.getString("ts.30min.input.s3.path.prefix") + s"year=$runYear/week=$formattedWeek"
    val resourcesDirectory = new File(appConf.getString("test.path")).getAbsolutePath
    val loadPath = resourcesDirectory + confPath

    val df = thirtyMinIngestor.dataLoader(loadPath)

    //testing count and schema
    assert(df.count() > 0)
    assert(df.schema === Encoders.product[thirtyMinInputSchema].schema)
  }


  test("test thirtyMinIngestor.dataLoaderMT") {

//    implicit val spark = SparkSessionProvider.sparkSession
    spark.sparkContext.setLogLevel("WARN")

    val confPath =  appConf.getString("ts.30min.output.yw.prefix") + appConf.getString("ts.30min.output.yw.folder")
    val resourcesDirectory = new File(appConf.getString("test.path")).getAbsolutePath
    val inputLocationYW = resourcesDirectory + confPath

    val df = thirtyMinIngestor.dataLoaderMT(inputLocationYW, "2018")

   //testing count
    assert(df.count() > 0)

  }

}
