package com.star.prism.tatasky.pp.Ingestors

import java.io.File

import com.holdenkarau.spark.testing.{DataFrameSuiteBase, SparkSessionProvider}
import com.star.prism.tatasky.commonSparkSession
import com.star.prism.tatasky.pp.Transformers.ppsummary
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.Encoders
import org.scalatest.FunSuite
import org.scalatest.prop.Checkers

class ppsummaryingestorspec extends FunSuite with Checkers with commonSparkSession {

  implicit val appConf = ConfigFactory.load("pp-test-application.conf")

  test("test ppsummaryIngestor.dataLoader") {
//    implicit val spark = SparkSessionProvider.sparkSession

    spark.sparkContext.setLogLevel("WARN")
    val path = new File("src/test/resources/test_pp/sports").getAbsolutePath

    val df = new PpIngestor().ppsportsLoader(path)
    val path1 = new File("src/test/resources/test_pp/Non sports").getAbsolutePath
    val df1= new PpIngestor().ppnonportsLoader(path1,df)

    //testing count and schema
    assert(df.count() > 0)
    assert(df.schema === Encoders.product[ppsummary].schema)


  }

  test("test ppsummaryIngestor.datanotfoundfornonsports") {
//    implicit val spark = SparkSessionProvider.sparkSession

    spark.sparkContext.setLogLevel("WARN")
    val path = new File("src/test/resources/test_pp/sports").getAbsolutePath

    val df = new PpIngestor().ppsportsLoader(path)

    val path1 = new File("src/test/resources/test_pp/Nonsports").getAbsolutePath
    val df1= new PpIngestor().ppnonportsLoader(path1,df)

    //testing count and schema
    assert(df.count() > 0)
    assert(df.schema === Encoders.product[ppsummary].schema)

  }

}
