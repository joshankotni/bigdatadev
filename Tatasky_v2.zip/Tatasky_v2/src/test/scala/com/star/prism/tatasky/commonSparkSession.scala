package com.star.prism.tatasky

import com.holdenkarau.spark.testing._
import org.scalatest.FunSuite

trait commonSparkSession extends FunSuite with DataFrameSuiteBase {

  override implicit lazy val spark = SparkSessionProvider.sparkSession

}
