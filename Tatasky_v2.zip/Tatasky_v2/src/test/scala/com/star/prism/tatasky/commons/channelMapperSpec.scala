package com.star.prism.tatasky.commons

import java.io.File

import com.star.prism.tatasky.commonSparkSession
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql.{Encoders, Row}
import org.scalatest.FunSuite
import org.scalatest.prop.Checkers

class channelMapperSpec extends FunSuite with Checkers with commonSparkSession {

  implicit val appConf: Config = ConfigFactory.load("weekly-test-application.conf")

  val channelMap = new channelMapper()
  val resourcesDirectory: String = new File(appConf.getString("test.path")).getAbsolutePath

  test("test channelMapper.mapLatestChannelName") {

    import spark.implicits._

    val channelNameMapLocation = resourcesDirectory + appConf.getString("ts.channel.revision.mapping")

    val inputDF = spark.sparkContext.parallelize(List("Sony", "Asianet HD", "&Flix HD")).toDF("channel")

    val df = channelMap.mapLatestChannelName(inputDF, channelNameMapLocation)

    assertResult("SET") {df.filter("channel = 'Sony'").select("latestChannelName").distinct().head().getString(0)}
    assertResult("ASIANETHD") {df.filter("channel = 'Asianet HD'").select("latestChannelName").distinct().head().getString(0)}
    assertResult("&FLIXHD") {df.filter("channel = '&Flix HD'").select("latestChannelName").distinct().head().getString(0)}
    //        assertResult(" ASIANETHD ") {df.filter("channel = 'Asianet HD'").select("latestChannelName").distinct().head().getString(0)} //To Test Failure

  }

  test("test channelMapper.transformMapFile") {

    val data = Seq(
      Row("SET", "SET", "Sony", "", "", "", ""),
      Row("Asianet HD", "Asianet HD", "", "", "", "", ""),
      Row("&Flix HD", "&Flix HD", "Zee Studio HD", "", "", "", "")
    )

    val inputDF = spark.createDataFrame(spark.sparkContext.parallelize(data), Encoders.product[channelRevisionMappingSchema].schema)
    val df = channelMap.transformMapFile(inputDF)

    assertResult("SET") {df.filter("channelName = 'SONY'").select("latestChannelName").distinct().head().getString(0)}
    assertResult("SET") {df.filter("channelName = 'SET'").select("latestChannelName").distinct().head().getString(0)}
    assertResult("ASIANETHD") {df.filter("channelName = 'ASIANETHD'").select("latestChannelName").distinct().head().getString(0)}
    assertResult("&FLIXHD") {df.filter("channelName = '&FLIXHD'").select("latestChannelName").distinct().head().getString(0)}
    assertResult("&FLIXHD") {df.filter("channelName = 'ZEESTUDIOHD'").select("latestChannelName").distinct().head().getString(0)}
    //            assertResult(" ASIANETHD ") {df.filter("channelName = 'ASIANETHD'").select("latestChannelName").distinct().head().getString(0)} //To Test Failure

  }

  case class channelMapSchema (channelName: String, latestChannelName: String )

  test("test channelMapper.mapChannels") {

    import spark.implicits._

    val inputDF = spark.sparkContext.parallelize(List("Sony", "Asianet HD", "&Flix HD", "Zee Studio HD")).toDF("channel")

    val channelMapData = Seq(
      Row("SET", "SET"),
      Row("SONY", "SET"),
      Row("&FLIXHD", "&FLIXHD"),
      Row("ZEESTUDIOHD", "&FLIXHD"),
      Row("ASIANETHD", "ASIANETHD")
    )

    val latestChannelMap = spark.createDataFrame(spark.sparkContext.parallelize(channelMapData), Encoders.product[channelMapSchema].schema)
    val df = channelMap.mapChannels(inputDF, latestChannelMap)

    assertResult("SET") {df.filter("channel = 'Sony'").select("latestChannelName").distinct().head().getString(0)}
    assertResult("ASIANETHD") {df.filter("channel = 'Asianet HD'").select("latestChannelName").distinct().head().getString(0)}
    assertResult("&FLIXHD") {df.filter("channel = '&Flix HD'").select("latestChannelName").distinct().head().getString(0)}
    assertResult("&FLIXHD") {df.filter("channel = 'Zee Studio HD'").select("latestChannelName").distinct().head().getString(0)}
    //            assertResult(" ASIANETHD ") {df.filter("channel = 'Asianet HD'").select("latestChannelName").distinct().head().getString(0)} //To Test Failure

  }

}
