package com.star.prism.tatasky.pp_ingestion

import com.star.prism.tatasky.commonSparkSession
import com.star.prism.tatasky.commons.Mappers.{channelMapper, channelRevisionMapper}
import com.star.prism.tatasky.commons.{channelMappingSchema, channelRevisionMappingSchema}
import com.star.prism.tatasky.pp_ingestion.Transformers.PPTransformer
import com.star.prism.tatasky.pp_prevalidation.Transformers.PPPVTransformer
import com.star.prism.tatasky.schemas.pp.ppSummary
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Encoders, Row}
import org.scalatest.FunSuite
import org.scalatest.prop.Checkers

import scala.annotation.tailrec

class ppITSpec extends FunSuite with Checkers with commonSparkSession with Serializable with PPTransformer with PPPVTransformer with channelRevisionMapper with channelMapper {

  def TSRecentNameToStarHistoricalName(line: List[String]): List[(String, String)] = {
    val filteredLine = line.filterNot(_ == null)
    createMapOfTargetChannelToSourceChannel(filteredLine.tail, filteredLine.head, Nil)
      .reverse
  }

  @tailrec
  final def createMapOfTargetChannelToSourceChannel(inp: List[String], first: String, output: List[(String, String)]):
  List[(String, String)] = inp match {
    case head :: tail => {
      createMapOfTargetChannelToSourceChannel(tail, first, output :+ (head -> first))
    }
    case Nil => output
  }

  test(" Integration Testing for all modules ") {

    implicit val appConf: Config = ConfigFactory.load("pp-ingestion-application.conf")

    val runWeek = "1"
    val runYear = "2019"
    val formattedWeek = "%02d".format(runWeek.toInt)

    // pp raw input data
    val inputData = List(
      ",,,,,,,,Universe,Target,Units,,,,,,,,,",
      ",,,,,,,,*01PUN / HAR / CHA / HP / J&K[All],*01PUN / HAR / CHA / HP / J&K[All],*01PUN / HAR / CHA / HP / J&K[All],*01PUN / HAR / CHA / HP / J&K[All],*01PUN / HAR / CHA / HP / J&K[All],*01PUN / HAR / CHA / HP / J&K[All],*01PUN / HAR / CHA / HP / J&K[All],*01PUN / HAR / CHA / HP / J&K[All],*01PUN / HAR / CHA / HP / J&K[All],*01PUN / HAR / CHA / HP / J&K[All],*01PUN / HAR / CHA / HP / J&K[All],*01PUN / HAR / CHA / HP / J&K[All]",
      ",,,,,,,,*01 4+,*01 4+,*01 4+,*01 4+,*01 4+,*01 4+,*02 15+,*02 15+,*02 15+,*02 15+,*02 15+,*02 15+",
      "Channel,Date,Week sat-fri,Main Title,Programme Genre,Weekday,Time (sec),To Time (sec),Duration,TRP (avgW),'000 (avg),Cover (1min cont),Cover000 (1min cont),Prog Share,Duration,TRP (avgW),'000 (avg),Cover (1min cont),Cover000 (1min cont),Prog Share",
      "DD National,29/12/2018,2019w01,AAP KI BAAT,Interviews/Portraits/Discussions,Saturday,09:01:16,09:25:27,24,0.0000,0.0000,0.0000,0.0000,0.0000,24,0.0000,0.0000,0.0000,0.0000,0.0000",
      "DD National 2,29/12/2018,2019w01,AAP KI BAAT,Interviews/Portraits/Discussions,Saturday,09:01:16,09:25:27,24,0.0000,0.0000,0.0000,0.0000,0.0000,24,0.0000,0.0000,0.0000,0.0000,0.0000",
      "Star Sports 1,29/12/2018,2019w01,L/T VODAFONE PBL-18-19 NOR/DEL-PUN PRE,Live Telecast/Sports,Saturday,19:06:43,22:34:37,207,0.0005,0.0142,0.0136,0.3760,0.0021,207,0.0006,0.0142,0.0158,0.3760,0.0025",
      "Star Sports 1,29/12/2018,2019w01,L/T VODAFONE PBL-18-19 NOR/DEL-PUN,Live Telecast/Sports,Saturday,19:06:43,22:34:37,207,0.0005,0.0142,0.0136,0.3760,0.0021,207,0.0006,0.0142,0.0158,0.3760,0.0025",
      "Star Sports 1,29/12/2018,2019w01,L/T VODAFONE PBL-18-19 NOR/DEL-PUN,Live Telecast/Sports,Saturday,19:06:43,22:34:38,207,0.0005,0.0142,0.0136,0.3760,0.0021,207,0.0006,0.0142,0.0158,0.3760,0.0025"
    )

    // sports summary raw input data
    val sportSummaryData = List(
      "*01PUN / HAR / CHA / HP / J&K[All],*01 4+,Star Sports 1,L/T VODAFONE PBL-18-19 NOR/DEL-PUN,2019w01,2019,29-12-2018,Saturday,Live Telecast/Sports,12475,0.000512,0.01416,0.013583,0.376,0.00214",
      "*01PUN / HAR / CHA / HP / J&K[All],*02 15+,Star Sports 1,L/T VODAFONE PBL-18-19 NOR/DEL-PUN,2019w01,2019,29-12-2018,Saturday,Live Telecast/Sports,12475,0.000595,0.01416,0.015794,0.376,0.002513"
    )

    val sportSummaryDF = spark.
      createDataFrame(spark.sparkContext.parallelize(sportSummaryData,1).map(a => Row.fromSeq(a.split(","))),
        Encoders.product[ppSummary].schema)

    // explode raw data into flat schema using pp_prevalidation
    val inputRDD = spark.sparkContext.parallelize(inputData,1)
    object pppv extends PPPVTransformer with Serializable
    val ppDF = pppv.lineParser(inputRDD, runYear, runWeek)

    // transform pp and sports summary data before merge
    val ppTransformedDF = preMergeTransformer(ppDF)
    val sportSummaryTransformedDF = preMergeTransformerSportsSummary(sportSummaryDF)

    // lt merge on pp data
    val ppAfterLTDF = ltMergeTransformer(ppTransformedDF, sportSummaryTransformedDF)

    // create channel revision mapping data
    val channelRevisionMappingData = Seq(
      Row("Channel Common", "channel 1", "channel 2", "channel 3", "channel 4", "channel 5", "channel 6"),
      Row("DD National", "DD National", "", "", "", "", ""),
      Row("Star Sports 1", "Star Sports 1", "", "", "", "", "")
    )

    // apply channel revision mapping on pp data
    val channelRevisionMappingLoadDF = spark.createDataFrame(spark.sparkContext.parallelize(channelRevisionMappingData), Encoders.product[channelRevisionMappingSchema].schema)

    val channelRevMapping = channelRevisionMappingLoadDF.collect().toList.map(x => x.mkString(","))
      .drop(1)
      .filter(elem => elem.size>0)
      .map(elem => elem.split(",").toList)
      .filter(elem => elem.size>0)
      .map(TSRecentNameToStarHistoricalName)
      .flatten

    val transformCRM = spark.
      createDataFrame(channelRevMapping).
      withColumnRenamed("_1", "channelName").
      withColumnRenamed("_2", "latestChannelName").
      withColumn("channelName", trim(upper(regexp_replace(col("channelName")," ","")))).
      withColumn("latestChannelName", trim(upper(regexp_replace(col("latestChannelName")," ",""))))

    val channelRevisionMappedPPDF = mapChannels(ppAfterLTDF, transformCRM)

    // create channel mapping data
    val channelMapData = Seq(
      Row("DD National", "01", "2019", "Hindi GEC", "DD Network", "FTA", "SD"),
      Row("Star Sports 1", "01", "2019", "Sport", "Star Network", "Paid", "SD")
    )

    // apply channel revision mapping on channel mapping data
    val channelMapLoadDF = spark.createDataFrame(spark.sparkContext.parallelize(channelMapData), Encoders.product[channelMappingSchema].schema)
    val channelAttributesMap = transformMappingFile(runYear, formattedWeek, channelMapLoadDF)

    val revisedNameMap = mapChannels(channelAttributesMap, transformCRM).
      filter("latestChannelName != 'NOT FOUND'").
      select("latestChannelName", "channelInfo").
      distinct()

    // perform channel mapping on pp data followed by transforming to final redshift schema
    val (channelAttributesMappedDF, errDF) = mapAttributes(channelRevisionMappedPPDF, revisedNameMap)
    val redshiftTransformedDF = redshiftSchemaTransformer(channelAttributesMappedDF, runYear, runWeek)

    assert(redshiftTransformedDF.columns.length == 27)
    assert(redshiftTransformedDF.count == 8)
    assert(errDF.count == 1)

    assertResult("DD National 2") {
      errDF.select("channel").distinct().head().getString(0)
    }

  }

}
