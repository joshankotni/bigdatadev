package com.star.prism.tatasky.pp.Ingestors

import java.io.File

import com.holdenkarau.spark.testing._
import com.star.prism.tatasky.commonSparkSession
import com.typesafe.config.ConfigFactory
import org.scalatest.FunSuite
import org.scalatest.prop.Checkers

class ppingestorspec extends FunSuite with Checkers with commonSparkSession {

  implicit val appConf = ConfigFactory.load("pp-test-application.conf")

  test("test ppIngestor.dataLoader") {

//    implicit val spark = SparkSessionProvider.sparkSession
    spark.sparkContext.setLogLevel("WARN")

    val path = new File("src/test/resources/test_pp/testdata").getAbsolutePath

    val df = new PpIngestor().ppdataLoader(path)

    assert(df.count() > 0)

  }

}
