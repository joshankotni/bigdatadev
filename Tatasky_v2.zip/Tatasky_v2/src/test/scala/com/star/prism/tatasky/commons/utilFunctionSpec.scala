package com.star.prism.tatasky.commons

import org.scalatest.FunSuite


class utilFunctionSpec extends FunSuite with utilFunctions {

  test("transformFunction.formardate"){
    assert(formatDate("2019/03/18") === "2019-03-18")
    assert(formatDate("18/03/2019") === "2019-03-18")
    assert(formatDate("18-03-2019") === "2019-03-18")
    assert(formatDate("2019-03-18") === "2019-03-18")
  }

  test("transformFunctions.formatUniverse") {
    assert(formatMarket("*01PUN / HAR / CHA / HP / J&K[All]") === "PUN / HAR / CHA / HP / J&K")
    assert(formatMarket("*02UP / UTTARAKHAND[All]") === "UP / UTTARAKHAND")
  }

  test("transformFunctions.formatTarget") {
    assert(formatTarget("*64 13+AB") === "13+AB")
  }

  test("transformFunctions.regionTransform") {
    assert(regionTransform("KARNATAK") === "KARNATAKA")
    assert(regionTransform("KERAL") === "KERALA")
    assert(regionTransform("Delhi") === "Delhi")
  }

  test("transformFunctions.getWeekStartDate") {
    assert(getWeekStartDate("2019", "01", 0) === "2018-12-29")
  }

  test("derive timezone from time") {
    assert(handleTimeBand("14:00:00") === "Non Prime")
    assert(handleTimeBand("19:00:00") === "Prime")
  }

  test("get day name from date") {
    assert(getDayName("2019-06-07") === "Friday")
  }

  test("round start time") {
    assert(roundStartTime("14:10:00") === "14:00:00")
    assert(roundStartTime("14:19:00") === "14:30:00")
    assert(roundStartTime("14:39:00") === "14:30:00")
    assert(roundStartTime("14:49:00") === "15:00:00")
  }

  test(" build twoDigitString") {
    assert(twoDigitString("01","w") === "w01")
  }

  test(" build fourDigitString") {
    assert(fourDigitString("2019") === "2019")
  }

  test(" build getPPInputDir") {
    assert(getPPInputDir("24","2019","w") === "w24-2019")
  }

  test(" buildCondition") {
    assert(buildCondition(List("*65 4-14ABC", "*29 15+AB"), "OR", "target") === "target = '*65 4-14ABC' OR target = '*29 15+AB'")
  }


}
