package com.star.prism.tatasky.pp.Transformers

import java.io.File

import com.holdenkarau.spark.testing.{DataFrameSuiteBase, SparkSessionProvider}
import com.star.prism.tatasky.commonSparkSession
import com.star.prism.tatasky.pp.Ingestors.PpIngestor
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.{Encoders, Row}
import org.scalatest.FunSuite
import org.scalatest.prop.Checkers

class ppdatatransformspec extends FunSuite with Checkers with commonSparkSession {

  test("test ppdatatransform.transformer") {
    implicit val appConf = ConfigFactory.load("pp-test-application.conf")
//    implicit val spark = SparkSessionProvider.sparkSession
    spark.sparkContext.setLogLevel("WARN")
    import spark.implicits._

    val path = new File("src/test/resources/test_pp/testdata").getAbsolutePath
    val df = new PpIngestor().ppdataLoader(path)

    val (df1,df2) = new ppTransformer().ppdatatransform(df)

    assert(df.count() > 0)
    assertResult("13+AB"){df1.select("target").distinct().head().getString(0)}
    assertResult(0){df1.filter($"Market".contains("[All]")).count()}
  }

  test ("test.ppdata.mockup.transformer") {
    implicit val appConf = ConfigFactory.load("pp-test-application.conf")
//    implicit val spark = SparkSessionProvider.sparkSession
    import spark.implicits._
    spark.sparkContext.setLogLevel("WARN")
    val data = Seq(
      Row("*01PUN / HAR / CHA / HP / J&K[All]", "*64 13+AB", "DD National", "29/12/2018", "2019w01", "BHAKTI DHARA", "Religious/Devotional", "Saturday", "05:02:39", "05:24:46", "22", "0.0000", "0.0000", "0.0000", "0.0000", "0.0000"),
      Row("*01PUN / HAR / CHA / HP / J&K[All]", "*64 13+AB", "DD National", "29/12/2018", "2019w01", "CINE SANGEET", "Film Songs", "Saturday", "06:00:13", "06:53:40", "53", "0.0000", "0.0000", "0.0000", "0.0000", "0.0000"),
      Row("*01PUN / HAR / CHA / HP / J&K[All]", "*64 13+AB", "Star Sports 1", "30/12/2018", "2019w01", "L/T VODAFONE PBL-18-19 AHM/CHE-PUN", "Live Telecast/Sports", "Sunday", "15:29:53", "18:58:34", "208", "0.0014", "0.0326", "0.1358", "3.188", "0.0109"),
      Row("*01PUN / HAR / CHA / HP / J&K[All]", "*64 13+AB", "Star Sports 1 HD", "30/12/2018", "2019w01", "L/T VODAFONE PBL-18-19 AHM/CHE-PUN", "Live Telecast/Sports", "Sunday", "15:29:54", "18:58:34", "208", "0.0017", "0.041", "0.0294", "0.6912", "0.0137"),
      Row("*01PUN / HAR / CHA / HP / J&K[All]", "*64 13+AB", "Star Sports 1", "31/12/2018", "2019w01", "L/T VODAFONE PBL-18-19 AWA/MUM-PUN", "Live Telecast/Sports", "Monday", "18:59:20", "22:36:40", "217", "0.0001", "0.0019", "0", "0", "0.0003")
    )

    val inputDF = spark.createDataFrame(spark.sparkContext.parallelize(data), Encoders.product[ppdataschema].schema)

    val (detaildf, groupdf) = new ppTransformer().ppdatatransform(inputDF)

    assert(detaildf.count() > 0)
    assert(groupdf.count() > 0)
    assertResult("2018-12-29"){detaildf.select("week_date").filter($"week_date" === "2018-12-29").distinct().head().getString(0)}

  }
  test ("test.ppsumarymockup.transformer") {
    implicit  val appConf = ConfigFactory.load("pp-test-application.conf")
//    implicit val spark = SparkSessionProvider.sparkSession
    spark.sparkContext.setLogLevel("WARN")
    val data1= Seq(
      Row("*01PUN / HAR / CHA / HP / J&K[All]","*64 13+AB","Star Sports 1","L/T VODAFONE PBL-18-19 AHM/CHE-PUN","2019w01","2018","30-12-2018","Sunday","Live Telecast/Sports","12522","0.00139","0.032622","0.135795","3.188","0.010929"),
      Row("*01PUN / HAR / CHA / HP / J&K[All]","*64 13+AB","Star Sports 1","L/T VODAFONE PBL-18-19 AWA/MUM-PUN","2019w01","2018","31-12-2018","Monday","Live Telecast/Sports","13041","0.000078","0.00185","0","0","0.000341"),
      Row("*01PUN / HAR / CHA / HP / J&K[All]","*64 13+AB","Star Sports 1 HD","L/T VODAFONE PBL-18-19 AHM/CHE-PUN","2019w01","2018","30-12-2018","Sunday","Live Telecast/Sports","12522","0.00139","0.032622","0.135795","3.188","0.010929")
    )
    val inputDF1 = spark.createDataFrame(spark.sparkContext.parallelize(data1), Encoders.product[ppsummary].schema)

    val summarydf = new ppTransformer().ppsummarytransform(inputDF1)

    assert(summarydf.count() > 0)

  }
  test("test.ppmap.transformer"){
    implicit  val appConf = ConfigFactory.load("pp-test-application.conf")
//    implicit val spark = SparkSessionProvider.sparkSession
    import spark.implicits._
    spark.sparkContext.setLogLevel("WARN")
    val path = new File("src/test/resources/test_pp/sports").getAbsolutePath

    val df = new PpIngestor().ppsportsLoader(path)
    val resourcesDirectory = new File(appConf.getString("test.path")).getAbsolutePath
    val channelNameMapLocation = resourcesDirectory + appConf.getString("ts.channel.revision.mapping")

    val df1 = new ppTransformer().ppsummarytransform(df)
    //assertResult("STARSPORTS1") {df1.filter("channel = 'Star Sports 1'").select("latestChannelName").distinct().head().getString(0)}

    assert(df1.count() > 0)

    val path1 = new File("src/test/resources/test_pp/testdata").getAbsolutePath
    val df2 = new PpIngestor().ppdataLoader(path1)

    val (df3,df4) = new ppTransformer().ppdatatransform(df2)

    //val channelNameMapLocation = resourcesDirectory + appConf.getString("ts.channel.revision.mapping")
    val channelAttributesMapLocation = resourcesDirectory + appConf.getString("ts.channel.attributes.mapping")
    val (ppjoined_latest,errordf,header_df) = new ppTransformer().ppmap(df2,df1,channelNameMapLocation,channelAttributesMapLocation,"2019","01","Tatasky","13+AB" )

    assertResult(0){ppjoined_latest.select("ns_flag").distinct().head().getInt(0)}
    assertResult(0){ppjoined_latest.filter($"market".contains("[All]")).count()}
    //assertResult("N"){errordf.select("error_flag").where(errordf("summary_count") === errordf("merged_count")).distinct().head().getString(0)}
    assertResult("Y"){header_df.select("error_flag").where(header_df("summary_count") !== header_df("merged_count")).distinct().head().getString(0)}

  }
}
