package com.star.prism.tatasky.commons

import java.io.File

import com.star.prism.tatasky.commonSparkSession
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql.{Encoders, Row}
import org.scalatest.prop.Checkers
import org.scalatest.{FunSuite, Matchers}

class channelAttributesMapperSpec extends FunSuite with Checkers with commonSparkSession with Matchers {

  implicit val appConf: Config = ConfigFactory.load("weekly-test-application.conf")

  val channelAttributesMap = new channelAttributesMapper()
  val resourcesDirectory: String = new File(appConf.getString("test.path")).getAbsolutePath

  case class channelMapSchema(channel: String, week: String, year: String, genre: String, main_network: String, channel_type: String, format: String, latestChannelName: String)

  test("test channelAttributesMapper.mapChannelAttributes") {

    val channelNameMapLocation = resourcesDirectory + appConf.getString("ts.channel.revision.mapping")
    val channelAttributesMapLocation = resourcesDirectory + appConf.getString("ts.channel.attributes.mapping")

    val data = Seq(
      Row("Sony", "40", "2018", "Hindi GEC", "Sony Network", "Paid", "SD", "SET"),
      Row("Khushboo Bangla", "40", "2018", "Bengali GEC", "Sony Network", "Paid", "SD", "KHUSHBOOBANGLA"),
      Row("SET", "40", "2018", "Hindi GEC", "Sony Network", "Paid", "SD", "SET"),
      Row("Asianet HD", "40", "2018", "Malayalam GEC", "Star Network", "Paid", "HD", "ASIANETHD"),
      Row("&Flix HD", "40", "2018", "English Movies", "Zee Network", "Paid", "HD", "&FLIXHD")
    )

    val inputDF = spark.createDataFrame(spark.sparkContext.parallelize(data), Encoders.product[channelMapSchema].schema)

    val (df, errorDF) = channelAttributesMap.mapChannelAttributes("2018", "40", inputDF, channelNameMapLocation, channelAttributesMapLocation, "TATASKY", "WEEKLY")

    assertResult("Sony Network") {
      df.filter("latestChannelName = 'SET'").select("main_network").distinct().head().getString(0)
    }
    assertResult("Hindi GEC") {
      df.filter("latestChannelName = 'SET'").select("genre").distinct().head().getString(0)
    }
    assertResult("Paid") {
      df.filter("latestChannelName = 'SET'").select("channel_type").distinct().head().getString(0)
    }
    assertResult("SD") {
      df.filter("latestChannelName = 'SET'").select("resolution_type").distinct().head().getString(0)
    }
//        assertResult("Spanish Music") {df.filter("latestChannelName = 'MTV'").select("genre").distinct().head().getString(0)} // To test failure

  }

    test("test channelAttributesMapper.transformAttributesMapFile") {

      val channelNameMapLocation = resourcesDirectory + appConf.getString("ts.channel.revision.mapping")

      val data = Seq(
        Row("Sony", "41", "2018", "Hindi GEC", "Sony Network", "Paid", "SD"),
        Row("Khushboo Bangla", "40", "2018", "Bengali GEC", "Sony Network", "Paid", "SD"),
        Row("SET", "40", "2018", "Hindi GEC", "Sony Network", "Paid", "SD"),
        Row("Asianet HD", "40", "2018", "Malayalam GEC", "Star Network", "Paid", "HD"),
        Row("&Flix HD", "40", "2018", "English Movies", "Zee Network", "Paid", "HD")
      )

      val inputDF = spark.createDataFrame(spark.sparkContext.parallelize(data), Encoders.product[channelMappingSchema].schema)
      val df = channelAttributesMap.transformAttributesMapFile("2018", "40", inputDF, channelNameMapLocation)

      assertResult("Sony Network|Hindi GEC|Paid|SD") {
        df.filter("latestChannelName = 'SET'").select("channelInfo").distinct().head().getString(0)
      }
      assertResult("Zee Network|English Movies|Paid|HD") {
        df.filter("latestChannelName = '&FLIXHD'").select("channelInfo").distinct().head().getString(0)
      }
      assertResult("Star Network|Malayalam GEC|Paid|HD") {
        df.filter("latestChannelName = 'ASIANETHD'").select("channelInfo").distinct().head().getString(0)
      }
//          assertResult(" Star Network|Malayalam GEC|Paid|HD ") {df.filter("latestChannelName = 'ASIANETHD'").select("channelInfo").distinct().head().getString(0)} //To Test Failure

    }

  case class channelAttributesMapSchema(latestChannelName: String, channelInfo: String)
  case class inputChannelSchema (channel: String, latestChannelName: String )

  test("test channelAttributesMapper.mapAttributes") {

      val inputData = Seq(
        Row("SET", "SET"),
        Row("Sony", "SET"),
        Row("&Flix HD", "&FLIXHD"),
        Row("Zee Studio HD", "&FLIXHD"),
        Row("Khushboo Bangla", "KHUSHBOOBANGLA"),
        Row("Asianet HD", "ASIANETHD")
      )

    val inputDF = spark.createDataFrame(spark.sparkContext.parallelize(inputData), Encoders.product[inputChannelSchema].schema)

      val channelMapData = Seq(
        Row("SET", "Sony Network|Hindi GEC|Paid|SD"),
        Row("&FLIXHD", "Zee Network|English Movies|Paid|HD"),
        Row("ASIANETHD", "Star Network|Malayalam GEC|Paid|HD")
      )

      val latestChannelMap = spark.createDataFrame(spark.sparkContext.parallelize(channelMapData), Encoders.product[channelAttributesMapSchema].schema)
      val (df, errorDF) = channelAttributesMap.mapAttributes(inputDF, latestChannelMap)

      assert(inputDF.select("channel").distinct().count() === df.select("channel").union(errorDF.select("channel")).distinct().count())

      assertResult("Sony Network") {
        df.filter("latestChannelName = 'SET'").select("main_network").distinct().head().getString(0)
      }

      assertResult("Hindi GEC") {
        df.filter("latestChannelName = 'SET'").select("genre").distinct().head().getString(0)
      }

      assertResult("Paid") {
        df.filter("latestChannelName = 'SET'").select("channel_type").distinct().head().getString(0)
      }

      assertResult("SD") {
        df.filter("latestChannelName = 'SET'").select("resolution_type").distinct().head().getString(0)
      }

//        assertResult("Music") {df.filter("latestChannelName = 'ASIANETHD'").select("genre").distinct().head().getString(0)} // To test failure

    }


    case class inputSchema(channel: String, genre: String, main_network: String, channel_type: String, resolution_type: String)

    test("test channelAttributesMapper.filterErrorChannels") {

      import spark.implicits._

      val data = Seq(
        Row("Hello World TV", "NOT FOUND", "NOT FOUND", "NOT FOUND", "NOT FOUND"),
        Row("CHANNEL NOT FOUND", "NOT FOUND", "NOT FOUND", "NOT FOUND", "NOT FOUND"),
        Row("Wrong TV", "NOT FOUND", "NOT FOUND", "NOT FOUND", "NOT FOUND")
      )

      val inputDF = spark.createDataFrame(spark.sparkContext.parallelize(data), Encoders.product[inputSchema].schema)

      val df = channelAttributesMap.filterErrorChannels("2018", "40", "TATASKY", "WEEKLY", inputDF)

      assert(df.count() > 0)
      df.select("channel").map(r => r.getString(0)).collect.toList should contain theSameElementsAs Iterable("Hello World TV", "CHANNEL NOT FOUND", "Wrong TV")
//          assert(df.count() < 0) // To test for failure

    }

}