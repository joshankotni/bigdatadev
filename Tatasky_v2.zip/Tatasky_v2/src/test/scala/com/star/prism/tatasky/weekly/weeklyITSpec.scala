package com.star.prism.tatasky.weekly

import java.io.File

import com.star.prism.tatasky.commonSparkSession
import com.star.prism.tatasky.weekly.Egestors.WeeklyEgestor
import com.star.prism.tatasky.weekly.Transformers.{WeeklyTransformer, weeklyInputSchema}
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.Encoders
import org.scalatest.FunSuite
import org.scalatest.prop.Checkers


class weeklyITSpec extends FunSuite with Checkers with commonSparkSession {

  implicit val appConf = ConfigFactory.load("weekly-test-application.conf")

  // run one test at a time (second one's input is the output of the first)

  test(" Integration Testing for all modules (YW) ") {

//    implicit val spark = SparkSessionProvider.sparkSession
    spark.sparkContext.setLogLevel("WARN")

    val runWeek = "40"
    val runYear = "2018"
    val formattedWeek = "%02d".format(runWeek.toInt)

    val confPath =  appConf.getString("ts.weekly.input.s3.path.prefix") + s"year=$runYear/week=$formattedWeek"
    val resourcesDirectory = new File(appConf.getString("test.path")).getAbsolutePath

    val loadPath = resourcesDirectory + confPath
    val channelNameMapLocation = resourcesDirectory + appConf.getString("ts.channel.revision.mapping")
    val channelAttributesMapLocation = resourcesDirectory + appConf.getString("ts.channel.attributes.mapping")

    val outputLocationYW = resourcesDirectory + appConf.getString("ts.weekly.output.yw.prefix") + appConf.getString("ts.weekly.output.yw.folder")
    val outputLocationError = resourcesDirectory + appConf.getString("ts.weekly.output.yw.prefix") + appConf.getString("ts.error.output.folder")

    val inputDF = new Ingestors.WeeklyIngestor().dataLoader(loadPath)
    val (df, errorDF) = new WeeklyTransformer().applyWeeklyTransforms(runYear, runWeek, inputDF, channelNameMapLocation, channelAttributesMapLocation)
    new WeeklyEgestor().dataWriter(df, errorDF, outputLocationYW, outputLocationError)

    //testing count and schema
    assert(inputDF.count() > 0)
    assert(inputDF.schema === Encoders.product[weeklyInputSchema].schema)
    assert(df.count() > 0)
    assert(errorDF.count() >= 0)

  }


  test(" Integration Testing for MT Repartition ") {

//    implicit val spark = SparkSessionProvider.sparkSession
    spark.sparkContext.setLogLevel("WARN")

    val confPath =  appConf.getString("ts.weekly.output.yw.prefix") + appConf.getString("ts.weekly.output.yw.folder")
    val resourcesDirectory = new File(appConf.getString("test.path")).getAbsolutePath
    val inputLocationYW = resourcesDirectory + confPath
    val outputLocationMT = resourcesDirectory + appConf.getString("ts.weekly.output.mt.prefix") + appConf.getString("ts.weekly.output.mt.folder")

    val df = new Ingestors.WeeklyIngestor().dataLoaderMT(inputLocationYW)
    new WeeklyEgestor().dataWriterMT(df, outputLocationMT)

    //testing count
    assert(df.count() > 0)

  }

}
