package com.star.prism.tatasky.pp

import java.io.File

import com.star.prism.tatasky.commonSparkSession
import com.star.prism.tatasky.pp.Egestors.ppegestor
import com.star.prism.tatasky.pp.Ingestors.PpIngestor
import com.star.prism.tatasky.pp.Transformers.ppTransformer
import com.typesafe.config.ConfigFactory
import org.scalatest.FunSuite
import org.scalatest.prop.Checkers

class ppITSpec extends FunSuite with Checkers with commonSparkSession  {

  test("test.ppmap.transformer"){
    implicit  val appConf = ConfigFactory.load("pp-test-application.conf")
//    implicit val spark = SparkSessionProvider.sparkSession
    import spark.implicits._
    spark.sparkContext.setLogLevel("WARN")
    val path = new File("src/test/resources/test_pp/sports").getAbsolutePath

    val df = new PpIngestor().ppsportsLoader(path)
    val resourcesDirectory = new File(appConf.getString("test.path")).getAbsolutePath
    val channelNameMapLocation = resourcesDirectory + appConf.getString("ts.channel.revision.mapping")

    val df1 = new ppTransformer().ppsummarytransform(df)
    //assertResult("STARSPORTS1") {df1.filter("channel = 'Star Sports 1'").select("latestChannelName").distinct().head().getString(0)}
    assert(df1.count() > 0)

    val path1 = new File("src/test/resources/test_pp/testdata").getAbsolutePath
    val df2 = new PpIngestor().ppdataLoader(path1)

    val (df3,df4) = new ppTransformer().ppdatatransform(df2)

    //val channelNameMapLocation = resourcesDirectory + appConf.getString("ts.channel.revision.mapping")
    val channelAttributesMapLocation = resourcesDirectory + appConf.getString("ts.channel.attributes.mapping")
    val (ppjoined_latest,errordf,header_df) = new ppTransformer().ppmap(df2,df1,channelNameMapLocation,channelAttributesMapLocation,"2019","01","Tatasky","13+AB" )

    assertResult(0){ppjoined_latest.select("ns_flag").distinct().head().getInt(0)}
    assertResult(0){ppjoined_latest.filter($"market".contains("[All]")).count()}
    //assertResult("N"){errordf.select("error_flag").where(errordf("summary_count") === errordf("merged_count")).distinct().head().getString(0)}
    //assertResult("Y"){errordf.select("error_flag").where(errordf("summary_count") !== errordf("merged_count")).distinct().head().getString(0)}
    val year_week_path_format = new File("src/test/resources/test_pp/output/yw/").getAbsolutePath
    val year_week_path_format1 = new File("src/test/resources/test_pp/output/report/").getAbsolutePath
    val year_week_path_format2 = new File("src/test/resources/test_pp/output/report2/").getAbsolutePath
    new ppegestor().dataWriter(ppjoined_latest,errordf,header_df,year_week_path_format,year_week_path_format1, year_week_path_format2)
  }

}
