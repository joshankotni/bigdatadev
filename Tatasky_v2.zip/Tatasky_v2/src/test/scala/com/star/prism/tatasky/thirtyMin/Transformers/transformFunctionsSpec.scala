package com.star.prism.tatasky.thirtyMin.Transformers

import org.scalatest.FunSuite

class transformFunctionsSpec extends FunSuite {

  val transformFunc = new transformFunctions()

  test("transformFunctions.formatUniverse") {
    assert(transformFunc.formatUniverse("*01PUN / HAR / CHA / HP / J&K[All]") === "PUN / HAR / CHA / HP / J&K")
  }

  test("transformFunctions.formatTarget") {
    assert(transformFunc.formatTarget("*64 13+AB") === "13+AB")
  }

  test("transformFunctions.regionTransform") {
    assert(transformFunc.regionTransform("KARNATAK") === "KARNATAKA")
    assert(transformFunc.regionTransform("KERAL") === "KERALA")
    assert(transformFunc.regionTransform("Delhi") === "Delhi")
    assert(transformFunc.regionTransform("Delhi") === "Delhi")
    assert(transformFunc.regionTransform("ALL INDIA") === " ALL INDIA")
  }

  test("transformFunctions.getWeekStartDate") {
    assert(transformFunc.getWeekStartDate("2018", "40", 0) === "2018-09-29")
  }

  test("transformFunctions.formatDate") {
    assert(transformFunc.formatDate("29/09/2018") === "2018-09-29")
    assert(transformFunc.formatDate("29-09-2018") === "2018-09-29")
  }

  test("transformFunctions.determineTimeZone") {
    assert(transformFunc.determineTimeZone("18:30") === "Prime")
    assert(transformFunc.determineTimeZone("22:30") === "Prime")
    assert(transformFunc.determineTimeZone("01:30") === "Non Prime")
    assert(transformFunc.determineTimeZone("08:30") === "Non Prime")
  }


}


