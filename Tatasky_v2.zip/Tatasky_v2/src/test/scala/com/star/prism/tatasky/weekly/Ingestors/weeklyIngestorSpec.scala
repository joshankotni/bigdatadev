package com.star.prism.tatasky.weekly.Ingestors

import java.io.File

import com.star.prism.tatasky.commonSparkSession
import com.star.prism.tatasky.weekly.Ingestors
import com.star.prism.tatasky.weekly.Transformers.weeklyInputSchema
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql.Encoders
import org.scalatest.FunSuite
import org.scalatest.prop.Checkers

class weeklyIngestorSpec extends FunSuite with Checkers with commonSparkSession {

  implicit val appConf: Config = ConfigFactory.load("weekly-test-application.conf")
  val resourcesDirectory: String = new File(appConf.getString("test.path")).getAbsolutePath

  val weeklyIngestor = new Ingestors.WeeklyIngestor()

  test("test WeeklyIngestor.dataLoader") {

    val runWeek = "40"
    val runYear = "2018"
    val formattedWeek = "%02d".format(runWeek.toInt)

    val confPath =  appConf.getString("ts.weekly.input.s3.path.prefix") + s"year=$runYear/week=$formattedWeek"
    val loadPath = resourcesDirectory + confPath

    val df = weeklyIngestor.dataLoader(loadPath)

    //testing count and schema
    assert(df.count() > 0)
    assert(df.schema === Encoders.product[weeklyInputSchema].schema)

  }


  test("test WeeklyIngestor.dataLoaderMT") {

    val confPath =  appConf.getString("ts.weekly.output.yw.prefix") + appConf.getString("ts.weekly.output.yw.folder")
    val inputLocationYW = resourcesDirectory + confPath

    val df = weeklyIngestor.dataLoaderMT(inputLocationYW)

   //testing count
    assert(df.count() > 0)

  }

}
