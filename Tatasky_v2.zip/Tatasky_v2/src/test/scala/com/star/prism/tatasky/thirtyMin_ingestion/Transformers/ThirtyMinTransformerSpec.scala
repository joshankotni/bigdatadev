package com.star.prism.tatasky.thirtyMin_ingestion.Transformers

import com.star.prism.tatasky.commonSparkSession
import com.star.prism.tatasky.schemas.thirtyMin.thirtyMinSchema
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql.{Encoders, Row}
import org.scalatest.prop.Checkers
import org.scalatest.{FunSuite, Matchers}

class ThirtyMinTransformerSpec extends FunSuite with Checkers with commonSparkSession with Matchers with Serializable with ThirtyMinTransformer{

  implicit val appConf: Config = ConfigFactory.load("thirtyMin-ingestion-application.conf")

  test(" Test applyThirtyMinTranforms ") {

    val runWeek = "1"
    val runYear = "2019"

    val inputData = Seq(
      Row("","","","","","","","Units","","","",""),
      Row("Universe","Target","Channel","Week sat-fri","Date","Weekday","Daypart","TRP (avgW)","'000 (avg)","Cover (1min cont)","Cover000 (1min cont)","Share"),
      Row("*01PUN / HAR / CHA / HP / J&K[All]","*01 4+","All Channels","2019w01","29/12/2018","Saturday","0200 - 0229","0.2063","5.7102","0.4663","12.9085","100.0000"),
      Row("*01PUN / HAR / CHA / HP / J&K[All]","*01 4+","DD National","2019w01","30/12/2018","Sunday","0200 - 0229","0.0000","0.0000","0.0000","0.0000","0.0000"),
      Row("*01PUN / HAR / CHA / HP / J&K[All]","*01 4+","DD National","2019w01","30/12/2018","Sunday","0230 - 0259","0.0000","0.0000","0.0000","0.0000","0.0000"),
      Row("*01PUN / HAR / CHA / HP / J&K[All]","*01 4+","DD","2019w01","30/12/2018","Sunday","0230 - 0259","0.0000","0.0000","0.0000","0.0000","0.0000"),
      Row("*01PUN / HAR / CHA / HP / J&K[All]","*01 4+","Star Sports 1","2019w01","31/12/2018","Monday","2000 - 2029","0.0000","0.0000","0.0000","0.0000","0.0000"),
      Row("*01PUN / HAR / CHA / HP / J&K[All]","*01 4+","Star Sports 1","2019w01","31/12/2018","Monday","2030 - 2059","0.0000","0.0000","0.0000","0.0000","0.0000")
    )

    val inputDF = spark.createDataFrame(spark.sparkContext.parallelize(inputData), Encoders.product[thirtyMinSchema].schema)
    val transformedDF = applyThirtyMinTranforms(inputDF, runYear, runWeek)

    assert(transformedDF.count > 0)
    assert(transformedDF.columns.length == 18)

    assertResult("4+") {
      transformedDF.select("target").distinct().head().getString(0)
    }

    assertResult("PUN / HAR / CHA / HP / J&K") {
      transformedDF.select("market").distinct().head().getString(0)
    }

  }

}
