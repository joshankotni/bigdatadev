package com.star.prism.tatasky.pp.Transformers

import org.scalatest.FunSuite

class transformfunctionspec extends FunSuite {

  test("transformFunction.formardate"){
    assert(new transformFunctions().formatDate("2019/03/18") === "2019-03-18")
    assert(new transformFunctions().formatDate("18/03/2019") === "2019-03-18")
    assert(new transformFunctions().formatDate("18-03-2019") === "2019-03-18")
    assert(new transformFunctions().formatDate("2019-03-18") === "2019-03-18")
  }

  test("transformFunctions.formatUniverse") {
    assert(new transformFunctions().formatUniverse("*01PUN / HAR / CHA / HP / J&K[All]") === "PUN / HAR / CHA / HP / J&K")
    assert(new transformFunctions().formatUniverse("*02UP / UTTARAKHAND[All]") === "UP / UTTARAKHAND")
  }

  test("transformFunctions.formatTarget") {
    assert(new transformFunctions().formatTarget("*64 13+AB") === "13+AB")
  }

  test("transformFunctions.regionTransform") {
    assert(new transformFunctions().regionTransform("KARNATAK") === "KARNATAKA")
    assert(new transformFunctions().regionTransform("KERAL") === "KERALA")
    assert(new transformFunctions().regionTransform("Delhi") === "Delhi")
  }

  test("transformFunctions.getWeekStartDate") {
    assert(new transformFunctions().getWeekStartDate("2019", "01", 0) === "2018-12-29")
  }

}
