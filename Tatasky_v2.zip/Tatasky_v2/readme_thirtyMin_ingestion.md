## Introduction 
---

This package contains the code for ingestion of Tatasky 30 Min data, written in Spark Scala. 
The inputs are present as CSV files in S3 and the output is stored as Parquet files in S3.


## Input/Output Details
---

| Input Type                        | S3 Locations                                          |
| ----------------------------------|-------------------------------------------------------|
| 30 Min Input                      | s3://tataskyagg/active/30min     	                    |
| Channel Revision Mapping          | s3://tataskyagg/Channel_Revision_Mapping/             |
| Channel Attributes Mapping        | s3://tataskyagg/Channel_Mapping/ 	                    |
| 30 Min Output (YWD)               | s3://tataskyagg/thirtyMin-ingestion-ywd/    	        |
| 30 Min Output (MT)                | s3://tataskyagg/thirtyMin-ingestion-mt/ 	            |


*Note: The locations are set in thirtyMin-ingestion-application.conf file 


## Process Description
---

The module has an uniform structure for all its submodules. They consist of packages of Ingestors, Transformers and Egestors. The main object is present outside these packages and serves as the entry point for running the process.

- Ingestors have methods to load the data, 
- Transformers have methods to parse Date, Target and Market columns and align the data with the Redshift Schema. 
- Also, Channel attributes are mapped using an intermediate channel revision mapping file. The modules for channel mapping and channel revision mapping are present in commons package.
- Egestors have methods to write output to S3 as parquet files.


## Pre-Requisties before running the code
---

The following input sources must be ready before running the code.

- Built JAR of the code
- S3 input data
- Channel Revision Mapping and Channel Mapping (Attributes)

Once these pre-requisites are present, the jar can be run.


## Running the code
---

The jar can be run using the following spark-submit commands:


```
export SPARK_MAJOR_VERSION=2
spark-submit --master yarn --queue jobs --num-executors 30 --executor-cores 2 --driver-memory 2G --executor-memory 7G \
--conf 'spark.driver.extraJavaOptions=-XX:+UseG1GC -Dconfig.file=/ebs_1/nithish/ts30min/thirtyMin-ingestion-application.conf' \
--conf 'spark.executor.extraJavaOptions=-XX:+UseG1GC -Dconfig.file=/ebs_1/nithish/ts30min/thirtyMin-ingestion-application.conf' \
--properties-file /ebs_1/nithish/ts30min/spark-defaults.conf \
--packages com.typesafe:config:1.3.3 \
--class com.star.prism.tatasky.thirtyMin_ingestion.ThirtyMinIngestionMain /ebs_1/nithish/ts30min/tatasky_2.11-0.1.jar > /ebs_1/nithish/ts30min/ts30min_ingestion.log 2>&1 

```

## Current Processing Time Information
---

It takes around 3-4 min to process 1 week of data and store them as both Year-Week-Week_Date partioned as well as Market-Target partitioned files.
