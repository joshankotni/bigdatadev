## Introduction 
---

NOTE: This readme was written for ingestion of 13+AB TG codes. Check other readme files for info about the latest codes.

This package contains the code for ingestion of Tatasky Weekly, 30 Min and PP data, written in Spark Scala. The inputs are present in S3 and the output is stored as Parquet files in S3.


## Input Details
---

| Input Type                    | S3 Locations                                          |
| ------------------------------|-------------------------------------------------------|
| Weekly Input (13+ AB)         | s3://tataskyagg/13+AB/weekly/ 	                    |
| 30 Min Input (13+ AB)         | s3://tataskyagg/13+AB/30min/ 	                        |
| PP Input (13+ AB)             | s3://tataskyagg/13+AB/pp/     	                    |
| Channel Revision Mapping      | s3://tataskyagg/13+AB/channel-revision-mapping/       |
| Channel Attributes Mapping    | s3://tataskyagg/13+AB/chnl-map/ 	                    |
| PP Summary Input (13+ AB)     | s3://tataskyagg/13+AB/LiveSports_Summary/         	|


*Note: The input locations are set in respective conf files and should be changed when ingesting a new TG


## Output Details
---

| Output Type                   | S3 Locations   	                                    |
| ------------------------------|-------------------------------------------------------|
| Weekly Output (13+ AB, YW)    | s3://star-dl-tatasky/processed/ts-weekly-13ab-yw 	    |
| Weekly Output (13+ AB, MT)    | s3://star-dl-tatasky/processed/ts-weekly-13ab-mt 	    |
| 30 Min Output (13+ AB, YW)    | s3://star-dl-tatasky/processed/ts-30min-13ab-ywd 	    |
| 30 Min Output (13+ AB, MT)    | s3://star-dl-tatasky/processed/ts-30min-13ab-mt 	    |
| PP Output (13+ AB, YW)        | s3://star-dl-tatasky/processed/ts-pp-13ab-ywd    	    |
| PP Output (13+ AB, MT)        | s3://star-dl-tatasky/processed/ts-pp-13ab-mt 	        |


*Note: The output locations are set in respective conf files and should be changed when ingesting a new TG


## Error Tracking Files details
---

| Tracker Type                          | Error Tracking Files S3 paths                                             |
| --------------------------------------|---------------------------------------------------------------------------|
| Channel Revision/Attributes Mapping   | s3://star-dl-tatasky/processed/ts-13AB-ingestion-error-reporting         |
| PP Summary and Merged Counts          | s3://star-dl-tatasky/processed/ts-13AB-ingestion-error-reporting-counts  |



## Process Description
---

Each of the Ingestion modules (Weekly/30 Min/PP) has an uniform structure for all its submodules. They consist of packages of Ingestors, Transformers and Egestors. The main object is present outside these packages and serves as the entry point for running the process.

For Weekly process, 
- Ingestors have methods to load the data, 
- Transformers have methods to parse Target and Market columns and align it to the Redshift Schema. Also, Channel attributes are mapped using an intermediate channel revision mapping file, which provides the latest channel name for mapping.
- Egestors have methods to write output to S3 and to record the channels with no mapping as CSV files.

For 30 Min process, 
- Ingestors have methods to load the data, 
- Transformers have methods to parse Date, Target and Market columns, determine the Timezone and Start Time and align it to the Redshift Schema. Also, Channel attributes are mapped using an intermediate channel revision mapping file, which provides the latest channel name for mapping.
- Egestors have methods to write output to S3 and to record the channels with no mapping as CSV files.

For PP process, 
- Ingestors have methods to load the data, 
- Transformers have methods to parse Target and Market columns do the L/T merge based n latest channel name and  align it to the Redshift Schema. Also, Channel attributes are mapped using an intermediate channel revision mapping file.
- Egestors have methods to write output to S3, find the count of L/T merge records and to record the channels with no mapping as CSV files.



## Pre-Requisties before running the code
---

The following input sources must be ready before running the code.

For Weekly and 30 Min,

- Built JAR of the code
- S3 input data
- Channel Revision Mapping and Channel Mapping (Attributes)

For PP, in addition those above, PP Summary files for Sports and Non Sports channels are also required.

Once these pre-requisites are present, the jar can be run for the specific input types.


## Running the code
---

The jar can be run using the following spark-submit commands:

### Weekly

#### For Year-Week Partition

```
export SPARK_MAJOR_VERSION=2
spark-submit --packages com.typesafe:config:1.3.3 --class com.star.prism.tatasky.weekly.WeeklyIngestionMain --master yarn --queue jobs --num-executors 10  --executor-cores 2 --driver-memory 1G --executor-memory 7G /ebs_1/nithish/ts_weekly/tataskyingestion_2.11-0.1.jar "/ebs_1/nithish/ts_13ab/weekly-application.conf" 2019 1 0 > /ebs_1/nithish/ts_weekly/logs/ts_weekly_13ab_2019_1.log 2>&1

```

#### For Market-Target Partition (All years together)

```
export SPARK_MAJOR_VERSION=2
spark-submit --packages com.typesafe:config:1.3.3 --class com.star.prism.tatasky.weekly.WeeklyIngestionMain --master yarn --queue jobs --num-executors 10  --executor-cores 2 --driver-memory 1G --executor-memory 7G /ebs_1/nithish/ts_weekly/tataskyingestion_2.11-0.1.jar "/ebs_1/nithish/ts_13ab/weekly-application.conf" 2018 0 1 > /ebs_1/nithish/ts_weekly/logs/ts_weekly_13ab_2018_0.log 2>&1

```

### 30 Min

#### For Year-Week Partition

```
export SPARK_MAJOR_VERSION=2
spark-submit --packages com.typesafe:config:1.3.3 --class com.star.prism.tatasky.thirtyMin.thirtyMinIngestionMain --master yarn --queue jobs --num-executors 10  --executor-cores 2 --driver-memory 1G --executor-memory 7G /ebs_1/nithish/ts_13ab/tataskyingestion_2.11-0.1.jar "/ebs_1/nithish/ts_13ab/thirtyMin-application.conf" 2018 29 0 > /ebs_1/nithish/ts_13ab/logs/ts_thirtyMin_13ab_2018_29.log 2>&1

```

#### For Market-Target Partition (One Year at a time)

```
export SPARK_MAJOR_VERSION=2
spark-submit --packages com.typesafe:config:1.3.3 --class com.star.prism.tatasky.thirtyMin.thirtyMinIngestionMain --master yarn --queue jobs --num-executors 30  --executor-cores 2 --driver-memory 1G --executor-memory 7G /ebs_1/nithish/ts_13ab/tataskyingestion_2.11-0.1.jar "/ebs_1/nithish/ts_13ab/thirtyMin-application.conf" 2018 0 1 > /ebs_1/nithish/ts_13ab/logs/ts_thirtyMin_13ab_2018_0.log 2>&1

```


### PP

#### For Year-Week Partition

```
export SPARK_MAJOR_VERSION=2
spark-submit --packages com.typesafe:config:1.3.3 --class com.star.prism.tatasky.pp.PpIngestionMain --master yarn --queue jobs --num-executors 20  --executor-cores 2 --driver-memory 1G --executor-memory 7G /ebs_1/nithish/ts_13ab/tataskyingestion_2.11-0.1.jar "/ebs_1/nithish/ts_13ab/pp-application.conf" 2018 29 0 > /ebs_1/nithish/ts_13ab/logs/ts_pp_13ab_2018_29.log 2>&1

```

#### For Market-Target Partition (One Year at a time)

```
export SPARK_MAJOR_VERSION=2
spark-submit --packages com.typesafe:config:1.3.3 --class com.star.prism.tatasky.pp.PpIngestionMain --master yarn --queue jobs --num-executors 30  --executor-cores 2 --driver-memory 1G --executor-memory 7G /ebs_1/nithish/ts_13ab/tataskyingestion_2.11-0.1.jar "/ebs_1/nithish/ts_13ab/pp-application.conf" 2018 0 1 > /ebs_1/nithish/ts_13ab/logs/ts_pp_13ab_2018_0.log 2>&1 &

```


## Processing Time Information
---

### Current Processing Times

- Tatasky Weekly partitioned on Year and Week:  ~1 min per week 
- Tatasky Weekly partitioned on Market and Target:  ~2 min for 26 weeks of data provided (2018w29 - 2019w02)
 
- Tatasky 30 Min partitioned on Year and Week:  ~1.5 min per week 
- Tatasky 30 Min partitioned on Market and Target:  ~6 min for 26 weeks of data provided (2018w29 - 2019w02)

- Tatasky PP partitioned on Year and Week:  ~2.5 min per week 
- Tatasky PP partitioned on Market and Target:  ~8 min for 26 weeks of data provided (2018w29 - 2019w02)


### Performance Optimizations Details

- Tatasky 30 Min partitioned on Market and Target took ~9 min for the entire set of data previously. This was because the Output was repartitioned to 1 previously. After repartitioning to 3, the time has reduced by 3 min to 6 min

- Tatasky PP took ~4 min per week previously. This was because both Year-Week-WeekDate and Market-Target partitioning were done simultaneously. By splitting the process into 2, around 31 min were saved. 
- Tatasky PP partitioned on Year-Week-WeekDate takes ~2.5 min per week now and Tatasky PP partitioned on Market-Target takes around ~8 min for entire set of data.
- Total Previous = 4 x 26 = 104 min and Total Current = 2.5 x 26 = 65 min(YWD) + 8 min(MT) = 73 min


## Tata sky regular pp and L/T Python script of gramener 
---

- s3 path for pp bucket: tataskyagg path "active/pp/w17-2019"
- s3 path for L/T bucket:tataskyagg path "sports_pp/w17-2019"
- run instructions for week 01:
    * python tata_sky_pp_upload.py w01-2019
    * python tatasky_lt.py w01-2019

